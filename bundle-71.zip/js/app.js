/*
 * «Пора валить» для телефона.
 * Слева (или на весь экран на внешнем дисплее Fold): «Места» и «Рядом».
 * Справа (или поверх): поездка до места или остановка — отсчёт, карта, живые автобусы.
 */
(function (App) {
  'use strict';
  var T = App.time;
  var cfg = App.config;

  // ---------- Маленькие помощники ----------
  function $(id) { return document.getElementById(id); }
  function h(tag, attrs, kids) {
    var parts = tag.split('.');
    var el = document.createElement(parts[0] || 'div');
    if (parts.length > 1) el.className = parts.slice(1).join(' ');
    if (attrs) Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'text') el.textContent = v;
      else if (k === 'on') Object.keys(v).forEach(function (ev) { el.addEventListener(ev, v[ev]); });
      else el.setAttribute(k, v === true ? '' : v);
    });
    (kids || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return el;
  }
  function icon(id, cls) {
    var ns = 'http://www.w3.org/2000/svg';
    var s = document.createElementNS(ns, 'svg');
    s.setAttribute('class', 'ic' + (cls ? ' ' + cls : ''));
    s.setAttribute('aria-hidden', 'true');
    var u = document.createElementNS(ns, 'use');
    u.setAttribute('href', '#i-' + id);
    s.appendChild(u);
    return s;
  }
  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
  function km(m) { return m < 1000 ? Math.round(m / 10) * 10 + tr(' м') : (m / 1000).toFixed(1).replace('.', ',') + tr(' км'); }
  function minutes(ms) { return Math.max(0, Math.round(ms / 60000)); }

  // «через 7:42», «через 1 ч 05 мин»
  function leftText(ms) {
    if (ms <= 0) return tr('сейчас');
    if (ms >= 3600000) {
      var mm = Math.floor(ms / 60000);
      return Math.floor(mm / 60) + tr(' ч ') + (mm % 60 < 10 ? '0' : '') + (mm % 60) + tr(' мин');
    }
    return T.countdown(ms);
  }

  var STATUS = {
    relax: tr('Можно не спешить'), soon: tr('Собирайся'), go: tr('Пора выходить'), late: tr('Уже не успеть'),
    none: tr('Нет рейсов'), noorigin: tr('Жду GPS'), loading: tr('Считаю…'), here: tr('Вы уже здесь'), error: tr('Нет связи')
  };

  function lineBadge(mode, line, big) {
    return h('span.badge.mode-' + String(mode || 'BUS').toLowerCase() + (big ? '.badge-big' : ''), null, [icon(App.modeIcon(mode)), h('span', { text: line || '?' })]);
  }
  function chain(opt) {
    var legs = (opt.legs || []).filter(function (l) { return l.transit; });
    var kids = [];
    legs.forEach(function (l, i) {
      if (i) kids.push(h('span.chain-sep', { text: '›', 'aria-hidden': 'true' }));
      kids.push(lineBadge(l.mode, l.line));
    });
    return h('span.chain', null, kids);
  }

  // ---------- Раскладка: одна колонка или две (раскрытый Fold) ----------
  var appEl = $('app');
  var splitMq = window.matchMedia('(min-width: 700px)');
  function isSplit() { return splitMq.matches; }

  // ---------- Состояние ----------
  var state = {
    tab: 'places',
    detail: null,        // { kind: 'trip', trip, place, selected } | { kind: 'stop', stop }
    trips: {},           // id места -> Trip
    nearby: { stops: [], at: 0, from: null, loading: false, error: '', open: {} },
    queue: [], queueBusy: false
  };

  function tripFor(place) {
    var t = state.trips[place.id];
    if (!t) {
      // Разовые поездки (адрес из поиска) не копим: оставляем только текущую
      if (place.temp && /^tmp-/.test(place.id)) Object.keys(state.trips).forEach(function (k) { if (/^tmp-/.test(k)) delete state.trips[k]; });
      t = new App.Trip(place); state.trips[place.id] = t;
    }
    t.place = place;
    return t;
  }

  // Маршруты для карточек считаем по одному, чтобы не заваливать Peatus.ee запросами.
  function enqueue(trip, opts) {
    if (state.queue.some(function (q) { return q.trip === trip; })) return;
    state.queue.push({ trip: trip, opts: opts });
    pump();
  }
  function pump() {
    if (state.queueBusy || !state.queue.length) return;
    var origin = App.here.origin();
    if (!origin) { state.queue = []; return; }
    state.queueBusy = true;
    var job = state.queue.shift();
    job.trip.refresh(origin, job.opts).then(function () {
      // Через setTimeout, а не сразу: даже если ответ мгновенный, интерфейс успевает отвечать на нажатия
      setTimeout(function () {
        state.queueBusy = false;
        renderPlaces();
        if (state.detail && state.detail.trip === job.trip) renderDetail(true);
        pump();
      }, 0);
    });
  }

  // От чего считаем — для подписей «от вас / от дома / от работы / от точки»
  function originWord() {
    var m = App.here.mode;
    if (m === 'home' && cfg.home) return tr('от дома');
    if (m === 'work' && cfg.work) return tr('от работы');
    if (m === 'pick' && App.here.pick) return tr('от точки');
    return tr('от вас');
  }
  function originName() {
    var o = App.here.origin();
    return o ? o.label : '';
  }
  // Маркеры на карте: настоящее место телефона — синяя точка всегда; «Откуда» (дом/работа/точка) — отдельный пин
  function applyMe(data) {
    var g = App.here.gps;
    var o = App.here.origin();
    if (g) data.me = { lat: g.lat, lon: g.lon, acc: g.acc };
    if (o && (App.here.mode !== 'gps' || !g || o.fallback)) {
      data.origin = { lat: o.lat, lon: o.lon, kind: o.home ? 'home' : o.work ? 'work' : 'pin', label: o.label };
    }
  }

  // ---------- Откуда ----------
  function renderOrigin() {
    var o = App.here.origin();
    var v = $('origin-value');
    var btn = $('origin');
    btn.classList.toggle('is-warn', !o || !!(o && o.fallback));
    if (App.here.mode === 'pick' && App.here.pick) {
      v.textContent = App.here.pick.address === tr('Точка на карте') ? tr('Точка на карте') : tr('Точка · ') + App.here.pick.address;
      btn.querySelector('use').setAttribute('href', '#i-pin');
    } else if (App.here.mode === 'home' && cfg.home) {
      v.textContent = tr('Дом · ') + cfg.home.address;
      btn.querySelector('use').setAttribute('href', '#i-home');
    } else if (App.here.mode === 'work' && cfg.work) {
      v.textContent = tr('Работа · ') + cfg.work.address;
      btn.querySelector('use').setAttribute('href', '#i-work');
    } else if (App.here.gps) {
      var gp = App.here.gps;
      var stale = Date.now() - gp.at > 60000;
      v.textContent = stale ? tr('GPS давно не обновлялся') : gp.acc > 100 ? tr('Я здесь · неточно, ') + gp.acc + tr(' м. Выйдите на открытое место') : tr('Я здесь · точность ') + gp.acc + tr(' м');
      btn.classList.toggle('is-warn', !!(stale || gp.acc > 100));
      btn.querySelector('use').setAttribute('href', '#i-gps');
    } else if (o && o.fallback) {
      v.textContent = (App.here.error || tr('Жду GPS')) + tr(' · пока от дома');
      btn.querySelector('use').setAttribute('href', '#i-home');
    } else {
      v.textContent = App.here.error || tr('Ищу GPS…');
      btn.querySelector('use').setAttribute('href', '#i-gps');
    }
  }

  // ---------- Места ----------
  function cardStatus(trip, now) {
    if (trip.error === 'here') return { st: 'here' };
    var opt = trip.options[0];
    if (!opt && !App.here.origin()) return { st: 'noorigin' };
    if (!opt) {
      if (trip.loading) return { st: 'loading' };
      return { st: trip.error ? 'error' : 'none' };
    }
    // Первый вариант, на который ещё успеваем: «уже не успеть» показываем, только если успеть не на что
    var st = trip.status(opt, now);
    if (st === 'late') {
      for (var i = 1; i < trip.options.length && i < 4; i++) {
        var s2 = trip.status(trip.options[i], now);
        if (s2 !== 'late') { opt = trip.options[i]; st = s2; break; }
      }
    }
    var t = trip.timing(opt, now);
    return { st: st, opt: opt, t: t };
  }

  var cardRefs = {};   // id места -> { el, count, label, pill } — для тика раз в секунду

  function renderPlaces() {
    if (drag.active) { drag.pending = true; return; }   // не перерисовывать список под пальцем
    var box = $('places');
    var focusId = document.activeElement && document.activeElement.getAttribute('data-place');
    clear(box);
    cardRefs = {};
    var favs = App.places.favorites();
    var others = App.places.others();
    var origin = App.here.origin();

    // «Дом» и «Работа» из настроек — такие же карточки с отсчётом, первыми в списке
    var quick = [];
    if (cfg.home) quick.push({ id: 'quick-home', icon: 'home', name: tr('Дом'), address: cfg.home.address, sub: cfg.home.address, lat: cfg.home.lat, lon: cfg.home.lon, temp: true });
    if (cfg.work) quick.push({ id: 'quick-work', icon: 'work', name: tr('Работа'), address: cfg.work.address, sub: cfg.work.address, lat: cfg.work.lat, lon: cfg.work.lon, temp: true });
    if (quick.length) {
      var quickBox = h('div.fav-list.quick-cards', { role: 'group', 'aria-label': tr('Дом и работа') });
      quick.forEach(function (q) { quickBox.appendChild(placeCard(q, origin)); });
      box.appendChild(quickBox);
    }
    if (!favs.length && !others.length && !quick.length) {
      box.appendChild(h('div.empty', null, [
        icon('star', 'empty-ic'),
        h('h2', { text: tr('Добавьте свои места') }),
        h('p', { text: tr('Найдите адрес в поиске сверху: работа, мама, бассейн. Избранные места всегда видны здесь с отсчётом «выходи через».') })
      ]));
      return;
    }

    if (favs.length) {
      box.appendChild(h('h2.section-title', { text: tr('Избранное') }));
      var favBox = h('div.fav-list');
      favs.forEach(function (p) { var c = placeCard(p, origin); favBox.appendChild(c); if (favs.length > 1) makeDraggable(c, favBox); });
      box.appendChild(favBox);
      if (favs.length > 1) box.appendChild(h('p.drag-hint', { text: tr('Чтобы поменять порядок, удерживайте карточку и перетащите') }));
    }
    if (others.length) {
      box.appendChild(h('h2.section-title', { text: tr('Другие места') }));
      var list = h('div.rows');
      others.forEach(function (p) {
        list.appendChild(h('div.row', null, [
          h('button.row-main', { type: 'button', 'data-place': p.id, on: { click: function () { openTrip(p); } } }, [
            h('span.row-ic', null, [icon('pin')]),
            h('span.row-text', null, [h('span.row-name', { text: p.name }), h('span.row-sub', { text: p.address })])
          ]),
          h('button.icon-btn.row-star', { type: 'button', 'aria-label': tr('В избранное: ') + p.name, on: { click: function () { App.places.update(p.id, { fav: true }); toast('«' + p.name + tr('» в избранном')); } } }, [icon('star')])
        ]));
      });
      box.appendChild(list);
    }
    if (focusId) { var f = box.querySelector('[data-place="' + focusId + '"]'); if (f) f.focus({ preventScroll: true }); }
    tickPlaces();
  }

  function placeCard(p, origin) {
    var trip = tripFor(p);
    var pill = h('span.pill');
    var label = h('span.card-label');
    var count = h('span.card-count');
    var line = h('div.card-line');
    var live = h('div.card-live');
    var ride = h('div.card-ride');
    var card = h('button.card', { type: 'button', 'data-place': p.id, on: { click: function () { openTrip(p); } } }, [
      h('div.card-head', null, [
        h('div.card-title', null, [h('span.card-name', null, [p.icon ? icon(p.icon, 'card-kind') : null, p.remind ? icon('bell-on', 'card-bell') : null, p.name]), h('span.card-addr', { text: p.address })]),
        pill,
        h('div.card-when', null, [label, count])
      ]),
      live, ride
    ]);
    cardRefs[p.id] = { el: card, pill: pill, label: label, count: count, line: line, live: live, ride: ride, trip: trip, lineKey: '' };
    if (origin && trip.stale(origin, cfg.listPlanSeconds)) enqueue(trip);
    return card;
  }

  // ---------- Перестановка избранного долгим нажатием ----------
  var drag = { active: false, pending: false, suppressClick: 0 };
  // На телефоне пока карточка «в руке», страница не должна листаться
  document.addEventListener('touchmove', function (e) { if (drag.active && e.cancelable) e.preventDefault(); }, { passive: false });
  function makeDraggable(card, list) {
    var timer = null, sx = 0, sy = 0, pid = null;
    card.addEventListener('contextmenu', function (e) { e.preventDefault(); });
    card.addEventListener('selectstart', function (e) { e.preventDefault(); });
    card.addEventListener('dragstart', function (e) { e.preventDefault(); });
    function down(x, y) {
      sx = x; sy = y;
      clearTimeout(timer);
      timer = setTimeout(function () { start(y); }, 420);
    }
    function over(x, y) {
      if (!drag.active && timer && (Math.abs(x - sx) > 10 || Math.abs(y - sy) > 10)) { clearTimeout(timer); timer = null; }   // это листание
      if (drag.active && drag.card === card) move(y);
    }
    function up(cancelled) { clearTimeout(timer); timer = null; if (drag.active && drag.card === card) finish(cancelled); }

    // Палец: touch-события, а не pointer — Android после долгого нажатия шлёт pointercancel и карточка «срывается»
    card.addEventListener('touchstart', function (e) { if (e.touches.length !== 1) { up(true); return; } down(e.touches[0].clientX, e.touches[0].clientY); }, { passive: true });
    card.addEventListener('touchmove', function (e) {
      var t = e.touches[0];
      if (drag.active && drag.card === card && e.cancelable) e.preventDefault();
      over(t.clientX, t.clientY);
    }, { passive: false });
    card.addEventListener('touchend', function () { up(false); });
    card.addEventListener('touchcancel', function () { up(!(drag.active && drag.card === card && drag.to !== drag.from)); });
    // Мышь (компьютер)
    card.addEventListener('pointerdown', function (e) {
      if (e.pointerType !== 'mouse' || e.button !== 0) return;
      pid = e.pointerId;
      down(e.clientX, e.clientY);
    });
    card.addEventListener('pointermove', function (e) { if (e.pointerType === 'mouse') over(e.clientX, e.clientY); });
    card.addEventListener('pointerup', function (e) { if (e.pointerType === 'mouse') up(false); });
    card.addEventListener('click', function (e) { if (Date.now() < drag.suppressClick) { e.preventDefault(); e.stopImmediatePropagation(); } }, true);

    function start(y) {
      timer = null;
      var cards = Array.prototype.slice.call(list.children);
      drag = { active: true, pending: false, suppressClick: 0, card: card, list: list, cards: cards, startY: y, lastY: y,
        rects: cards.map(function (c) { var r = c.getBoundingClientRect(); return { top: r.top, h: r.height, mid: r.top + r.height / 2 }; }),
        from: cards.indexOf(card), to: cards.indexOf(card), scroller: $('places').closest('.views'), scrolled: 0 };
      drag.scrollStart = drag.scroller ? drag.scroller.scrollTop : 0;
      if (pid !== null) try { card.setPointerCapture(pid); } catch (err) { /* без захвата */ }
      card.classList.add('is-dragging');
      list.classList.add('is-sorting');
      if (navigator.vibrate) try { navigator.vibrate(15); } catch (err) { /* без вибрации */ }
      autoScroll();
    }
    function move(y) {
      drag.lastY = y;
      var scrollDy = (drag.scroller ? drag.scroller.scrollTop : 0) - drag.scrollStart;
      var dy = y - drag.startY + scrollDy;
      card.style.transform = 'translateY(' + dy + 'px) scale(1.02)';
      var r = drag.rects[drag.from];
      var mid = r.mid + dy;
      var to = drag.from;
      drag.rects.forEach(function (o, i) {
        if (i < drag.from && mid < o.mid) to = Math.min(to, i);
        if (i > drag.from && mid > o.mid) to = Math.max(to, i);
      });
      drag.to = to;
      var gap = r.h + 10;   // высота карточки + отступ между ними
      drag.cards.forEach(function (c, i) {
        if (c === card) return;
        var shift = 0;
        if (drag.from < to && i > drag.from && i <= to) shift = -gap;
        if (drag.from > to && i < drag.from && i >= to) shift = gap;
        c.style.transform = shift ? 'translateY(' + shift + 'px)' : '';
      });
    }
    function autoScroll() {
      if (!drag.active || drag.card !== card) return;
      var sc = drag.scroller;
      if (sc) {
        var b = sc.getBoundingClientRect();
        var v = drag.lastY < b.top + 70 ? -8 : drag.lastY > b.bottom - 70 ? 8 : 0;
        if (v) { sc.scrollTop += v; move(drag.lastY); }
      }
      requestAnimationFrame(autoScroll);
    }
    function finish(cancelled) {
      var d = drag;
      d.cards.forEach(function (c) { c.style.transform = ''; });
      card.classList.remove('is-dragging');
      d.list.classList.remove('is-sorting');
      drag = { active: false, pending: false, suppressClick: Date.now() + 400 };
      if (!cancelled && d.to !== d.from) {
        var ids = d.cards.map(function (c) { return c.getAttribute('data-place'); });
        var moved = ids.splice(d.from, 1)[0];
        ids.splice(d.to, 0, moved);
        App.places.reorderFav(ids);   // перерисует список
        toast(tr('Порядок сохранён'));
      } else if (d.pending) renderPlaces();
    }
  }

  function tickPlaces() {
    var now = Date.now();
    Object.keys(cardRefs).forEach(function (id) {
      var r = cardRefs[id];
      var s = cardStatus(r.trip, now);
      r.el.setAttribute('data-status', s.st);
      r.pill.textContent = STATUS[s.st] || '';
      if (!s.opt) {
        r.label.textContent = '';
        r.count.textContent = s.st === 'loading' ? '…' : s.st === 'noorigin' ? tr('жду GPS') : s.st === 'here' ? tr('на месте') : s.st === 'error' ? tr('нет связи') : tr('рейсов нет');
        r.count.classList.add('is-word');
        if (r.lineKey !== s.st) { clear(r.line); clear(r.live); clear(r.ride); r.lineKey = s.st; }
        if (s.st === 'error') r.live.textContent = tr('Проверьте интернет, пробую снова');
        return;
      }
      var leftMs = s.t.leaveAt - now;
      if (s.st === 'late') { r.label.textContent = tr('автобус в'); r.count.textContent = T.hm(s.t.busAt); }
      else if (leftMs <= 0) { r.label.textContent = ''; r.count.textContent = tr('сейчас'); }
      else { r.label.textContent = tr('выходи через'); r.count.textContent = (App.here.weak ? '≈ ' : '') + leftText(leftMs); }
      r.count.classList.toggle('is-word', !/^[≈\s]*\d+:\d+/.test(r.count.textContent));
      var ft = s.opt.firstTransit;
      var key = Trip_key(s.opt);
      if (r.lineKey !== key) {
        r.lineKey = key;
        clear(r.ride);
        r.ride.appendChild(h('span.card-ride-top', null, [
          h('span.card-ride-word', { text: tr('Садись на') }),
          lineBadge(ft.mode, ft.line, true),
          h('b.card-ride-to', { text: ft.headsign ? '→ ' + ft.headsign : '' })
        ]));
        r.ride.appendChild(h('span.card-ride-sub', { text: tr('Остановка ') + ft.stopName + ' · ' + s.opt.walkToStopMin + tr(' мин пешком') }));
      }
      r.live.textContent = cardLiveText(s.opt, s.t, leftMs, s.st);
      r.live.classList.toggle('is-gps', !!s.t.gps);
    });
  }
  function Trip_key(o) { return App.Trip.key(o); }

  // Строка под линией: Live / по расписанию · выйти в … · на месте в …
  function cardLiveText(opt, t, leftMs, st) {
    var near = t.near || {};
    var lead = t.gps ? tr('Live') : near.notYet && near.coming ? tr('Едет к конечной') : near.notYet ? tr('Ещё не на линии') : tr('По расписанию');
    var out = lead;
    if (leftMs > 0 && st !== 'late') out += ' · ' + tr('выйти в ') + T.hm(t.leaveAt);
    return out + ' · ' + tr('на месте в ') + T.hm(opt.end + Math.max(0, t.busAt - t.sched));
  }
  function liveText(trip, opt, t) {
    var near = t.near || {};
    if (t.gps && near.mine) {
      var where = near.mine.toStop < 150 ? tr('уже у остановки') : km(near.mine.toStop) + tr(' до остановки');
      return tr('GPS: автобус ') + where + tr(', будет ~') + T.hm(t.busAt);
    }
    if (near.notYet && near.coming) return tr('Едет к конечной и развернётся · по расписанию ') + T.hm(t.sched);
    if (near.notYet) return tr('Ещё не вышел на линию · по расписанию ') + T.hm(t.sched);
    if (!App.feed.ok) return tr('По расписанию: ') + T.hm(t.sched);
    return tr('Нет GPS по рейсу · по расписанию ') + T.hm(t.sched);
  }

  // ---------- Поиск ----------
  var searchTimer = null;
  var searchSeq = 0;
  function renderSuggest(list, q) {
    var box = $('suggest');
    clear(box);
    if (!q) { box.classList.add('is-hidden'); return; }
    box.classList.remove('is-hidden');
    if (list === null) { box.appendChild(h('div.suggest-note', { text: tr('Ищу адрес…') })); return; }
    if (!list.length) { box.appendChild(h('div.suggest-note', { text: tr('Не нашла такой адрес. Попробуйте «улица номер» или выберите на карте.') })); box.appendChild(mapSuggestItem()); return; }
    list.forEach(function (a) {
      var street = a.kind === 'street';
      var ic = a.kind === 'place' ? 'flag' : a.kind === 'stop' ? 'bus' : street ? 'road' : 'pin';
      box.appendChild(h('button.suggest-item' + (street ? '.is-street' : '') + (a.kind === 'stop' ? '.is-stop' : ''), { type: 'button', role: 'option', on: {
        mousedown: function (e) { if (street) e.preventDefault(); },   // не терять клавиатуру
        click: function () { if (street) fillStreet(a); else pickAddress(a); }
      } }, [
        icon(ic), h('span.row-text', null, [
          h('span.row-name', { text: a.kind === 'stop' ? 'Peatus ' + a.address : a.address }),
          h('span.row-sub', { text: street ? tr('Улица · нажмите и допишите номер дома') + (a.sub && !/Tallinn/.test(a.sub) ? ' · ' + a.sub : '') :
            a.kind === 'stop' ? tr('Остановка') + (a.sub ? ' · ' + a.sub : '') : a.sub })
        ])
      ]));
    });
    box.appendChild(mapSuggestItem());
  }
  function mapSuggestItem() {
    return h('button.suggest-item.suggest-map', { type: 'button', on: { click: function () { resetSearch(); pickDestination(); } } }, [
      icon('map'), h('span.row-text', null, [h('span.row-name', { text: tr('Выбрать на карте') })])
    ]);
  }
  // Улица без номера: подставить в строку и дать дописать дом, а не строить маршрут к середине улицы.
  function fillStreet(a) {
    var inp = $('search');
    var city = a.sub && !/Tallinn/.test(a.sub) ? ', ' + a.sub.split(',').pop().trim() : '';
    inp.value = a.address + ' ' + city;
    inp.focus();
    var pos = (a.address + ' ').length;
    try { inp.setSelectionRange(pos, pos); } catch (e) { /* без курсора */ }
    $('search-clear').classList.remove('is-hidden');
    var box = $('suggest');
    clear(box);
    box.classList.remove('is-hidden');
    box.appendChild(h('div.suggest-note', { text: tr('Допишите номер дома: например, «') + a.address + ' 5»' }));
  }

  function pickDestination() {
    $('search').blur();
    pickOnMap({ ok: tr('Сюда') }, function (r) { openTrip(tempPlace(r)); });
  }
  // Поиск по строке: адреса (In-ADS), места и остановки (Peatus.ee, OSM). Общий для главного поиска и «Откуда».
  function searchAll(q) {
    var o = App.here.origin();
    var hasNumber = /\d/.test(q);
    return Promise.all([
      App.geocode.suggest(q).catch(function () { return []; }),
      hasNumber ? Promise.resolve([]) : App.geocode.places(q, o).catch(function () { return []; })
    ]).then(function (r) {
      var addrs = r[0].map(function (a) { a.kind = /\d/.test(a.address) ? 'address' : 'street'; return a; });
      if (!hasNumber && r[1].length) {
        // ищут место по названию — оставляем только адреса, где есть набранное слово
        var w = q.toLowerCase().split(/[\s,]+/)[0];
        addrs = addrs.filter(function (x) { return x.address.toLowerCase().indexOf(w) >= 0; });
      }
      // С номером — только дома, чей номер начинается с набранного («6» → 6, 6a, 61), без самой улицы.
      if (hasNumber) {
        var num = (q.match(/\d+[a-zA-Z]?/) || [''])[0].toLowerCase();
        var houses = addrs.filter(function (x) {
          if (x.kind === 'street') return false;
          var m = x.address.toLowerCase().match(/\s(\d+[a-z]?)(\/\d+)?$/);
          return m && m[1].indexOf(num) === 0;
        });
        if (houses.length) addrs = houses;
        else addrs = addrs.filter(function (x) { return x.kind !== 'street'; });
      }
      // Без номера дома — только сама улица (по одной на город), без списка её домов.
      if (!hasNumber) {
        var streets = addrs.filter(function (x) { return x.kind === 'street'; });
        var seenSt = {};
        streets = streets.filter(function (x) { var k = x.address + '|' + x.sub; if (seenSt[k]) return false; seenSt[k] = true; return true; });
        addrs = streets.length ? streets : addrs.slice(0, 3);
      }
      // есть номер дома — адреса первыми; нет — улицы, потом места («Kristiine keskus») и остановки
      var list = hasNumber ? addrs : addrs.slice(0, 3).concat(r[1].slice(0, 4));
      if (!list.length && r[0] === undefined) throw new Error(tr('нет ответа'));
      return list;
    });
  }
  function onSearch() {
    var q = $('search').value.trim();
    $('search-clear').classList.toggle('is-hidden', !q);
    clearTimeout(searchTimer);
    if (!q && document.activeElement === $('search')) { renderRecent(); return; }
    if (q.length < 3) { renderSuggest([], q.length ? q : ''); if (q.length) renderSuggest(null, q); if (q.length && q.length < 3) { clear($('suggest')); $('suggest').appendChild(h('div.suggest-note', { text: tr('Ещё пару букв…') })); } return; }
    renderSuggest(null, q);
    var seq = ++searchSeq;
    searchTimer = setTimeout(function () {
      searchAll(q).then(function (list) { if (seq === searchSeq) renderSuggest(list, q); })
        .catch(function () { if (seq === searchSeq) { clear($('suggest')); $('suggest').appendChild(h('div.suggest-note.is-error', { text: tr('Адресный сервис не отвечает. Проверьте интернет.') })); } });
    }, 280);
  }
  // ---------- Недавние адреса (то, что искали, но не сохранили) ----------
  function recentList() {
    try { var l = JSON.parse(localStorage.getItem('pv.recent') || '[]'); return Array.isArray(l) ? l : []; } catch (e) { return []; }
  }
  function addRecent(a) {
    if (!a || !a.address || a.address === tr('Точка на карте')) return;
    var l = recentList().filter(function (x) { return !(x.address === a.address && (x.sub || '') === (a.sub || '')); });
    l.unshift({ address: a.address, sub: a.sub || '', lat: a.lat, lon: a.lon });
    try { localStorage.setItem('pv.recent', JSON.stringify(l.slice(0, 6))); } catch (e) { /* без памяти */ }
  }
  function renderRecent() {
    var box = $('suggest');
    var saved = App.places.all();
    var l = recentList().filter(function (r) {   // уже сохранённые места не повторяем
      return !saved.some(function (p) { return App.vehicles.dist(p.lat, p.lon, r.lat, r.lon) < 30; });
    });
    clear(box);
    box.classList.remove('is-hidden');
    if (l.length) {
      box.appendChild(h('div.suggest-head', null, [h('span', { text: tr('Недавние') }), h('button.suggest-clear-all', { type: 'button', on: { mousedown: function (e) { e.preventDefault(); }, click: function () {
        try { localStorage.removeItem('pv.recent'); } catch (e) { /* без памяти */ }
        renderRecent();
      } } }, [h('span', { text: tr('Очистить') })])]));
      l.forEach(function (a) {
        box.appendChild(h('button.suggest-item', { type: 'button', on: { mousedown: function (e) { e.preventDefault(); }, click: function () { pickAddress(a); } } }, [
          icon('clock'), h('span.row-text', null, [h('span.row-name', { text: a.address }), h('span.row-sub', { text: a.sub })])
        ]));
      });
    }
    var m = mapSuggestItem();
    m.addEventListener('mousedown', function (e) { e.preventDefault(); });
    box.appendChild(m);
  }

  function resetSearch() {
    $('search').value = '';
    $('search-clear').classList.add('is-hidden');
    renderSuggest([], '');
  }

  function pickAddress(a) {
    resetSearch();
    $('search').blur();
    openTrip(tempPlace(a));
  }
  // Место без сохранения: просто посмотреть маршруты. Сохранить можно кнопкой на экране поездки.
  function tempPlace(a) {
    addRecent(a);
    return { id: 'tmp-' + Date.now(), name: a.address, address: a.sub || '', sub: a.sub || '', lat: a.lat, lon: a.lon, temp: true };
  }

  // ---------- Выбор точки на карте (как в такси: двигаешь карту, булавка в центре) ----------
  var picker = { view: null, cb: null, seq: 0, timer: null, result: null, open: false };
  function pickOnMap(opts, cb) {
    // opts: { title: 'Куда' | 'Откуда' | 'Дом', ok: 'Сюда', at: {lat, lon} }
    var el = $('picker');
    el.classList.remove('is-hidden');
    picker.cb = cb;
    picker.result = null;
    picker.open = true;
    history.pushState({ pv: 'picker' }, '');
    $('picker-ok-text').textContent = opts.ok || tr('Выбрать');
    $('picker-ok').disabled = true;
    if (!picker.view) {
      picker.view = App.mapView.create($('picker-map'));
      var m = picker.view.map;
      m.on('movestart', function () {
        el.classList.add('is-moving');
        $('picker-ok').disabled = true;
        $('picker-title').textContent = tr('Определяю адрес…');
        $('picker-sub').textContent = '';
      });
      m.on('moveend', function () {
        el.classList.remove('is-moving');
        clearTimeout(picker.timer);
        picker.timer = setTimeout(lookupCenter, 250);
      });
    }
    var o = App.here.gps || App.here.origin();
    picker.view.setData({ me: App.here.gps ? { lat: App.here.gps.lat, lon: App.here.gps.lon } : null });
    var at = opts.at || o || { lat: 59.437, lon: 24.7536 };
    setTimeout(function () {
      picker.view.resize();
      picker.view.map.setView([at.lat, at.lon], 17, { animate: false });
      lookupCenter();
    }, 30);
  }
  function lookupCenter() {
    var c = picker.view.map.getCenter();
    var seq = ++picker.seq;
    var point = { lat: c.lat, lon: c.lng };
    App.geocode.reverse(c.lat, c.lng).then(function (a) {
      if (seq !== picker.seq) return;
      if (a) {
        picker.result = { address: a.address, sub: a.sub, lat: point.lat, lon: point.lon };
        $('picker-title').textContent = (a.far ? tr('Рядом с ') : '') + a.address;
        $('picker-sub').textContent = a.sub;
      } else {
        var name = tr('Точка ') + point.lat.toFixed(5) + ', ' + point.lon.toFixed(5);
        picker.result = { address: tr('Точка на карте'), sub: point.lat.toFixed(5) + ', ' + point.lon.toFixed(5), lat: point.lat, lon: point.lon };
        $('picker-title').textContent = tr('Точка на карте');
        $('picker-sub').textContent = tr('Адреса рядом нет, маршрут посчитаю от самой точки');
      }
      $('picker-ok').disabled = false;
    }).catch(function () {
      if (seq !== picker.seq) return;
      picker.result = { address: tr('Точка на карте'), sub: '', lat: point.lat, lon: point.lon };
      $('picker-title').textContent = tr('Точка на карте');
      $('picker-sub').textContent = tr('Адресный сервис не ответил, но точку выбрать можно');
      $('picker-ok').disabled = false;
    });
  }
  function closePicker(fromPop) {
    if (!picker.open) return;
    picker.open = false;
    $('picker').classList.add('is-hidden');
    if (!fromPop && history.state && history.state.pv === 'picker') silentBack();
  }
  $('picker-back').addEventListener('click', function () { closePicker(); });
  $('picker-me').addEventListener('click', function () {
    var g = App.here.gps;
    if (!g) { App.here.retry(); toast(tr('Ищу GPS…')); return; }
    picker.view.map.setView([g.lat, g.lon], 17, { animate: true });
  });
  $('picker-ok').addEventListener('click', function () {
    if (!picker.result) return;
    var r = picker.result;
    var cb = picker.cb;
    closePicker();
    setTimeout(function () { if (cb) cb(r); }, 80);
  });

  // ---------- Листы (bottom sheet) ----------
  var sheetOpen = false;
  function openSheet(build) {
    var sheet = $('sheet');
    clear(sheet);
    sheet.appendChild(h('div.sheet-grip', { 'aria-hidden': 'true' }));
    build(sheet);
    $('sheet-wrap').classList.remove('is-hidden');
    requestAnimationFrame(function () { $('sheet-wrap').classList.add('is-open'); });
    if (!sheetOpen) { history.pushState({ pv: 'sheet' }, ''); sheetOpen = true; }
    var first = sheet.querySelector('input, button.btn');
    if (first && first.tagName === 'INPUT' && !first.value) setTimeout(function () { first.focus(); }, 220);
  }
  function closeSheet(fromPop) {
    if (!sheetOpen) return;
    sheetOpen = false;
    $('sheet-wrap').classList.remove('is-open');
    setTimeout(function () { if (!sheetOpen) $('sheet-wrap').classList.add('is-hidden'); }, 220);
    if (!fromPop) silentBack();
  }
  $('scrim').addEventListener('click', function () { closeSheet(); });

  function field(labelText, input, help) {
    var id = 'f' + Math.random().toString(36).slice(2, 8);
    input.id = id;
    return h('div.field', null, [h('label', { for: id, text: labelText }), input, help ? h('p.help', { text: help }) : null]);
  }

  // Добавить или изменить место
  function placeSheet(data, existing) {
    openSheet(function (s) {
      var name = h('input', { type: 'text', value: existing ? existing.name : '', placeholder: data.address, autocomplete: 'off', maxlength: '40', enterkeyhint: 'done' });
      var fav = true;   // сохранённое место всегда в избранном; убрать звёздочку = удалить
      s.appendChild(h('h2.sheet-title', { text: existing ? tr('Изменить место') : tr('Новое место') }));
      s.appendChild(h('p.sheet-sub', null, [icon('pin'), h('span', { text: data.address + (data.sub ? ', ' + data.sub : '') })]));
      s.appendChild(field(tr('Название'), name, tr('Как показывать в списке, например «Работа» или «Мама». Можно оставить пустым.')));
      function save() {
        var n = name.value.trim() || data.address;
        var p;
        if (existing) p = App.places.update(existing.id, { name: n, fav: fav });
        else p = App.places.add({ name: n, address: data.address, sub: data.sub, lat: data.lat, lon: data.lon, fav: fav });
        closeSheet();
        if (!existing) setTimeout(function () { openTrip(p); }, 60);
        else if (state.detail && state.detail.place && state.detail.place.id === p.id) { state.detail.place = p; renderDetail(true); }
      }
      name.addEventListener('keydown', function (e) { if (e.key === 'Enter') save(); });
      var actions = h('div.sheet-actions', null, [
        h('button.btn.btn-primary', { type: 'button', on: { click: save } }, [icon('check'), h('span', { text: tr('Сохранить') })]),
        existing ? h('button.btn.btn-danger', { type: 'button', on: { click: function () {
          if (!window.confirm(tr('Удалить «') + existing.name + '»?')) return;
          App.places.remove(existing.id);
          delete state.trips[existing.id];
          if (rideD && rideD.place && rideD.place.id === existing.id) endRide();
          closeSheet();
          closeDetail();
          toast(tr('Место удалено'));
        } } }, [icon('trash'), h('span', { text: tr('Удалить') })])
          : h('button.btn', { type: 'button', on: { click: function () { closeSheet(); } } }, [h('span', { text: tr('Отмена') })])
      ]);
      s.appendChild(actions);
      if (existing) {
        s.appendChild(h('div.sheet-actions.sheet-actions-quiet', null, [
          h('button.btn.btn-quiet', { type: 'button', on: { click: function () { App.places.move(existing.id, -1); toast(tr('Выше в списке')); } } }, [h('span', { text: tr('Выше в списке') })]),
          h('button.btn.btn-quiet', { type: 'button', on: { click: function () { App.places.move(existing.id, 1); toast(tr('Ниже в списке')); } } }, [h('span', { text: tr('Ниже в списке') })])
        ]));
      }
    });
  }

  // Откуда считать
  function originSheet() {
    openSheet(function (s) {
      s.appendChild(h('h2.sheet-title', { text: tr('Откуда считать маршрут') }));
      // Самый частый выбор — первым
      s.appendChild(opt('gps', 'gps', tr('Где я сейчас'), App.here.gps ? tr('GPS телефона, точность ') + App.here.gps.acc + tr(' м') : (App.here.error || tr('GPS телефона'))));
      // Любой адрес, место или остановка — как в главном поиске
      var setFrom = function (a) {
        var name = a.kind === 'stop' ? 'Peatus ' + a.address : a.address;
        App.here.setPick({ address: name, lat: a.lat, lon: a.lon });
        closeSheet();
        toast(tr('Считаю от: ') + name);
      };
      s.appendChild(addressField(tr('Другой адрес'), tr('Адрес, место или остановка'), '', '', 'pin', function (a) { setFrom(a); }));
      // Сохранённые места — одним нажатием
      var saved = App.places.all().slice(0, 4);
      if (saved.length) {
        var row = h('div.from-saved', { role: 'group', 'aria-label': tr('Из сохранённых мест') });
        saved.forEach(function (p) {
          row.appendChild(h('button.from-chip', { type: 'button', on: { click: function () { setFrom({ address: p.name, lat: p.lat, lon: p.lon }); } } }, [icon('pin'), h('span', { text: p.name })]));
        });
        s.appendChild(row);
      }
      function opt(mode, ic, title, sub, disabled) {
        var active = App.here.mode === mode;
        return h('button.choice' + (active ? '.is-active' : ''), { type: 'button', disabled: disabled, 'aria-pressed': String(active), on: { click: function () {
          App.here.setMode(mode);
          if (mode === 'gps') App.here.retry();
          closeSheet();
        } } }, [icon(ic), h('span.row-text', null, [h('span.row-name', { text: title }), h('span.row-sub', { text: sub })]), active ? icon('check', 'choice-check') : null]);
      }
      s.appendChild(opt('home', 'home', tr('Из дома'), cfg.home ? cfg.home.address : tr('Сначала укажите дом в настройках'), !cfg.home));
      s.appendChild(opt('work', 'work', tr('С работы'), cfg.work ? cfg.work.address : tr('Сначала укажите работу в настройках'), !cfg.work));
      var pk = App.here.pick;
      var pickActive = App.here.mode === 'pick' && pk;
      s.appendChild(h('button.choice' + (pickActive ? '.is-active' : ''), { type: 'button', 'aria-pressed': String(!!pickActive), on: { click: function () {
        closeSheet();
        setTimeout(function () {
          pickOnMap({ ok: tr('Отсюда'), at: pk || null }, function (r) {
            App.here.setPick({ address: r.address, lat: r.lat, lon: r.lon });
            toast(tr('Считаю от: ') + r.address);
          });
        }, 240);
      } } }, [icon('pin'), h('span.row-text', null, [h('span.row-name', { text: tr('Точка на карте') }),
        h('span.row-sub', { text: pickActive ? pk.address + tr(' · нажмите, чтобы изменить') : tr('Передвиньте карту под булавку') })]), pickActive ? icon('check', 'choice-check') : null]));
      if (!cfg.home || !cfg.work) s.appendChild(h('button.btn', { type: 'button', on: { click: function () { closeSheet(); setTimeout(settingsSheet, 250); } } }, [icon('gear'), h('span', { text: !cfg.home && !cfg.work ? tr('Указать дом и работу') : !cfg.home ? tr('Указать дом') : tr('Указать работу') })]));
    });
  }

  function stepper(value, min, max, unit, onChange) {
    var out = h('span.stepper-value', { text: value + ' ' + unit });
    function set(v) { value = Math.max(min, Math.min(max, v)); out.textContent = value + ' ' + unit; onChange(value); }
    return h('div.stepper', null, [
      h('button.icon-btn', { type: 'button', 'aria-label': tr('Меньше'), on: { click: function () { set(value - 1); } } }, [h('span.stepper-sign', { text: '−' })]),
      out,
      h('button.icon-btn', { type: 'button', 'aria-label': tr('Больше'), on: { click: function () { set(value + 1); } } }, [icon('plus')])
    ]);
  }

  /*
   * Поле адреса в шторке: подсказки как в главном поиске (адреса, места, остановки), улица — дописать номер.
   * При фокусе поле поднимается к верху шторки, чтобы подсказки не прятались под клавиатурой.
   */
  function addressField(label, placeholder, help, value, ic, onPick) {
    var inp = h('input', { type: 'search', placeholder: placeholder, autocomplete: 'off', autocapitalize: 'words', spellcheck: 'false', value: value || '' });
    var sug = h('div.suggest.suggest-inline.is-hidden', { role: 'listbox', 'aria-label': tr('Найденные адреса') });
    var t = null, seq = 0;
    function note(text) { clear(sug); sug.classList.remove('is-hidden'); sug.appendChild(h('div.suggest-note', { text: text })); }
    function show(list) {
      clear(sug);
      sug.classList.remove('is-hidden');
      list.forEach(function (a) {
        var street = a.kind === 'street';
        sug.appendChild(h('button.suggest-item' + (street ? '.is-street' : '') + (a.kind === 'stop' ? '.is-stop' : ''), { type: 'button', role: 'option', on: {
          mousedown: function (e) { if (street) e.preventDefault(); },
          click: function () {
            if (street) { inp.value = a.address + ' '; inp.focus(); note(tr('Допишите номер дома: например, «') + a.address + ' 5»'); return; }
            sug.classList.add('is-hidden');
            onPick(a, inp);
          }
        } }, [icon(a.kind === 'place' ? 'flag' : a.kind === 'stop' ? 'bus' : street ? 'road' : ic), h('span.row-text', null, [
          h('span.row-name', { text: a.kind === 'stop' ? 'Peatus ' + a.address : a.address }),
          h('span.row-sub', { text: street ? tr('Улица · нажмите и допишите номер дома') : a.kind === 'stop' ? tr('Остановка') + (a.sub ? ' · ' + a.sub : '') : a.sub })
        ])]));
      });
    }
    inp.addEventListener('focus', function () {
      setTimeout(function () { wrap.scrollIntoView({ block: 'start', behavior: 'smooth' }); }, 250);
    });
    inp.addEventListener('input', function () {
      clearTimeout(t);
      var q = inp.value.trim();
      if (!q) { sug.classList.add('is-hidden'); return; }
      if (q.length < 3) { note(tr('Ещё пару букв…')); return; }
      var my = ++seq;
      note(tr('Ищу…'));
      t = setTimeout(function () {
        searchAll(q).then(function (list) {
          if (my !== seq) return;
          if (list.length) show(list); else note(tr('Не нашла. Попробуйте «улица номер» или укажите на карте.'));
        }, function () { if (my === seq) note(tr('Адресный сервис не отвечает. Проверьте интернет.')); });
      }, 280);
    });
    var f = field(label, inp, '');
    var wrap = h('div.addr-field', null, [f, sug, help ? h('p.help', { text: help }) : null]);
    return wrap;
  }

  // ---------- Первая настройка: полноэкранная, по одному вопросу за раз ----------
  // Открывается сама при первом запуске (и по кнопке в настройках). Всё потом меняется в обычных настройках.
  function setupDone() { try { return localStorage.getItem('pv.setupDone') === '1'; } catch (e) { return true; } }
  function finishSetup() { try { localStorage.setItem('pv.setupDone', '1'); localStorage.removeItem('pv.setupStep'); } catch (e) { /* без памяти */ } }
  var onb = { open: false, step: 0, el: null };

  function choiceList(items, current, label, onPick) {
    var box = h('div.onb-choices', { role: 'radiogroup', 'aria-label': label });
    items.forEach(function (it) {
      var b = h('button.onb-choice', { type: 'button', role: 'radio', 'aria-checked': String(it.v === current), on: { click: function () {
        Array.prototype.forEach.call(box.children, function (c) { c.setAttribute('aria-checked', String(c === b)); });
        onPick(it.v, b);
      } } }, [
        it.ic ? h('span.onb-choice-ic', null, [icon(it.ic)]) : null,
        h('span.onb-choice-text', null, [h('span.onb-choice-title', { text: it.t }), it.sub ? h('span.onb-choice-sub', { text: it.sub }) : null]),
        h('span.onb-choice-mark', null, [icon('check')])
      ]);
      box.appendChild(b);
    });
    return box;
  }
  // Кольцо с числом: заполняется по значению (сборы, запас)
  function ringArt(value, max, unit) {
    var R = 70, C = 2 * Math.PI * R;
    var ns = 'http://www.w3.org/2000/svg';
    var svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 180 180'); svg.setAttribute('class', 'onb-ring'); svg.setAttribute('aria-hidden', 'true');
    var bg = document.createElementNS(ns, 'circle'); bg.setAttribute('cx', 90); bg.setAttribute('cy', 90); bg.setAttribute('r', R); bg.setAttribute('class', 'onb-ring-bg');
    var fg = document.createElementNS(ns, 'circle'); fg.setAttribute('cx', 90); fg.setAttribute('cy', 90); fg.setAttribute('r', R); fg.setAttribute('class', 'onb-ring-fg');
    fg.style.strokeDasharray = C; fg.style.strokeDashoffset = C;
    svg.appendChild(bg); svg.appendChild(fg);
    var num = h('b.onb-ring-num', { text: String(value) });
    var wrap = h('div.onb-ring-wrap', null, [svg, h('div.onb-ring-label', null, [num, h('span', { text: unit })])]);
    function set(v) { num.textContent = String(v); fg.style.strokeDashoffset = String(C * (1 - Math.max(0.02, v / max))); }
    requestAnimationFrame(function () { requestAnimationFrame(function () { set(value); }); });
    wrap.set = function (v) { set(v); num.classList.remove('is-pop'); void num.offsetWidth; num.classList.add('is-pop'); };
    return wrap;
  }
  function iconArt(ic, cls) { return h('div.onb-badge' + (cls ? '.' + cls : ''), null, [h('span.onb-badge-ring'), h('span.onb-badge-ring.is-late'), icon(ic)]); }

  var WIZ = [
    { id: 'hello', title: function () { return tr('Добро пожаловать в Kuhu'); },
      help: function () { return tr('Kuhu подсказывает, когда выходить из дома, чтобы успеть на автобус или трамвай, и показывает, где он сейчас едет. Ответьте на пару вопросов — это займёт минуту.'); },
      art: function () {
        return h('div.onb-hello', null, [
          h('div.onb-logo-wrap', null, [h('span.onb-badge-ring'), h('span.onb-badge-ring.is-late'), h('img.onb-logo', { src: 'img/icon.png', alt: '' })]),
          h('div.onb-road', { 'aria-hidden': 'true' }, [h('span.onb-road-line'), h('span.onb-road-bus', null, [icon('bus')]), h('span.onb-road-stop', null, [icon('signpost')])])
        ]);
      } },
    { id: 'lang', title: function () { return 'Язык · Language · Keel'; }, help: function () { return tr('На каком языке показывать приложение?'); },
      art: function () {
        var words = ['Привет', 'Hello', 'Tere'];
        var w = h('span.onb-hi', { text: words[0] });
        var i = 0;
        onb.timer = setInterval(function () { i = (i + 1) % words.length; w.classList.remove('is-in'); void w.offsetWidth; w.textContent = words[i]; w.classList.add('is-in'); }, 1600);
        return h('div.onb-hi-wrap', null, [w]);
      },
      body: function (s) {
        s.appendChild(choiceList([{ v: 'ru', t: 'Русский' }, { v: 'en', t: 'English' }, { v: 'et', t: 'Eesti' }], App.i18n.lang, 'Language', function (v) {
          if (v === App.i18n.lang) return;
          try { localStorage.setItem('pv.setupStep', '2'); } catch (e) { /* без памяти */ }
          setTimeout(function () { App.i18n.set(v); }, 250);   // перезагрузит приложение и откроет следующий шаг
        }));
      } },
    { id: 'home', title: function () { return tr('Где ваш дом?'); }, help: function () { return tr('Чтобы считать дорогу «из дома» и сразу видеть, когда выходить домой.'); },
      art: function () { return iconArt('home', cfg.home ? 'is-set' : ''); }, body: function (s, step, art) { wizAddress(s, 'home', step, art); } },
    { id: 'work', title: function () { return tr('Где вы работаете или учитесь?'); }, help: function () { return tr('Карточка «Работа» появится на главном экране с отсчётом «выходи через».'); },
      art: function () { return iconArt('work', cfg.work ? 'is-set' : ''); }, body: function (s, step, art) { wizAddress(s, 'work', step, art); } },
    { id: 'walk', title: function () { return tr('Как вы ходите?'); }, help: function () { return tr('От этого зависит, сколько минут идти до остановки.'); },
      art: function () {
        var man = h('span.onb-walker', null, [icon('walk')]);
        var track = h('div.onb-track', { 'aria-hidden': 'true' }, [h('span.onb-track-line'), man, h('span.onb-track-end', null, [icon('signpost')])]);
        track.speed = function (f) { track.style.setProperty('--walk-dur', (f >= 1.35 ? 3.4 : f >= 1.15 ? 2.4 : 1.5) + 's'); };
        track.speed(cfg.walkFactor);
        return track;
      },
      body: function (s, step, art) {
        s.appendChild(choiceList([
          { v: 1.4, t: tr('Не спеша'), sub: tr('с детьми, с сумками') },
          { v: 1.2, t: tr('Обычно') },
          { v: 1.0, t: tr('Быстро'), sub: tr('широким шагом') }
        ], [1.4, 1.2, 1.0].filter(function (v) { return Math.abs(cfg.walkFactor - v) < 0.01; })[0], tr('Скорость ходьбы'), function (v) { App.settings.save({ walkFactor: v }); art.speed(v); }));
      } },
    { id: 'prep', title: function () { return tr('Сколько минут на сборы?'); }, help: function () { return tr('Обуться, одеться, дождаться лифта. Напомним выходить с учётом этого времени.'); },
      art: function () { return ringArt(cfg.prepMinutes, 20, tr('мин')); },
      body: function (s, step, art) { s.appendChild(h('div.onb-stepper', null, [stepper(cfg.prepMinutes, 0, 20, tr('мин'), function (v) { App.settings.save({ prepMinutes: v }); art.set(v); })])); } },
    { id: 'buffer', title: function () { return tr('Какой запас оставить?'); }, help: function () { return tr('На сколько минут раньше прийти на остановку, чтобы не бежать. Обычно 2–3 минуты.'); },
      art: function () { return ringArt(cfg.bufferMinutes, 15, tr('мин')); },
      body: function (s, step, art) { s.appendChild(h('div.onb-stepper', null, [stepper(cfg.bufferMinutes, 0, 15, tr('мин'), function (v) { App.settings.save({ bufferMinutes: v }); art.set(v); })])); } },
    { id: 'theme', title: function () { return tr('Светлая или тёмная тема?'); }, help: function () { return tr('Можно оставить как в телефоне — тогда тема меняется вместе с ним.'); },
      art: function () {
        return h('div.onb-phone', { 'aria-hidden': 'true' }, [
          h('span.onb-phone-bar'),
          h('span.onb-phone-card.is-soon', null, [h('i'), h('b', { text: '3:48' })]),
          h('span.onb-phone-card', null, [h('i'), h('b', { text: '12' })]),
          h('span.onb-phone-tabs')
        ]);
      },
      body: function (s) {
        s.appendChild(choiceList([{ v: 'auto', t: tr('Как в телефоне'), ic: 'gear' }, { v: 'light', t: tr('Светлая'), ic: 'star' }, { v: 'dark', t: tr('Тёмная'), ic: 'moon' }], cfg.theme, tr('Тема'), function (v) { App.settings.save({ theme: v }); }));
      } }
  ];

  function wizAddress(s, key, step, art) {
    var save = function (a) {
      var patch = {};
      patch[key] = { address: a.kind === 'stop' ? 'Peatus ' + a.address : a.address, lat: a.lat, lon: a.lon };
      App.settings.save(patch);
      renderOrigin(); renderPlaces();
    };
    var label = key === 'home' ? tr('Адрес дома') : tr('Адрес работы');
    var done = h('p.onb-saved' + (cfg[key] ? '' : '.is-hidden'), null, [icon('check'), h('span', { text: cfg[key] ? cfg[key].address : '' })]);
    var af = addressField(label, tr('Начните вводить адрес'), '', cfg[key] ? cfg[key].address : '', key, function (a, inp) {
      save(a); inp.value = cfg[key].address; inp.blur();
      done.lastChild.textContent = cfg[key].address; done.classList.remove('is-hidden');
      if (art) { art.classList.remove('is-set'); void art.offsetWidth; art.classList.add('is-set'); }
      var nxt = onb.el && onb.el.querySelector('.onb-next span'); if (nxt) nxt.textContent = tr('Далее');
    });
    s.appendChild(af);
    s.appendChild(h('div.onb-row', null, [
      h('button.btn.btn-small', { type: 'button', on: { click: function () {
        onb.el.classList.add('is-hidden');
        pickOnMap({ ok: key === 'home' ? tr('Это мой дом') : tr('Это моя работа'), at: cfg[key] || null }, function (r) { save(r); });
        // окно выбора на карте закрылось (выбрали или передумали) — вернуться к этому же шагу
        var mo = new MutationObserver(function () {
          if (!$('picker').classList.contains('is-hidden')) return;
          mo.disconnect();
          setupWizard(step, 0);
        });
        mo.observe($('picker'), { attributes: true, attributeFilter: ['class'] });
      } } }, [icon('pin'), h('span', { text: tr('Выбрать на карте') })])
    ]));
    s.appendChild(done);
  }

  function closeOnb() {
    if (!onb.el) return;
    clearInterval(onb.timer);
    var el = onb.el;
    el.classList.add('is-leaving');
    onb.open = false; onb.el = null;
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 260);
  }

  // dir: 1 — вперёд (новое въезжает справа), -1 — назад (слева), 0 — без сдвига
  function setupWizard(step, dir) {
    step = Math.max(0, Math.min(step || 0, WIZ.length));
    if (dir === undefined) dir = 1;
    clearInterval(onb.timer);
    if (sheetOpen) closeSheet();
    try { localStorage.setItem('pv.setupStep', String(step)); } catch (e) { /* без памяти */ }
    var first = !onb.el;
    if (first) {
      onb.el = h('div.onb', { role: 'dialog', 'aria-modal': 'true', 'aria-label': tr('Настройка') });
      document.body.appendChild(onb.el);
    }
    onb.open = true; onb.step = step;
    onb.el.classList.remove('is-hidden');
    var el = onb.el;
    clear(el);

    if (step === WIZ.length) {
      finishSetup();
      el.appendChild(h('div.onb-stage.onb-final', null, [
        h('div.onb-art', null, [h('div.onb-done', null, [h('span.onb-burst'), h('span.onb-done-circle', null, [icon('check')])])]),
        h('h1.onb-title', { text: tr('Готово!') }),
        h('p.onb-help', { text: tr('Всё это можно поменять в любой момент: значок шестерёнки сверху справа.') })
      ]));
      el.appendChild(h('div.onb-foot', null, [
        h('button.btn.btn-primary.onb-next', { type: 'button', on: { click: function () { closeOnb(); refreshAllPlans(); } } }, [h('span', { text: tr('Начать') })])
      ]));
      return;
    }
    var w = WIZ[step];
    var bar = h('div.onb-progress', { role: 'progressbar', 'aria-valuemin': '1', 'aria-valuemax': String(WIZ.length), 'aria-valuenow': String(step + 1), 'aria-label': tr('Шаг ') + (step + 1) + tr(' из ') + WIZ.length });
    WIZ.forEach(function (x, i) { bar.appendChild(h('span.onb-seg' + (i < step ? '.is-done' : i === step ? '.is-now' : ''))); });
    el.appendChild(h('div.onb-top', null, [
      bar,
      h('button.onb-skip', { type: 'button', text: tr('Пропустить'), on: { click: function () { finishSetup(); closeOnb(); refreshAllPlans(); } } })
    ]));
    var art = w.art ? w.art() : null;
    var stage = h('div.onb-stage' + (dir > 0 ? '.from-right' : dir < 0 ? '.from-left' : ''), null, [
      art ? h('div.onb-art', null, [art]) : null,
      h('p.onb-step', { text: tr('Шаг ') + (step + 1) + tr(' из ') + WIZ.length }),
      h('h1.onb-title', { text: w.title() }),
      h('p.onb-help', { text: w.help() })
    ]);
    var body = h('div.onb-body');
    if (w.body) w.body(body, step, art);
    stage.appendChild(body);
    el.appendChild(stage);
    var optional = w.id === 'home' || w.id === 'work';
    var answered = !optional || !!cfg[w.id];
    el.appendChild(h('div.onb-foot', null, [
      step > 0 ? h('button.onb-back', { type: 'button', 'aria-label': tr('Назад'), on: { click: function () { setupWizard(step - 1, -1); } } }, [icon('back')]) : null,
      h('button.btn.btn-primary.onb-next', { type: 'button', on: { click: function () { setupWizard(step + 1, 1); } } }, [
        h('span', { text: w.id === 'hello' ? tr('Начать настройку') : answered ? tr('Далее') : tr('Пропустить') })
      ])
    ]));
    if (first) el.classList.add('is-entering');
  }
  // Первый запуск — сразу приветствие; после смены языка (перезагрузка) — продолжаем с того же шага
  function resumeSetup() {
    var st = null;
    try { st = localStorage.getItem('pv.setupStep'); } catch (e) { /* без памяти */ }
    if (!setupDone()) setTimeout(function () { setupWizard(st !== null ? parseInt(st, 10) || 0 : 0, 0); }, 300);
  }

  function settingsSheet() {
    if (!setupDone()) { setupWizard(0, 0); return; }
    openSheet(function (s) {
      s.appendChild(h('h2.sheet-title', { text: tr('Настройки') }));

      // Дом и работа — с подсказками адресов, мест и остановок
      [['home', tr('Дом'), tr('Начните вводить адрес'), tr('Чтобы считать «из дома» и быстро ехать домой.'), tr('Это мой дом'), tr('Дом')],
       ['work', tr('Работа'), tr('Начните вводить адрес'), tr('Кнопка «На работу» в «Местах» и «с работы» в «Откуда».'), tr('Это моя работа'), tr('Работа')]].forEach(function (k) {
        var key = k[0];
        var save = function (a) {
          var patch = {};
          patch[key] = { address: a.kind === 'stop' ? 'Peatus ' + a.address : a.address, lat: a.lat, lon: a.lon };
          App.settings.save(patch);
          toast(k[5] + ': ' + patch[key].address);
          renderOrigin();
          renderPlaces();
        };
        var af = addressField(k[1], k[2], k[3], cfg[key] ? cfg[key].address : '', key === 'home' ? 'home' : 'work', function (a, inp) { save(a); inp.value = cfg[key].address; inp.blur(); });
        s.appendChild(af);
        var row = h('div.addr-actions', null, [
          h('button.btn.btn-small', { type: 'button', on: { click: function () {
            closeSheet();
            setTimeout(function () {
              pickOnMap({ ok: k[4], at: cfg[key] || null }, function (r) { save(r); });
            }, 240);
          } } }, [icon('pin'), h('span', { text: tr('На карте') })]),
          cfg[key] ? h('button.btn.btn-small.btn-quiet', { type: 'button', on: { click: function () {
            var patch = {}; patch[key] = null; App.settings.save(patch);
            if (App.here.mode === key) App.here.setMode('gps');
            toast(k[5] + tr(' убран') + (key === 'work' ? tr('а') : ''));
            renderOrigin(); renderPlaces(); closeSheet(); setTimeout(settingsSheet, 250);
          } } }, [icon('trash'), h('span', { text: tr('Убрать') })]) : null
        ]);
        s.appendChild(row);
      });

      s.appendChild(h('div.set-row', null, [
        h('div.row-text', null, [h('span.row-name', { text: tr('Запас') }), h('span.row-sub', { text: tr('Выйти раньше, чем впритык') })]),
        stepper(cfg.bufferMinutes, 0, 15, tr('мин'), function (v) { App.settings.save({ bufferMinutes: v }); })
      ]));
      s.appendChild(h('div.set-row', null, [
        h('div.row-text', null, [h('span.row-name', { text: tr('Сборы') }), h('span.row-sub', { text: tr('Обуться, одеться, лифт') })]),
        stepper(cfg.prepMinutes, 0, 20, tr('мин'), function (v) { App.settings.save({ prepMinutes: v }); })
      ]));

      var speeds = [{ v: 1.4, t: tr('Не спеша') }, { v: 1.2, t: tr('Обычно') }, { v: 1.0, t: tr('Быстро') }];
      var seg = h('div.segmented', { role: 'radiogroup', 'aria-label': tr('Скорость ходьбы') });
      speeds.forEach(function (sp) {
        var b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(Math.abs(cfg.walkFactor - sp.v) < 0.01), text: sp.t, on: { click: function () {
          App.settings.save({ walkFactor: sp.v });
          Array.prototype.forEach.call(seg.children, function (c) { c.setAttribute('aria-checked', String(c === b)); });
        } } });
        seg.appendChild(b);
      });
      s.appendChild(h('div.field', null, [h('span.label', { text: tr('Как я хожу') }), seg]));

      // Маршруты только по городу: без автобусов других перевозчиков и поездов (по умолчанию выключено)
      var icSw = h('button.switch', { type: 'button', role: 'switch', 'aria-checked': String(!!cfg.noIntercity), 'aria-label': tr('Без междугороднего транспорта'), on: { click: function () {
        var v = !(App.config.noIntercity === true);
        App.settings.save({ noIntercity: v });
        icSw.setAttribute('aria-checked', String(v));
        // сразу пересчитываем маршруты с новым правилом
        Object.keys(state.trips).forEach(function (k) {
          var tr0 = state.trips[k];
          tr0.planAt = 0;
          if (v) tr0.options = tr0.options.filter(function (o) { return !App.isIntercity(o); });
        });
        renderPlaces();
        if (state.detail && state.detail.kind === 'trip') renderDetail(true);
      } } }, [h('span.switch-knob')]);
      s.appendChild(h('div.set-row', null, [
        h('div.row-text', null, [h('span.row-name', { text: tr('Без междугороднего транспорта') }), h('span.row-sub', { text: tr('Только городской транспорт Таллинна') })]),
        icSw
      ]));

      var themes = [{ v: 'auto', t: tr('Как в телефоне') }, { v: 'light', t: tr('Светлая') }, { v: 'dark', t: tr('Тёмная') }];
      var tseg = h('div.segmented', { role: 'radiogroup', 'aria-label': tr('Тема') });
      themes.forEach(function (th) {
        var b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(cfg.theme === th.v), text: th.t, on: { click: function () {
          App.settings.save({ theme: th.v });
          Array.prototype.forEach.call(tseg.children, function (c) { c.setAttribute('aria-checked', String(c === b)); });
        } } });
        tseg.appendChild(b);
      });
      s.appendChild(h('div.field', null, [h('span.label', { text: tr('Тема') }), tseg]));

      var langs = [{ v: 'ru', t: 'Русский' }, { v: 'en', t: 'English' }, { v: 'et', t: 'Eesti' }];
      var lseg = h('div.segmented', { role: 'radiogroup', 'aria-label': tr('Язык') });
      langs.forEach(function (lg) {
        var b = h('button', { type: 'button', role: 'radio', 'aria-checked': String(App.i18n.lang === lg.v), text: lg.t, on: { click: function () {
          if (App.i18n.lang !== lg.v) App.i18n.set(lg.v);
        } } });
        lseg.appendChild(b);
      });
      s.appendChild(h('div.field', null, [h('span.label', { text: tr('Язык') + ' / Language' }), lseg]));

      if (App.native.hasWidget) s.appendChild(h('p.help', { text: tr('Виджет: удерживайте палец на пустом месте главного экрана → Виджеты → Kuhu. Он показывает 3 первых места из избранного.') }));
      if (App.update.mine()) {
        var verSub = h('span.row-sub', { text: tr('Сборка ') + App.update.mine() });
        var verBtn = h('button.btn.btn-small', { type: 'button', on: { click: function () {
          verBtn.disabled = true;
          verSub.textContent = tr('Проверяю…');
          App.update.check({ force: true }).then(function (r) {
            verBtn.disabled = false;
            if (r.state === 'new') { closeSheet(); setTimeout(function () { updateSheet(r.latest); }, 250); return; }
            verSub.textContent = tr('Сборка ') + App.update.mine() + tr(' — это последняя версия');
          }).catch(function () {
            verBtn.disabled = false;
            verSub.textContent = tr('Не получилось проверить: нет интернета?');
          });
        } } }, [icon('refresh'), h('span', { text: tr('Проверить') })]);
        s.appendChild(h('div.set-row', null, [
          h('div.row-text', null, [h('span.row-name', { text: tr('Обновления') }), verSub]),
          verBtn
        ]));
      }
      s.appendChild(h('button.btn.btn-quiet', { type: 'button', on: { click: function () {
        try { localStorage.removeItem('pv.setupDone'); } catch (e) { /* без памяти */ }
        closeSheet(); setTimeout(function () { setupWizard(0, 0); }, 250);
      } } }, [icon('refresh'), h('span', { text: tr('Пройти настройку заново') })]));
      s.appendChild(h('p.about', { text: tr('Маршруты и расписание: Peatus.ee. Автобусы в реальном времени: transport.tallinn.ee (GPS). Адреса: In-ADS, Maa- ja Ruumiamet. Время прибытия по GPS — оценка по расстоянию (~20 км/ч).') }));
      s.appendChild(h('button.btn.btn-primary', { type: 'button', on: { click: function () { closeSheet(); refreshAllPlans(); } } }, [icon('check'), h('span', { text: tr('Готово') })]));
    });
  }

  // Окно «Вышла новая версия»: что нового и как поставить
  function updateSheet(latest) {
    openSheet(function (s) {
      s.appendChild(h('h2.sheet-title', { text: tr('Вышла новая версия') }));
      s.appendChild(h('p.help', { text: tr('Сборка ') + latest.build + tr(' (у вас ') + App.update.mine() + tr('). Места и настройки сохранятся.') }));
      if (latest.notes.length) {
        var ul = h('ul.upd-notes');
        latest.notes.forEach(function (n) { ul.appendChild(h('li', { text: n })); });
        s.appendChild(ul);
      }
      var msg = h('p.help', { text: latest.ota
        ? tr('Обновление маленькое: скачается само, и приложение перезапустится. Ничего устанавливать не нужно.')
        : tr('Нажмите «Скачать»: файл загрузится через браузер. Потом откройте его (из уведомления или из «Загрузок») и нажмите «Обновить». Если телефон спросит разрешение — разрешите установку из этого источника.') });
      s.appendChild(msg);
      var go = h('button.btn.btn-primary', { type: 'button', on: { click: function () {
        if (!latest.ota) { App.update.download(latest); return; }
        go.disabled = true;
        msg.textContent = tr('Загружаю обновление…');
        App.update.apply(latest).catch(function (err) {
          // не вышло по воздуху — обычный способ через APK
          latest.ota = false;
          go.disabled = false;
          msg.textContent = tr('Не получилось обновить по воздуху. Скачайте файл и установите его вручную.') + (err && err.message ? ' (' + err.message + ')' : '');
          go.lastChild.textContent = tr('Скачать обновление');
        });
      } } }, [icon('download'), h('span', { text: latest.ota ? tr('Обновить') : tr('Скачать обновление') })]);
      s.appendChild(go);
      s.appendChild(h('button.btn.btn-quiet', { type: 'button', on: { click: function () { App.update.snooze(latest.build); closeSheet(); } } }, [h('span', { text: tr('Позже') })]));
    });
  }
  // Фоновая проверка: на старте и когда возвращаешься в приложение (не чаще раза в несколько часов)
  function autoCheckUpdate() {
    if (sheetOpen || picker.open) return;
    App.update.check().then(function (r) {
      if (r.state === 'new' && !sheetOpen && !picker.open) updateSheet(r.latest);
    });
  }

  function refreshAllPlans() {
    Object.keys(state.trips).forEach(function (k) { state.trips[k].planAt = 0; state.trips[k].est = {}; });
    renderPlaces();
    if (state.detail) renderDetail(true);
  }

  // ---------- Тосты ----------
  var toastTimer = null;
  // action: { label, fn } — кнопка в подсказке (например «Вернуть»)
  function toast(text, action) {
    var t = $('toast');
    clear(t);
    t.appendChild(h('span', { text: text }));
    if (action) t.appendChild(h('button.toast-btn', { type: 'button', text: action.label, on: { click: function () { t.classList.add('is-hidden'); action.fn(); } } }));
    t.classList.toggle('has-action', !!action);
    t.classList.remove('is-hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.add('is-hidden'); }, action ? 5000 : 2600);
  }

  // ---------- Деталь: поездка или остановка ----------
  var mapView = null;
  function ensureMap() {
    if (!mapView) mapView = App.mapView.create($('map'));
    return mapView;
  }

  function showDetail() {
    $('detail-empty').classList.add('is-hidden');
    $('detail-body').classList.remove('is-hidden');
    appEl.classList.add('has-detail');
    if (!isSplit() && !history.state) history.pushState({ pv: 'detail' }, '');
    else if (!isSplit() && history.state && history.state.pv !== 'detail') history.pushState({ pv: 'detail' }, '');
    $('detail-scroll').scrollTop = 0;
    setTimeout(function () { ensureMap().resize(); if (mapView) mapView.recenter(); if (live.view) live.view.resize(); }, 260);
  }
  function closeDetail(fromPop) {
    var was = !!state.detail;
    var lv = function (x) { return x && x.kind === 'line' ? (x.stop ? 1 : 0) + (x.trip ? 1 : 0) : 0; };
    var levels = lv(state.detail) + (state.prevDetail ? 1 + lv(state.prevDetail) : 0);
    var wasRide = was && rideD && state.detail === rideD && rideD.riding;
    state.detail = null;
    state.prevDetail = null;
    appEl.classList.remove('has-detail');
    $('detail-body').classList.add('is-hidden');
    $('detail-empty').classList.remove('is-hidden');
    if (was && !fromPop && !isSplit() && history.state && history.state.pv === 'tt') { silentPops++; history.go(-(levels + 1)); }
    else if (was && !fromPop && !isSplit() && history.state && history.state.pv === 'detail') silentBack();
    Array.prototype.forEach.call(document.querySelectorAll('.is-current'), function (e) { e.classList.remove('is-current'); });
    if (live.view && state.tab === 'map') setTimeout(function () { live.view.resize(); }, 30);
    if (wasRide && !rideHint) { rideHint = true; toast(tr('Поездка продолжается: нажмите кружок, чтобы вернуться')); }
    updateRideFab();
  }
  $('detail-back').addEventListener('click', function () { if (!stackBack() && !lineStopBack()) closeDetail(); });

  // Своё закрытие (крестик, «Готово») убирает запись истории — этот popstate не должен закрывать ещё что-то.
  var silentPops = 0;
  function silentBack() { silentPops++; history.back(); }
  window.addEventListener('popstate', function () {
    if (silentPops > 0) { silentPops--; return; }
    if (picker.open) { closePicker(true); return; }
    if (sheetOpen) { closeSheet(true); return; }
    if (state.prevDetail && state.detail && !isSplit()) { stackBack(true); return; }
    if (state.detail && state.detail.kind === 'line' && (state.detail.stop || state.detail.trip) && !isSplit()) { lineStopBack(true); return; }
    if (state.detail && !isSplit()) closeDetail(true);
  });

  function openTrip(place) {
    if (rideD && rideD.riding && App.ride.active() && rideD.place && rideD.place.id === place.id) { resumeRide(); return; }
    state.prevDetail = null;
    var trip = tripFor(place);
    state.detail = { kind: 'trip', trip: trip, place: place, selected: 0, key: '' };
    markCurrent('[data-place="' + place.id + '"]');
    renderDetail(true);
    showDetail();
    var origin = App.here.origin();
    if (origin && (trip.stale(origin, cfg.planSeconds) || !Object.keys(trip.stops).length)) {
      trip.planAt = Math.min(trip.planAt, Date.now() - cfg.planSeconds * 1000);
      trip.refresh(origin, { withStops: true }).then(function () { renderDetail(true); renderPlaces(); });
    }
  }
  function openStop(stop, dirId) {
    state.prevDetail = null;
    state.detail = { kind: 'stop', stop: stop, key: '', lineFilter: null, dirFilter: dirId || null, sel: null };
    markCurrent('[data-stop="' + stop.id + '"]');
    renderDetail(true);
    showDetail();
  }
  function markCurrent(sel) {
    Array.prototype.forEach.call(document.querySelectorAll('.is-current'), function (e) { e.classList.remove('is-current'); });
    var el = document.querySelector(sel);
    if (el) el.classList.add('is-current');
  }

  function fact(ic, label, value, cls) {
    return h('div.fact' + (cls ? '.' + cls : ''), null, [icon(ic), h('span.fact-label', { text: label }), h('span.fact-value', { text: value })]);
  }

  // full=true — перерисовать всё; иначе только отсчёт (раз в секунду)
  function renderDetail(full) {
    var d = state.detail;
    if (!d) return;
    try {
      var ds = $('detail-scroll');
      ds.classList.toggle('is-pinned', d.kind === 'stop');   // карта остановки стоит на месте, листается только список
      ds.classList.toggle('is-line', d.kind === 'line');
      var lineMap = d.kind === 'line' && d.showMap;
      document.querySelector('#detail .map-box').classList.toggle('is-hidden', d.kind === 'line' && !lineMap);
      ds.classList.toggle('is-pinned', d.kind === 'stop' || lineMap);
      // В листаемом экране (поездка) карта не перехватывает палец, пока её не развернули
      var scrollable = !ds.classList.contains('is-pinned');
      if (!scrollable) d.mapBig = false;
      document.querySelector('#detail .map-box').classList.toggle('is-big', !!d.mapBig);
      ensureMap().setLocked(scrollable && !d.mapBig);
      var mx = $('map-expand');
      mx.classList.toggle('is-hidden', !scrollable);
      mx.setAttribute('aria-pressed', String(!!d.mapBig));
      mx.querySelector('use').setAttribute('href', d.mapBig ? '#i-collapse' : '#i-expand');
      mx.querySelector('span').textContent = d.mapBig ? tr('Свернуть карту') : tr('Развернуть карту');
      $('detail-map').classList.toggle('is-hidden', d.kind !== 'line');
      if (d.kind === 'trip') renderTripDetail(d, full);
      else if (d.kind === 'line') { if (full === 'line') renderLineDetail(d); else if (full && d.showMap) renderLineMap(d); }   // расписание перерисовываем только по своим событиям
      else if (full) renderStopDetail(d, full);   // остановку обновляем с данными (раз в 10 с), а не каждую секунду
    } catch (e) {
      if (window.console) console.error(tr('Экран не дорисован:'), e);
      if (mapView) mapView.resize();
    }
  }

  function renderTripDetail(d, full) {
    var trip = d.trip;
    var place = d.place;
    var now = Date.now();
    trip.pinKey = d.pinKey || null;   // за выбранным рейсом следим, пока он не уедет
    if (trip.prune(now)) full = true;
    // Выбранный вариант держим по рейсу, а не по номеру строки: список пересортировывается по GPS,
    // и «второй» вариант через минуту — уже другой автобус. Если выбранный уже выпал из списка
    // (не успеть / уехал) — остаётся в списке первой строкой, пока не выберут другой.
    var list = trip.options.slice();
    if (d.pinKey) {
      var at = -1;
      list.forEach(function (o, i) { if (Trip_key(o) === d.pinKey) at = i; });
      if (at >= 0) d.pinOpt = list[at];
      else if (d.pinOpt) { list.unshift(d.pinOpt); at = 0; }
      if (at >= 0) d.selected = at;
    }
    if (d.selected >= list.length) d.selected = 0;
    var opt = list[d.selected] || null;
    var st = trip.error === 'here' ? 'here' : !opt && !App.here.origin() ? 'noorigin' : opt ? trip.status(opt, now) : trip.loading ? 'loading' : trip.error ? 'error' : 'none';
    var t = opt ? trip.timing(opt, now) : null;
    if (t && t.departed) {   // автобус уже ушёл с остановки: времена берём из расписания
      var fd = opt.firstTransit.departure;
      t = { departed: true, near: t.near, busAt: fd, latest: fd, leaveAt: fd, sched: fd, gps: false,
        walkMs: Math.max(0, fd - opt.start) * App.config.walkFactor };
    }

    $('detail-name').textContent = place.name;
    $('detail-sub').textContent = place.address || '';
    var saved = !place.temp && App.places.get(place.id);
    var starBtn = $('detail-star');
    // «Дом» и «Работа» из настроек уже закреплены наверху — звезда им не нужна
    starBtn.classList.toggle('is-hidden', /^quick-/.test(String(place.id)));
    starBtn.querySelector('use').setAttribute('href', saved && saved.fav ? '#i-star-fill' : '#i-star');
    starBtn.classList.toggle('is-on', !!(saved && saved.fav));
    starBtn.setAttribute('aria-label', saved && saved.fav ? tr('Убрать из избранного') : tr('В избранное'));
    $('detail-more').classList.toggle('is-hidden', !saved);
    var bell = $('detail-bell');
    var on = !!(saved && saved.remind);
    bell.classList.toggle('is-hidden', !saved || !App.native.canNotify);
    bell.classList.toggle('is-on', on);
    bell.querySelector('use').setAttribute('href', on ? '#i-bell-on' : '#i-bell');
    bell.setAttribute('aria-label', on ? tr('Не напоминать') : tr('Напомнить, когда выходить'));
    bell.setAttribute('aria-pressed', String(on));

    // Режим «Еду на этом»: тот же экран, но отсчёт и карта ведут за выбранным автобусом
    if (d.riding) {
      if (App.ride.active() && d.rideOpt) { renderRideBody(d, full); return; }
      d.riding = false; d.rideSig = null; full = true;
    }

    // Отсчёт
    var hero = $('hero');
    hero.setAttribute('data-status', st);
    if (full || !hero.firstChild || hero.getAttribute('data-kind') !== 'trip') {
      hero.setAttribute('data-kind', 'trip');
      clear(hero);
      hero.appendChild(h('span.pill', { id: 'hero-pill' }));
      hero.appendChild(h('div.hero-label', { id: 'hero-label' }));
      hero.appendChild(h('div.hero-count', { id: 'hero-count' }));
      hero.appendChild(h('div.hero-sub', { id: 'hero-sub' }));
      hero.appendChild(h('div.hero-ride', { id: 'hero-ride' }));
    }
    $('hero-pill').textContent = STATUS[st] || '';
    var label = '', count = '', sub = '';
    if (st === 'loading') { count = '…'; sub = tr('Смотрю маршруты и где сейчас автобусы'); }
    else if (st === 'noorigin') { label = tr('нет вашего места'); count = '—'; sub = tr('Включите GPS или выберите, откуда считать, на плашке «Отсюда»'); }
    else if (st === 'here') {
      label = tr('вы уже'); count = tr('здесь');
      sub = App.here.mode === 'gps' ? tr('До места меньше 150 м') : tr('Откуда считаем: ') + originName() + tr('. Если вы в другом месте — выберите «Где я» на плашке «Отсюда»');
    }
    else if (st === 'error') { label = tr('нет связи'); count = '—'; sub = trip.error + tr('. Пробую снова.'); }
    else if (st === 'none') { label = tr('транспорта нет'); count = '—'; sub = tr('Peatus.ee не нашёл поездок в ближайшее время'); }
    else if (opt) {
      var leftMs = t.leaveAt - now;
      if (t.departed) { label = tr('автобус уже уехал'); count = '—'; }
      else if (st === 'late') { label = tr('этот уже не догнать'); count = T.hm(t.busAt); }
      else if (leftMs <= 0) { label = ''; count = tr('сейчас'); }
      else { label = tr('выходи через'); count = (App.here.weak ? '≈ ' : '') + leftText(leftMs); }
      // «Пора выходить» уже сказано плашкой: не повторяем «выходи» и «выйти в» в той же карточке
      if (t.departed) sub = tr('Выберите другой вариант ниже');
      else sub = (t.gps ? tr('● по GPS') : tr('○ по расписанию')) + ' · ' + (leftMs > 0 && st !== 'late' ? tr('выйти в ') + T.hm(t.leaveAt) + ' · ' : '') + tr('на месте в ') + T.hm(opt.end + Math.max(0, t.busAt - t.sched));
      var late = t.gps && !t.departed ? Math.round((t.busAt - t.sched) / 60000) : 0;
      if (late >= 5) sub += tr(' · автобус опаздывает на ') + late + ' ' + T.minutesWord(late) + (late >= 20 && trip.options.length > 1 ? tr('. Посмотрите другие варианты ниже') : '');
      if (App.here.weak && !t.departed) sub += tr(' · место неточное, ±') + App.here.gps.acc + tr(' м');
    }
    $('line-chips').classList.add('is-hidden');
    $('hero').classList.remove('is-hidden');
    $('hero-label').textContent = label;
    $('hero-count').textContent = count;
    $('hero-sub').textContent = sub;
    // На что садиться — крупно, прямо под отсчётом, а не только на карте
    var ride = $('hero-ride');
    var rideKey = opt && opt.firstTransit ? opt.firstTransit.tripId + '|' + opt.firstTransit.stopName : '';
    if (ride.getAttribute('data-key') !== rideKey) {
      ride.setAttribute('data-key', rideKey);
      clear(ride);
      if (opt && opt.firstTransit && st !== 'here') {
        var ft0 = opt.firstTransit;
        var more = opt.legs.filter(function (l) { return l.transit; }).length - 1;
        ride.appendChild(h('span.hero-ride-top', null, [
          h('span.hero-ride-word', { text: tr('Садись на') }),
          lineBadge(ft0.mode, ft0.line, true),
          h('b.hero-ride-to', { text: ft0.headsign ? '→ ' + ft0.headsign : '' })
        ]));
        ride.appendChild(h('span.hero-ride-sub', { text: tr('Остановка ') + ft0.stopName + (t ? ' · ' + Math.max(1, Math.round(t.walkMs / 60000)) + tr(' мин пешком') : '') +
          (more > 0 ? tr(' · потом ') + (more === 1 ? tr('пересадка') : more + tr(' пересадки')) : '') }));
        ride.appendChild(h('div.hero-ride-actions', null, [
          h('button.btn.btn-go', { type: 'button', on: { click: function () { startRide(trip, opt); } } }, [icon('nav'), h('span', { text: tr('Еду на этом') })])
        ]));
      }
    }

    if (!full) { updateFootNote(trip); return; }

    // Факты
    var facts = $('facts');
    clear(facts);
    if (opt) {
      var ft = opt.firstTransit;
      var legs = opt.legs.filter(function (l) { return l.transit; });
      facts.appendChild(h('div.facts-head', null, [
        chain(opt),
        h('span.facts-dir', { text: ft.headsign ? tr('в сторону ') + ft.headsign : '' })
      ]));
      facts.appendChild(fact('walk', tr('Остановка'), ft.stopName + ' · ' + Math.round(t.walkMs / 60000) + tr(' мин пешком')));
      var depText;
      if (t.gps) {
        var diff = Math.round((t.busAt - t.sched) / 60000);
        depText = tr('около ') + T.hm(t.busAt) + tr(' по GPS') + (diff >= 1 ? ' (+' + diff + tr(' мин)') : diff <= -1 ? ' (−' + (-diff) + tr(' мин)') : '');
      } else depText = T.hm(ft.departure) + tr(' по расписанию');
      facts.appendChild(fact('clock', (MODE_WORD[ft.mode] || tr('Транспорт')) + tr(' будет'), depText));
      var near = t.near || {};
      var where;
      if (near.mine) {
        if (near.mine.toStop < 150) where = tr('уже на остановке');
        else {
          where = km(near.mine.toStop);
          var left = App.vehicles.stopsLeft(ft.pattern, trip.stops[ft.tripId], near.mine);
          if (left === 0) where += tr(' · следующая наша');
          else if (left !== null) where += ' · ' + left + ' ' + T.stopsWord(left);
        }
      } else if (near.notYet && near.coming) where = tr('едет к конечной') + (near.coming.terminal ? ' ' + near.coming.terminal : '') + tr(', развернётся (догадка)');
      else if (near.notYet) where = tr('ещё не вышел на линию');
      else if (!App.feed.ok) where = tr('GPS автобусов недоступен');
      else where = tr('нет GPS по этому рейсу');
      facts.appendChild(fact(App.modeIcon(ft.mode), tr('Где он сейчас'), where, near.mine ? 'is-live' : ''));
      if (legs.length > 1) {
        facts.appendChild(fact('refresh', tr('Пересадка'), legs.slice(1).map(function (l) { return l.from + ' ' + T.hm(l.start) + ', ' + l.line; }).join('; ')));
      }
    }

    renderSteps(trip, opt, t, now);

    // Варианты
    var box = $('options');
    clear(box);
    if (list.length > 1 || (list.length === 1 && !trip.loading)) {
      box.appendChild(h('h3.options-title', { text: tr('Варианты') }));
      var SHOW = 3;
      var showAll = d.showAll || d.selected >= SHOW;
      list.forEach(function (o, i) {
        if (!showAll && i >= SHOW) return;
        var ot = trip.timing(o, now);
        if (ot.departed) { var fd2 = o.firstTransit.departure; ot = { departed: true, gps: false, leaveAt: fd2, busAt: fd2, sched: fd2 }; }
        box.appendChild(h('button.option' + (i === d.selected ? '.is-selected' : ''), { type: 'button', 'aria-pressed': String(i === d.selected), on: { click: function () { d.selected = i; d.pinKey = Trip_key(o); d.pinOpt = o; renderDetail(true); } } }, [
          h('span.opt-leave', null, [h('span.opt-k', { text: tr('выйти') }), h('span.opt-v', { text: T.hm(Math.max(ot.leaveAt, now)) })]),
          chain(o),
          h('span.opt-text', null, [
            h('span.src' + (ot.gps ? '.is-live' : ''), { text: ot.gps ? '●' : '○', 'aria-label': ot.gps ? tr('по GPS') : tr('по расписанию') }),
            ' ' + T.hm(ot.busAt) + (ot.gps && Math.abs(Math.round((ot.busAt - ot.sched) / 60000)) >= 1 ? ' (' + (ot.busAt > ot.sched ? '+' : '−') + Math.abs(Math.round((ot.busAt - ot.sched) / 60000)) + ')' : '') + ' → ' + T.hm(o.end)
          ])
        ]));
      });
      if (list.length > SHOW) {
        box.appendChild(h('button.btn.btn-quiet.options-more', { type: 'button', on: { click: function () { d.showAll = !showAll; renderDetail(true); } } },
          [h('span', { text: showAll ? tr('Свернуть') : tr('Показать ещё ') + (list.length - SHOW) })]));
      }
    }

    // Карта
    var mv = ensureMap();
    var origin = App.here.origin();
    var data = { lines: [], vehicles: [] };
    applyMe(data);
    data.dest = { lat: place.lat, lon: place.lon, name: place.name };
    var pts = [];
    if (origin) pts.push([origin.lat, origin.lon]);
    pts.push([place.lat, place.lon]);
    if (opt) {
      var ft2 = opt.firstTransit;
      opt.legs.forEach(function (l) { data.lines.push({ points: l.points, kind: l.transit ? 'transit' : 'walk' }); });
      // Остановки по пути каждого рейса — точками на линии
      data.routeStops = [];
      opt.legs.forEach(function (l) {
        if (!l.transit) return;
        if (l.fromLat != null) data.routeStops.push({ lat: l.fromLat, lon: l.fromLon });
        (rideStopList(l, 0) || []).forEach(function (x) { if (x.lat != null) data.routeStops.push({ lat: x.lat, lon: x.lon }); });
      });
      if (ft2.stopLat) data.stop = { lat: ft2.stopLat, lon: ft2.stopLon, name: ft2.stopName };
      var nr = t.near || {};
      // На карте поездки — только тот транспорт, за которым следим (остальные не показываем)
      if (!nr.mine && nr.coming) {
        var cv = nr.coming.v;
        data.vehicles.push({ id: cv.id, lat: cv.lat, lon: cv.lon, line: cv.line, mode: cv.mode, mine: true,
          label: tr('Похоже, это он: едет к конечной') + (nr.coming.terminal ? ' ' + nr.coming.terminal : '') + tr(' и развернётся') });
        pts.push([cv.lat, cv.lon]);
        // Путь автобуса от начальной конечной до нашей остановки
        var pat = ft2.pattern;
        if (pat && pat.length > 1 && ft2.stopLat != null) {
          var fs = App.vehicles.onPattern(pat, { lat: pat[0][0], lon: pat[0][1] }, ft2.stopLat, ft2.stopLon);
          if (fs && fs.path) data.lines.unshift({ points: fs.path, kind: 'approach' });
        }
      }
      if (nr.mine) {
        data.vehicles.push({ id: nr.mine.id, lat: nr.mine.lat, lon: nr.mine.lon, line: nr.mine.line, mode: nr.mine.mode, mine: true });
        if (nr.mine.path) {
          data.lines.unshift({ points: nr.mine.path, kind: 'approach' });
          // Остановки на пути автобуса к нам — точками на оранжевой линии
          var ts = trip.stops && trip.stops[ft2.tripId];
          (ts || []).forEach(function (stp) {
            if (stp.lat != null && App.vehicles.distToLine(nr.mine.path, stp.lat, stp.lon) < 35) data.routeStops.push({ lat: stp.lat, lon: stp.lon });
          });
        }
      }
      // Главное — путь от меня до остановки и транспорт, который к ней едет. Поездка дальше — по кнопке «Развернуть».
      var bus = nr.mine || (nr.coming && nr.coming.v) || null;
      if (ft2.stopLat != null) {
        pts = origin ? [[origin.lat, origin.lon]] : [];
        pts.push([ft2.stopLat, ft2.stopLon]);
        if (bus) pts.push([bus.lat, bus.lon]);
        var walk0 = opt.legs[0] && !opt.legs[0].transit ? opt.legs[0].points : null;
        if (walk0) pts = pts.concat(walk0);
      } else opt.legs.forEach(function (l) { pts = pts.concat(l.points); });
    }
    mv.setData(data);
    var fitKey = 'trip:' + place.id + ':' + (opt ? Trip_key(opt) : '') + ':' + (t && t.near && (t.near.mine || t.near.coming) ? 'bus' : 'stop');
    mv.fit(pts, fitKey);
    var note = $('map-note');
    note.classList.toggle('is-hidden', App.feed.ok || !App.feed.failed);
    note.textContent = tr('Живой GPS автобусов недоступен, показываю по расписанию');
    updateFootNote(trip);
  }

  // ---------- 4. Поездка по шагам ----------
  // Для второго и следующих автобусов — живой GPS: где машина и успеваем ли на пересадку.
  function legLive(leg, now) {
    if (!App.feed.ok || !leg.pattern || !leg.pattern.length || leg.fromLat === null) return null;
    var near = App.vehicles.approaching(App.feed.vehicles,
      { line: leg.line, mode: leg.mode, headsign: leg.headsign, pattern: leg.pattern, stopLat: leg.fromLat, stopLon: leg.fromLon, tripId: leg.tripId, departure: leg.start },
      leg.points, 0, (leg.start - now) / 60000, {});
    if (!near.mine) return null;
    return { toStop: near.mine.toStop, eta: (App.feed.at || now) + near.mine.toStop / App.vehicles.SPEED * 60000, vehicle: near.mine };
  }

  // Остановки по пути рейса (как в Google Maps): грузим расписание рейса один раз и кэшируем.
  var rideStops = {};
  var rideStopsHidden = false;
  var lastSteps = null;
  function rideStopsFor(l) {
    var c = rideStops[l.tripId];
    if (c === undefined && l.tripId && App.timetable) {
      rideStops[l.tripId] = 'loading';
      var day = new Date(l.start - 4 * 3600000); day.setHours(12, 0, 0, 0);
      App.timetable.trip(l.tripId, day).then(function (r) {
        rideStops[l.tripId] = r || 'none';
        if (state.detail && state.detail.kind === 'trip') renderDetail(true);
      }).catch(function () { rideStops[l.tripId] = 'none'; });
    }
    return c;
  }
  // [{name, at}] от посадки (не включая) до выхода (включая); at — время, сдвинутое на shift мс
  function rideStopList(l, shift) {
    var r = rideStopsFor(l);
    if (!r || typeof r === 'string') return null;
    var st = r.stops;
    var i0 = -1;
    for (var i = 0; i < st.length; i++) if (l.stopId ? st[i].stop.gtfsId === l.stopId : st[i].stop.name === l.from) { i0 = i; break; }
    if (i0 < 0) return null;
    var i1 = -1;
    for (var k = i0 + 1; k < st.length; k++) if (st[k].stop.name === l.to) { i1 = k; break; }
    if (i1 < 0) return null;
    var day = new Date(l.start - 4 * 3600000); day.setHours(0, 0, 0, 0);
    var out = [];
    for (var m = i0 + 1; m <= i1; m++) out.push({ lat: st[m].stop.lat, lon: st[m].stop.lon, name: st[m].stop.name, at: day.getTime() + (st[m].arr != null ? st[m].arr : st[m].sec) * 1000 + shift, last: m === i1 });
    return out;
  }

  function renderSteps(trip, opt, t, now) {
    lastSteps = [trip, opt, t, now];
    var box = $('steps');
    clear(box);
    if (!opt) { box.classList.add('is-hidden'); return; }
    box.classList.remove('is-hidden');
    box.appendChild(h('div.steps-head', null, [h('h3.options-title', { text: tr('Как ехать') })]));
    var rd = state.detail && state.detail.riding && App.ride.active();
    var rSteps = rd ? App.ride.steps() : null;
    var rCur = rd ? App.ride.stepIndex() : -1;
    function rideState(leg) {
      if (!rd) return '';
      if (leg === 'start') return '.is-past';
      if (leg === 'end') return rCur >= rSteps.length ? '.is-cur' : '';
      for (var q = 0; q < rSteps.length; q++) if (rSteps[q].leg === leg) return q < rCur ? '.is-past' : q === rCur ? '.is-cur' : '';
      return '';
    }
    var list = h('ol.timeline');
    function step(kind, ic, title, sub, time, extra, leg) {
      list.appendChild(h('li.tl-step.tl-' + kind + rideState(leg), rd && rideState(leg) === '.is-cur' ? { 'aria-current': 'step' } : null, [
        h('span.tl-time', { text: time || '' }),
        h('span.tl-dot', null, [ic]),
        h('span.tl-body', null, [h('span.tl-title', null, title), sub ? h('span.tl-sub', { text: sub }) : null, extra || null])
      ]));
    }
    var origin = App.here.origin();
    step('start', icon(origin && origin.home ? 'home' : origin && origin.work ? 'work' : 'door'), [h('span', { text: tr('Выйти ') + (origin && origin.home ? tr('из дома') : origin && origin.work ? tr('с работы') : tr('отсюда')) })],
      cfg.prepMinutes ? tr('Сборы ') + cfg.prepMinutes + tr(' мин учтены') : '', T.hm(Math.max(t.leaveAt, now)), null, 'start');
    var legs = opt.legs;
    var transitIdx = 0;
    var prevArrive = null;
    legs.forEach(function (l, i) {
      if (!l.transit) {
        var mins = Math.max(1, Math.round((l.end - l.start) / 60000 * cfg.walkFactor));
        if (l.minutes < 1 && i !== 0 && i !== legs.length - 1) return;
        var to = i === legs.length - 1 ? tr('до места') : tr('до остановки ') + l.to;
        step('walk', icon('walk'), [h('span', { text: tr('Пешком ') + mins + tr(' мин') })], to, '', null, l);
        return;
      }
      transitIdx++;
      var extra = null;
      var sub = l.from + ' → ' + l.to;
      var depTime = l.start;
      if (transitIdx === 1) {
        depTime = t.busAt;
        if (t.gps && t.near && t.near.mine) extra = h('span.tl-live', { text: 'GPS: ' + km(t.near.mine.toStop) + tr(' до остановки') });
      } else {
        var wait = prevArrive ? Math.round((l.start - prevArrive) / 60000) : null;
        var live = legLive(l, now);
        var parts = [];
        if (wait !== null) parts.push(tr('пересадка, ждать ~') + Math.max(0, wait) + tr(' мин'));
        if (live) {
          depTime = live.eta;
          parts.push('GPS: ' + km(live.toStop) + tr(', будет ~') + T.hm(live.eta));
          if (prevArrive && live.eta < prevArrive + 60000) parts.push(tr('можете не успеть на пересадку'));
        }
        if (parts.length) extra = h('span.tl-live' + (live && prevArrive && live.eta < prevArrive + 60000 ? '.is-warn' : ''), { text: parts.join(' · ') });
      }
      var stopsEl = null;
      var rs = rideStopList(l, depTime - l.start);
      if (rs && rs.length) {
        var inner = rs.slice(0, -1);
        stopsEl = h('span.ride-stops', null, [
          rideStopsHidden ? null : h('ul.ride-list', null, rs.map(function (x) {
            return h('li' + (x.last ? '.is-last' : ''), null, [h('span.rs-name', { text: x.name }), h('span.rs-time', { text: T.hm(x.at) })]);
          })),
          h('button.ride-toggle', { type: 'button', 'aria-expanded': String(!rideStopsHidden), on: { click: function () { rideStopsHidden = !rideStopsHidden; if (lastSteps) renderSteps.apply(null, lastSteps); } } },
            [h('span', { text: rideStopsHidden ? tr('Показать остановки (') + inner.length + ')' : tr('Скрыть остановки') })])
        ]);
      }
      step('ride', icon(App.modeIcon(l.mode)), [lineBadge(l.mode, l.line), h('span', { text: ' → ' + l.headsign })],
        sub + ' · ' + Math.max(1, Math.round((l.end - l.start) / 60000)) + tr(' мин в пути'), T.hm(depTime), h('span.tl-extra', null, [extra, stopsEl]), l);
      prevArrive = l.end + Math.max(0, (transitIdx === 1 ? t.busAt - t.sched : 0));
    });
    step('end', icon('flag'), [h('span', { text: tr('На месте') })], '', T.hm(opt.end + Math.max(0, t.busAt - t.sched)), null, 'end');
    box.appendChild(list);
  }

  // Режим «Поехали»: ведение по маршруту по GPS телефона (пока приложение открыто).
  function startRide(trip, opt, confirmed) {
    var place = state.detail && state.detail.place;
    var g = App.here.gps;
    var o = App.here.origin();
    if (!confirmed && g && o && !o.fallback && App.here.mode !== 'gps' && App.vehicles.dist(g.lat, g.lon, o.lat, o.lon) > 150) {
      openSheet(function (sh) {
        sh.appendChild(h('h2.sheet-title', { text: tr('Вы не там, откуда считали') }));
        sh.appendChild(h('p', { text: tr('Маршрут посчитан ') + originWord() + ' (' + originName() + tr('), а вы сейчас в другом месте. Пересчитать от вашего места?') }));
        sh.appendChild(h('div.sheet-actions', null, [
          h('button.btn', { type: 'button', on: { click: function () { closeSheet(); App.here.setMode('gps'); toast(tr('Считаю от вашего места')); } } }, [h('span', { text: tr('Пересчитать') })]),
          h('button.btn.btn-quiet', { type: 'button', on: { click: function () { closeSheet(); setTimeout(function () { startRide(trip, opt, true); }, 250); } } }, [h('span', { text: tr('Всё равно ехать') })])
        ]));
      });
      return;
    }
    var firstLeg = opt.legs.filter(function (x) { return x.transit; })[0];
    function eta(l) {
      var now = Date.now();
      if (l === firstLeg) {
        var tm = trip.timing(opt, now);
        return tm && tm.busAt ? tm.busAt : l.start;
      }
      var lv = legLive(l, now);
      return lv ? lv.eta : l.start;
    }
    var d = state.detail;
    if (!d || d.kind !== 'trip') return;
    d.pinKey = Trip_key(opt); d.pinOpt = opt;   // следим именно за этим рейсом, что бы ни делал список вариантов
    d.rideOpt = opt; d.rideSig = null; d.rideVeh = null; d.rideWalk = null;
    if (rideD && rideD !== d) { rideD.riding = false; rideD.rideOpt = null; }
    var ok = App.ride.start({ opt: opt, etaFor: eta, busFor: function (l) { return rideBus(d, l, false, Date.now()); }, stopsFor: function (l) { return rideStopList(l, eta(l) - l.start); } });
    if (!ok) return;
    d.riding = true;
    rideD = d; d.trip.pinKey = d.pinKey;
    var sc = $('detail-scroll'); if (sc) sc.scrollTop = 0;
    renderDetail(true);
    updateRideFab();
  }

  // Поездка живёт отдельно от открытого экрана: можно уйти на другую вкладку, а кружок вернёт обратно.
  var rideD = null;
  var rideHint = false;
  function endRide() {
    var d = rideD || state.detail;
    App.ride.stop();
    if (d) { d.riding = false; d.rideSig = null; d.rideOpt = null; d.rideVeh = null; d.rideWalk = null; }
    rideD = null;
    if (state.detail) renderDetail(true);
    updateRideFab();
  }
  function resumeRide() {
    if (!rideD || !rideD.riding || !App.ride.active()) { updateRideFab(); return; }
    state.prevDetail = null;
    state.detail = rideD;
    rideD.rideSig = null;
    if (rideD.place) markCurrent('[data-place="' + rideD.place.id + '"]');
    renderDetail(true);
    showDetail();
    updateRideFab();
  }

  function updateRideFab() {
    var fab = $('ride-fab');
    if (!fab) return;
    var ev = rideD && rideD.riding && App.ride.active() ? App.ride.event() : null;
    if (!ev || state.detail === rideD) { fab.classList.add('is-hidden'); return; }
    var now = Date.now();
    var info = rideDescribe(ev, now, rideD, App.ride.stepIndex());
    var leg = ev.kind === 'walk' ? ev.nextLeg : ev.kind === 'done' ? null : ev.st.leg;
    var top = leg ? (leg.line || '') : '✓';
    var count = ev.kind === 'ride' && info.status === 'go' ? tr('Выходите!') : info.count;
    fab.setAttribute('data-status', info.status);
    fab.setAttribute('data-long', count.length > 6 ? '1' : '0');
    $('ride-fab-top').textContent = top;
    $('ride-fab-count').textContent = count;
    $('ride-fab-label').textContent = info.label && info.label.length <= 22 ? info.label : info.pill;
    fab.classList.remove('is-hidden');
    placeFab(false);
    if (fab.style.left) { var rc = fab.getBoundingClientRect(); if (rc.right > window.innerWidth - 4) fab.style.left = Math.max(4, window.innerWidth - rc.width - 4) + 'px'; }
  }
  // Положение кружка: можно двигать, запоминается как доля экрана
  var fabPos = null;
  (function () { try { fabPos = JSON.parse(localStorage.getItem('pv.fab') || 'null'); } catch (e) { fabPos = null; } })();
  function placeFab(force) {
    var fab = $('ride-fab');
    if (!fabPos || (!force && fab.getAttribute('data-placed') === '1' && fab.getAttribute('data-w') === window.innerWidth + 'x' + window.innerHeight)) return;
    var w = fab.offsetWidth || 76, hh = fab.offsetHeight || 76;
    var x = Math.min(Math.max(4, fabPos.x * window.innerWidth), window.innerWidth - w - 4);
    var y = Math.min(Math.max(4, fabPos.y * window.innerHeight), window.innerHeight - hh - 4);
    fab.style.left = x + 'px'; fab.style.top = y + 'px'; fab.style.right = 'auto'; fab.style.bottom = 'auto';
    fab.setAttribute('data-placed', '1'); fab.setAttribute('data-w', window.innerWidth + 'x' + window.innerHeight);
  }
  (function () {
    var fab = $('ride-fab'), st = null;
    fab.addEventListener('pointerdown', function (e) {
      var r = fab.getBoundingClientRect();
      fab._dragged = false;
      st = { x: e.clientX, y: e.clientY, l: r.left, t: r.top, moved: false, id: e.pointerId };
      try { fab.setPointerCapture(e.pointerId); } catch (x) { /* без захвата */ }
    });
    fab.addEventListener('pointermove', function (e) {
      if (!st || e.pointerId !== st.id) return;
      var dx = e.clientX - st.x, dy = e.clientY - st.y;
      if (!st.moved && Math.abs(dx) + Math.abs(dy) < 10) return;
      st.moved = true; fab.classList.add('is-dragging');
      var w = fab.offsetWidth, hh = fab.offsetHeight;
      var x = Math.min(Math.max(4, st.l + dx), window.innerWidth - w - 4);
      var y = Math.min(Math.max(4, st.t + dy), window.innerHeight - hh - 4);
      fab.style.left = x + 'px'; fab.style.top = y + 'px'; fab.style.right = 'auto'; fab.style.bottom = 'auto';
    });
    function up(e) {
      if (!st || e.pointerId !== st.id) return;
      var moved = st.moved; st = null;
      fab._dragged = moved;
      fab.classList.remove('is-dragging');
      if (moved) {
        var r = fab.getBoundingClientRect();
        fabPos = { x: r.left / window.innerWidth, y: r.top / window.innerHeight };
        fab.setAttribute('data-placed', '1'); fab.setAttribute('data-w', window.innerWidth + 'x' + window.innerHeight);
        try { localStorage.setItem('pv.fab', JSON.stringify(fabPos)); } catch (x) { /* не сохранилось */ }
      }
    }
    fab.addEventListener('click', function () { if (fab._dragged) { fab._dragged = false; return; } resumeRide(); });
    fab.addEventListener('pointerup', up);
    fab.addEventListener('pointercancel', up);
    window.addEventListener('resize', function () { if (fabPos) placeFab(true); });
  })();

  // Автобус, за которым следим: до посадки — тот, что едет к остановке; после — тот, в котором мы.
  // Машину запоминаем по id: когда она доезжает до остановки, расчёт «едет к остановке» её теряет
  // (рейс считается ушедшим), а мы всё равно должны её видеть и на остановке, и в пути.
  function rideBus(d, l, boarded, now) {
    var opt = d.rideOpt, trip = d.trip;
    var first = opt.legs.filter(function (x) { return x.transit; })[0] === l;
    var vs = App.feed.vehicles || [];
    var key = (l.tripId || l.line) + '|' + l.start;
    var sticky = d.rideVeh && d.rideVeh.key === key ? d.rideVeh.id : null;
    function byId(id) { var r = null; if (id) vs.forEach(function (x) { if (x.id === id) r = x; }); return r; }
    var v = null;
    if (!boarded) {
      if (first) { var tm = trip.timing(opt, now); v = tm && tm.near && tm.near.mine ? tm.near.mine : null; }
      else { var lv = legLive(l, now); v = lv ? lv.vehicle : null; }
      if (v) { d.rideVeh = { key: key, id: v.id }; return v; }
      var sv = byId(sticky);   // доехала до остановки: считаем расстояние сами
      if (sv && l.fromLat != null) { var c = {}; for (var k in sv) c[k] = sv[k]; c.toStop = App.vehicles.dist(sv.lat, sv.lon, l.fromLat, l.fromLon); c.path = null; return c; }
      return null;
    }
    v = byId(sticky);
    if (!v && first) v = byId(trip.locks[Trip_key(opt)]);
    var g = App.here.gps;
    if (!v && g) {
      var best = 250, wantTram = String(l.mode).toUpperCase() === 'TRAM';
      vs.forEach(function (x) {
        if (x.line !== l.line || (x.mode === 'TRAM') !== wantTram) return;
        var dd = App.vehicles.dist(g.lat, g.lon, x.lat, x.lon);
        if (dd < best) { best = dd; v = x; }
      });
    }
    if (v) d.rideVeh = { key: key, id: v.id };
    return v;
  }

  function rideDescribe(ev, now, d, idx) {
    var W = App.ride.walkMPerMin;
    var o = { status: 'relax', pill: '', label: '', count: '', sub: '', text: false };
    if (ev.kind === 'done') {
      o.pill = tr('На месте'); o.count = tr('приехали'); o.text = true; o.sub = tr('Хорошей дороги дальше!');
    } else if (ev.kind === 'walk' && ev.nextLeg) {
      // Как на карточках мест: пока не вышли — «выходи через», когда уже идём — «запас». Время приезда автобуса — в подписи.
      // Первый автобус считаем тем же расчётом, что и экран плана (trip.timing): иначе цифры «выходи через» расходятся.
      var busAt = ev.nextEta, planLeave = null;
      if (d && d.rideOpt && d.trip && d.rideOpt.legs.filter(function (x) { return x.transit; })[0] === ev.nextLeg) {
        var tm0 = d.trip.timing(d.rideOpt, now);
        if (!tm0.departed) { busAt = tm0.busAt; planLeave = tm0.leaveAt - now; }
      }
      var busMs = busAt - now;
      var W0 = ev.dist === null ? null : ev.dist / W;
      var wm = W0 === null ? (ev.st.leg.minutes || 0) : W0;
      var slack = busMs / 60000 - wm;
      var rw = d && d.rideWalk;
      if (d && ev.dist !== null && (!rw || rw.idx !== idx)) rw = d.rideWalk = { idx: idx, max: ev.dist };
      if (rw && ev.dist !== null && ev.dist > rw.max) rw.max = ev.dist;
      var started = !!(rw && ev.dist !== null && rw.max - ev.dist > 40);
      var busTxt = tr('автобус в ') + T.hm(busAt);
      o.pill = tr('Идём к остановке');
      if (!started) {
        var leaveMs = planLeave !== null ? planLeave : busMs - wm * 60000 - (cfg.bufferMinutes + (cfg.prepMinutes || 0)) * 60000;
        o.status = leaveMs <= 60000 ? 'go' : leaveMs <= 300000 ? 'soon' : 'relax';
        o.pill = STATUS[o.status];
        if (leaveMs > 0) { o.label = tr('выходи через'); o.count = leftText(leaveMs); } else { o.label = ''; o.count = tr('сейчас'); }
        o.sub = (leaveMs > 0 ? tr('выйти в ') + T.hm(now + leaveMs) + ' · ' : '') + busTxt +
          (ev.dist !== null ? ' · ' + km(ev.dist) + tr(' до остановки') : '');
        if (slack < -1) { o.status = 'late'; o.pill = STATUS.late; o.label = ''; o.count = tr('не успеть'); o.text = true; o.sub = busTxt + ' · ' + tr('лучше следующий'); }
      } else if (ev.dist === null) { o.status = 'soon'; o.sub = tr('Жду GPS телефона…'); }
      else {
        o.status = slack >= 3 ? 'relax' : slack >= 0.5 ? 'soon' : slack >= -1 ? 'go' : 'late';
        if (slack >= 0.5) { o.label = tr('запас'); o.count = Math.floor(slack) + tr(' мин'); }
        else { o.label = ''; o.count = slack >= -1 ? tr('бегом') : tr('не успеть'); o.text = true; }
        o.sub = km(ev.dist) + tr(' до остановки') + ' · ≈' + Math.max(1, Math.round(wm)) + tr(' мин пешком') + ' · ' + busTxt +
          (slack < -1 ? ' · ' + tr('лучше следующий') : '');
      }
    } else if (ev.kind === 'walk') {
      o.pill = tr('Идём к месту');
      o.label = tr('до места'); o.count = ev.dist === null ? '—' : km(ev.dist);
      o.sub = ev.dist === null ? tr('Жду GPS телефона…') : '≈' + Math.max(1, Math.round(ev.dist / W)) + tr(' мин пешком'); o.text = ev.dist !== null;
    } else if (ev.kind === 'wait') {
      var ms = ev.eta - now;
      o.pill = ev.transfer ? tr('Пересадка: ждём') : tr('Ждём на остановке');
      o.label = ms > 30000 ? tr('приедет через') : '';
      o.count = ms > 30000 ? leftText(ms) : tr('сейчас');
      o.status = ms < 60000 ? 'go' : 'soon';
      o.sub = tr('Остановка ') + ev.st.leg.from + (ev.near !== null && ev.near > 100 ? ' · ' + tr('до неё ') + km(ev.near) : '');
    } else {
      var urgent = ev.left === 1 || (ev.exitD !== null && ev.exitD < 250 && ev.left === null);
      var lr = ev.st.leg;
      if (urgent) {
        o.status = 'go'; o.pill = tr('Выходите!'); o.label = tr('следующая — ваша'); o.count = lr.to; o.text = true;
      } else {
        o.pill = tr('Едем');
        if (ev.left !== null) { o.label = T.stopsWord(ev.left) + tr(' до выхода'); o.count = String(ev.left); }
        else { o.label = tr('до выхода'); o.count = ev.exitD === null ? '—' : km(ev.exitD); }
      }
      o.sub = tr('Выходить: ') + lr.to + tr(' · около ') + T.hm(ev.exitAt);
    }
    return o;
  }

  function renderRideBody(d, full) {
    var trip = d.trip, opt = d.rideOpt, place = d.place, now = Date.now();
    var ev = App.ride.event();
    if (!ev) return;
    var idx = App.ride.stepIndex();
    var urgentNow = ev.kind === 'ride' && (ev.left === 1 || (ev.exitD !== null && ev.exitD < 250 && ev.left === null));
    var sig = idx + '|' + ev.kind + (urgentNow ? '!' : '');
    if (d.rideSig !== sig) { d.rideSig = sig; full = true; }
    var info = rideDescribe(ev, now, d, idx);
    var leg = ev.kind === 'walk' ? ev.nextLeg : ev.kind === 'done' ? null : ev.st.leg;
    var boarded = ev.kind === 'ride';
    var bus = leg ? rideBus(d, leg, boarded, now) : null;

    var hero = $('hero');
    if (full || !hero.firstChild || hero.getAttribute('data-kind') !== 'ride') {
      hero.setAttribute('data-kind', 'ride');
      clear(hero);
      hero.appendChild(h('span.pill', { id: 'hero-pill' }));
      hero.appendChild(h('div.hero-label', { id: 'hero-label' }));
      hero.appendChild(h('div.hero-count', { id: 'hero-count' }));
      hero.appendChild(h('div.hero-sub', { id: 'hero-sub' }));
      var card = h('div.hero-ride', { id: 'hero-ride', 'data-key': 'ride:' + sig });
      if (leg) {
        card.appendChild(h('span.hero-ride-top', null, [
          h('span.hero-ride-word', { text: boarded ? tr('Вы едете на') : tr('Ваш транспорт') }),
          lineBadge(leg.mode, leg.line, true),
          h('b.hero-ride-to', { text: leg.headsign ? '→ ' + leg.headsign : '' })
        ]));
        card.appendChild(h('span.hero-ride-sub', { id: 'hero-ride-live' }));
      }
      var acts = h('div.hero-ride-actions');
      if (ev.kind === 'done') acts.appendChild(h('button.btn.btn-go', { type: 'button', on: { click: endRide } }, [icon('flag'), h('span', { text: tr('Завершить') })]));
      else {
        acts.appendChild(h('button.btn.btn-quiet', { type: 'button', on: { click: endRide } }, [h('span', { text: tr('Закончить') })]));
      }
      card.appendChild(acts);
      hero.appendChild(card);
    }
    hero.setAttribute('data-status', info.status);
    hero.classList.remove('is-hidden');
    $('hero-pill').textContent = info.pill;
    $('hero-label').textContent = info.label;
    var cEl = $('hero-count');
    cEl.textContent = info.count;
    cEl.classList.toggle('is-text', !!info.text);
    $('hero-sub').textContent = info.sub;
    $('line-chips').classList.add('is-hidden');
    var live = $('hero-ride-live');
    if (live) {
      var txt;
      if (boarded) txt = bus ? tr('● ваш автобус на карте') : tr('○ автобуса на карте нет, веду по вашему GPS');
      else if (bus && bus.toStop != null) txt = '● ' + (bus.toStop < 150 ? tr('уже на остановке') : km(bus.toStop) + tr(' до остановки'));
      else txt = App.feed.ok ? tr('○ нет GPS по этому рейсу, иду по расписанию') : tr('○ GPS автобусов недоступен, иду по расписанию');
      live.textContent = txt;
      live.classList.toggle('is-live', txt.charAt(0) === '●');
    }

    // Карта: вы, цель шага и автобус — всегда в кадре
    var g = App.here.gps && Date.now() - App.here.gps.at < 60000 ? App.here.gps : null;
    var target = null;
    if (ev.kind === 'walk') target = ev.nextLeg && ev.nextLeg.fromLat != null ? [ev.nextLeg.fromLat, ev.nextLeg.fromLon] : ev.st.leg.toLat != null ? [ev.st.leg.toLat, ev.st.leg.toLon] : null;
    else if (ev.kind === 'wait') target = ev.st.leg.fromLat != null ? [ev.st.leg.fromLat, ev.st.leg.fromLon] : null;
    else if (ev.kind === 'ride') target = ev.st.leg.toLat != null ? [ev.st.leg.toLat, ev.st.leg.toLon] : null;
    var mkey = [idx, ev.kind, g ? Math.round(g.lat * 20000) + ',' + Math.round(g.lon * 20000) : '-', bus ? Math.round(bus.lat * 20000) + ',' + Math.round(bus.lon * 20000) : '-', full ? 'f' : ''].join('|');
    if (full || d.rideMapKey !== mkey) {
      d.rideMapKey = mkey.replace(/\|f$/, '');
      var mv = ensureMap();
      var data = { lines: [], vehicles: [] };
      if (g) data.me = { lat: g.lat, lon: g.lon, acc: g.acc };
      var steps = App.ride.steps();
      steps.forEach(function (sx, i) {
        if (i < idx || !sx.leg.points || sx.leg.points.length < 2) return;
        data.lines.push({ points: sx.leg.points, kind: sx.leg.transit ? 'transit' : 'walk' });
      });
      var lastLeg = steps[steps.length - 1].leg;
      data.dest = lastLeg && lastLeg.toLat != null ? { lat: lastLeg.toLat, lon: lastLeg.toLon, name: place.name } : { lat: place.lat, lon: place.lon, name: place.name };
      if (target) data.stop = { lat: target[0], lon: target[1], name: ev.kind === 'ride' ? ev.st.leg.to : (ev.nextLeg || ev.st.leg).from };
      if (ev.kind === 'ride' && ev.list) data.routeStops = ev.list.filter(function (x) { return x.lat != null; });
      if (bus && !boarded && bus.path) data.lines.unshift({ points: bus.path, kind: 'approach' });
      if (bus) data.vehicles.push({ id: bus.id, lat: bus.lat, lon: bus.lon, line: bus.line, mode: bus.mode, mine: true });
      mv.setData(data);
      var pts = [];
      if (g) pts.push([g.lat, g.lon]);
      if (target) pts.push(target);
      if (bus && !boarded) pts.push([bus.lat, bus.lon]);
      if (ev.kind === 'done' && data.dest) pts = [[data.dest.lat, data.dest.lon]];
      if (!pts.length) pts.push([place.lat, place.lon]);
      var bucket = bus && g && !boarded ? Math.floor(App.vehicles.dist(g.lat, g.lon, bus.lat, bus.lon) / 400) : 'x';
      mv.fit(pts, 'ride:' + idx + ':' + ev.kind + ':' + bucket);
    }
    var note = $('map-note');
    note.classList.toggle('is-hidden', App.feed.ok || !App.feed.failed);
    note.textContent = tr('Живой GPS автобусов недоступен, показываю по расписанию');
    var foot = tr('Оставьте приложение открытым: в фоне оно не следит.');
    if (!g && ev.kind !== 'done') foot = (App.here.error || tr('Нет свежего GPS. Выйдите на открытое место.')) + ' ' + foot;
    $('foot-note').textContent = foot;

    if (!full) return;

    // Факты и шаги — как на обычном экране поездки
    var t0 = trip.timing(opt, now);
    if (t0.departed) { var fd = opt.firstTransit.departure; t0 = { departed: true, near: t0.near, busAt: fd, latest: fd, leaveAt: fd, sched: fd, gps: false, walkMs: 0 }; }
    var facts = $('facts');
    clear(facts);
    if (leg) {
      facts.appendChild(h('div.facts-head', null, [chain(opt), h('span.facts-dir', { text: leg.headsign ? tr('в сторону ') + leg.headsign : '' })]));
      if (boarded) {
        facts.appendChild(fact('flag', tr('Выход'), leg.to));
        facts.appendChild(fact('clock', tr('Прибытие'), tr('около ') + T.hm(ev.exitAt)));
        if (ev.left !== null) facts.appendChild(fact(App.modeIcon(leg.mode), tr('До выхода'), ev.left + ' ' + T.stopsWord(ev.left)));
      } else {
        facts.appendChild(fact('walk', tr('Остановка'), leg.from));
        facts.appendChild(fact('clock', (MODE_WORD[leg.mode] || tr('Транспорт')) + tr(' будет'), T.hm(ev.kind === 'wait' ? ev.eta : ev.nextEta) + (bus ? tr(' по GPS') : tr(' по расписанию'))));
        facts.appendChild(fact(App.modeIcon(leg.mode), tr('Где он сейчас'), bus && bus.toStop != null ? (bus.toStop < 150 ? tr('уже на остановке') : km(bus.toStop)) : tr('нет GPS по этому рейсу'), bus ? 'is-live' : ''));
      }
    }
    renderSteps(trip, opt, t0, now);
    clear($('options'));
  }

  function updateFootNote(trip) {
    var parts = [];
    if (App.feed.at) parts.push(tr('Автобусы: ') + T.hm(App.feed.at) + ':' + String(new Date(App.feed.at).getSeconds()).padStart(2, '0'));
    if (trip && trip.updated) parts.push(tr('маршрут: ') + T.hm(trip.updated));
    parts.push(tr('запас ') + cfg.bufferMinutes + tr(' мин') + (cfg.prepMinutes ? tr(', сборы ') + cfg.prepMinutes + tr(' мин') : ''));
    $('foot-note').textContent = parts.join(' · ');
  }

  // Отправления всей группы (обе стороны улицы), с пометкой, с какой платформы.
  function groupDeps(g) {
    var out = [];
    g.stops.forEach(function (st) {
      App.nearby.live(st).forEach(function (x) { x.stop = st; out.push(x); });
    });
    out.sort(function (a, b) { return a.eta - b.eta; });
    return out;
  }
  function lineKey(x) { return x.mode + '|' + x.line + '|' + x.headsign; }

  // Линии, которые ходят через остановку (с учётом выбранной стороны), даже когда рейсов скоро нет
  function stopPatterns(g, d) {
    var dir = d.dirFilter ? g.dirs.filter(function (y) { return y.id === d.dirFilter; })[0] : null;
    var out = [];
    var seen = {};
    (dir ? dir.stops : g.stops).forEach(function (stp) {
      (stp.patterns || []).forEach(function (pt) { if (!seen[pt.code]) { seen[pt.code] = true; out.push({ code: pt.code, line: pt.line, mode: pt.mode, headsign: pt.headsign, stop: stp }); } });
    });
    out.sort(function (a, b) { return String(a.line).localeCompare(String(b.line), undefined, { numeric: true }) || String(a.headsign).localeCompare(String(b.headsign)); });
    return out;
  }

  // Ближайший будущий рейс линии на остановке: сегодня, а если сегодня уже всё — завтра (по расписанию Peatus.ee)
  var nextTimes = {};
  function nextFirst(stopId, code) {
    var key = stopId + '|' + code + '|' + Math.floor(Date.now() / 600000);
    var c = nextTimes[key];
    if (c !== undefined) return c;
    nextTimes[key] = 'loading';
    var base = App.timetable.serviceToday();
    var dayStart = new Date(base); dayStart.setHours(0, 0, 0, 0);
    var nowSec = (Date.now() - dayStart.getTime()) / 1000;
    App.timetable.times(stopId, [code], base).then(function (list) {
      var nx = list.filter(function (x) { return x.sec > nowSec; })[0];
      if (nx) return { at: dayStart.getTime() + nx.sec * 1000, tomorrow: false };
      var next = new Date(base); next.setDate(next.getDate() + 1);
      var ns = new Date(next); ns.setHours(0, 0, 0, 0);
      return App.timetable.times(stopId, [code], next).then(function (l2) {
        return l2.length ? { at: ns.getTime() + l2[0].sec * 1000, tomorrow: true } : 'none';
      });
    }).then(function (r) { nextTimes[key] = r; }).catch(function () { nextTimes[key] = 'none'; }).then(function () {
      if (state.detail && state.detail.kind === 'stop') renderDetail(true);
    });
    return 'loading';
  }
  function appendStopLines(list, g, d) {
    var pats = stopPatterns(g, d);
    if (!pats.length) return;
    list.appendChild(h('h3.options-title.stop-lines-title', { text: tr('Ходят через эту остановку') }));
    pats.slice(0, 12).forEach(function (pt) {
      var nf = nextFirst(pt.stop.id, pt.code);
      var when = nf && typeof nf === 'object' ? (nf.tomorrow ? tr('завтра ') : tr('сегодня ')) + T.hm(nf.at) : nf === 'none' ? '' : '…';
      list.appendChild(h('div.dep.dep-static', null, [
        lineBadge(pt.mode, pt.line),
        h('span.dep-head', null, [h('span', { text: pt.headsign })]),
        h('span.dep-when', null, when && when !== '…' ? [h('small', { text: tr('ближайший') }), h('b', { text: when })] : [h('small', { text: when })])
      ]));
    });
  }

  function renderStopDetail(d, full) {
    var g = d.stop;
    var now = Date.now();
    if (d.dirFilter && !g.dirs.some(function (y) { return y.id === d.dirFilter; })) d.dirFilter = null;
    var all = groupDeps(g).filter(function (x) { return inDir(g, d.dirFilter, x); });
    if (d.lineFilter && !all.some(function (x) { return lineKey(x) === d.lineFilter; })) d.lineFilter = null;
    var deps = d.lineFilter ? all.filter(function (x) { return lineKey(x) === d.lineFilter; }) : all;
    // Выбранный рейс (нажали на строку): список не сужаем, только показываем этот автобус на карте.
    var selDep = d.sel ? deps.filter(function (x) { return x.tripId === d.sel; })[0] : null;
    if (!selDep) d.sel = null;
    $('detail-name').textContent = g.name;
    $('detail-sub').textContent = (g.fromTT ? '' : km(g.distance) + ' ' + originWord()) + (g.dirs.length > 1 ? tr(' · 2 направления') : '');
    $('detail-star').classList.add('is-hidden');
    $('detail-more').classList.add('is-hidden');
    $('steps').classList.add('is-hidden');
    var bellBtn = $('detail-bell');
    bellBtn.classList.add('is-hidden');

    // Выбор линии: «Все» и каждая линия с направлением
    var box = $('line-chips');
    box.classList.remove('is-hidden');
    var keepScroll = Array.prototype.map.call(box.querySelectorAll('.chip-row'), function (r) { return r.scrollLeft; });
    clear(box);
    if (g.dirs.length > 1) {
      var dirRow = h('div.chip-row', { role: 'radiogroup', 'aria-label': tr('Направление') });
      var dchip = function (id, kids, label) {
        var on = (d.dirFilter || '') === (id || '');
        return h('button.dir-chip' + (on ? '.is-on' : ''), { type: 'button', role: 'radio', 'aria-checked': String(on), 'aria-label': label, on: { click: function () {
          d.dirFilter = id;
          d.sel = null;
          state.nearby.dir = state.nearby.dir || {};
          state.nearby.dir[g.id] = id;
          renderDetail(true);
          renderNearby();
          if (mapView) mapView.recenter();
        } } }, kids);
      };
      g.dirs.forEach(function (dd) {
        dirRow.appendChild(dchip(dd.id, dirChipKids(dd), tr('В сторону ') + dd.label));
      });
      dirRow.appendChild(dchip(null, [h('span', { text: tr('Оба') })], tr('Оба направления')));
      box.appendChild(dirRow);
    }
    var chips = h('div.chip-row', { role: 'radiogroup', 'aria-label': tr('Линия') });
    box.appendChild(chips);
    var lines = [];
    all.forEach(function (x) { if (!lines.some(function (l) { return lineKey(l) === lineKey(x); })) lines.push(x); });
    lines.sort(function (a, b) {
      return (parseInt(a.line, 10) || 999) - (parseInt(b.line, 10) || 999) ||
        String(a.line || '').localeCompare(String(b.line || '')) || String(a.headsign || '').localeCompare(String(b.headsign || ''));
    });
    function chip(key, kids, label) {
      var on = (d.lineFilter || '') === key;
      return h('button.line-chip' + (on ? '.is-on' : ''), { type: 'button', role: 'radio', 'aria-checked': String(on), 'aria-label': label, on: { click: function () {
        d.lineFilter = key || null;
        d.sel = null;
        renderDetail(true);
        if (mapView) mapView.recenter();
      } } }, kids);
    }
    chips.appendChild(chip('', [h('span', { text: tr('Все') })], tr('Все линии')));
    lines.forEach(function (x) {
      chips.appendChild(chip(lineKey(x), [lineBadge(x.mode, x.line), h('span.line-chip-dir', { text: '→ ' + x.headsign })], tr('Линия ') + x.line + tr(' в сторону ') + x.headsign));
    });

    Array.prototype.forEach.call(box.querySelectorAll('.chip-row'), function (r, i) { if (keepScroll[i]) r.scrollLeft = keepScroll[i]; });

    var hero = $('hero');
    hero.setAttribute('data-kind', 'stop');
    // ближайший рейс, к которому ещё можно успеть дойти
    var first = selDep || deps.filter(function (x) { return stopLeave(x) > now - 60000; })[0] || deps[0];
    var focused = !!(selDep || d.lineFilter);
    if (focused && first && App.native.canNotify) {
      var rem = stopRem();
      var onRem = !!(rem && rem.tripId === first.tripId);
      bellBtn.classList.remove('is-hidden');
      bellBtn.classList.toggle('is-on', onRem);
      bellBtn.querySelector('use').setAttribute('href', onRem ? '#i-bell-on' : '#i-bell');
      bellBtn.setAttribute('aria-label', onRem ? tr('Не напоминать') : tr('Напомнить, когда выходить к ') + first.line);
      d.remDep = first;
    } else d.remDep = null;
    var st = 'none';
    var walkMs = 0;
    if (first) {
      walkMs = first.stop.distance / 80 * 60000 * cfg.walkFactor; // ~80 м/мин пешком (оценка)
      var leave = first.eta - walkMs - cfg.bufferMinutes * 60000;
      st = leave - now <= 0 ? (first.eta - walkMs < now ? 'late' : 'go') : leave - now <= 3 * 60000 ? 'go' : leave - now <= 10 * 60000 ? 'soon' : 'relax';
    }
    hero.setAttribute('data-status', st);
    clear(hero);
    if (first) {
      hero.appendChild(h('span.pill', { text: first.gps ? tr('Ближайший по GPS') : tr('Ближайший по расписанию') }));
      hero.appendChild(h('div.hero-label', null, [lineBadge(first.mode, first.line), h('span', { text: ' → ' + first.headsign })]));
      hero.appendChild(h('div.hero-count', { text: first.eta - now <= 30000 ? tr('сейчас') : tr('через ') + minutes(first.eta - now) + tr(' мин') }));
      var leaveIn = first.eta - walkMs - cfg.bufferMinutes * 60000 - now;
      var lateN = first.gps ? Math.round((first.eta - first.time) / 60000) : 0;
      hero.appendChild(h('div.hero-sub', { text: tr('До остановки ~') + Math.max(1, Math.round(walkMs / 60000)) + tr(' мин пешком') +
        (lateN >= 5 ? tr(' · опаздывает на ') + lateN + ' ' + T.minutesWord(lateN) : '') +
        (App.here.weak ? tr(' · место неточное, ±') + App.here.gps.acc + tr(' м') : '') +
        (leaveIn > 60000 ? tr(' · выйти через ') + minutes(leaveIn) + tr(' мин') : leaveIn > -60000 ? tr(' · выходи сейчас') : tr(' · уже не успеть')) }));
    } else {
      hero.appendChild(h('span.pill', { text: tr('Нет рейсов') }));
      hero.appendChild(h('div.hero-count', { text: '—' }));
      hero.appendChild(h('div.hero-sub', { text: d.lineFilter ? tr('Этот автобус в ближайшие 2 часа отсюда не уходит') : tr('В ближайшие 2 часа отсюда ничего не уходит') }));
    }
    hero.classList.add('is-hidden');   // на экране остановки достаточно списка отправлений

    var facts = $('facts');
    var keepTop = facts.scrollTop;
    clear(facts);
    var list = h('div.deps');
    deps.slice(0, d.lineFilter ? 10 : 14).forEach(function (x) {
      var m = minutes(x.eta - now);
      var isSel = x.tripId && x.tripId === d.sel;
      list.appendChild(h('button.dep' + (x.gps ? '.is-live' : '') + (isSel ? '.is-sel' : ''), { type: 'button', 'aria-pressed': String(!!isSel),
        'aria-label': x.line + tr(' в сторону ') + x.headsign + ', ' + (m <= 0 ? tr('сейчас') : tr('через ') + m + tr(' мин')) + (isSel ? tr(', показан на карте') : tr(', показать на карте')), on: { click: function () {
        d.sel = isSel ? null : x.tripId;   // повторное нажатие снимает выбор
        renderDetail(true);
        if (mapView) mapView.recenter();
        if (d.sel) { var mb = document.querySelector('#detail .map-box'); if (mb && mb.getBoundingClientRect().top < 0) mb.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
      } } }, [
        lineBadge(x.mode, x.line),
        h('span.dep-head', null, [h('span', { text: x.headsign }), g.stops.length > 1 ? h('small', { text: km(x.stop.distance) + ' ' + originWord() }) : null]),
        h('span.dep-when', null, [
          h('b', { text: m <= 0 ? tr('сейчас') : m + tr(' мин') }),
          h('small', { text: x.gps ? 'GPS · ' + km(x.vehicle.toStop) : T.hm(x.time) })
        ])
      ]));
    });
    if (!deps.length) {
      list.appendChild(h('p.no-deps-note', { text: d.dirFilter ? tr('В эту сторону в ближайшие 2 часа рейсов нет') : tr('В ближайшие 2 часа отсюда ничего не уходит') }));
      appendStopLines(list, g, d);
    }
    facts.appendChild(list);
    facts.scrollTop = keepTop;
    clear($('options'));

    var mv = ensureMap();
    var origin = App.here.origin();
    var data = { lines: [], vehicles: [], stops: [] };
    applyMe(data);
    var pts = [];
    var activeDir = d.dirFilter ? g.dirs.filter(function (y) { return y.id === d.dirFilter; })[0] : null;
    var activeStops = focused && first ? [first.stop] : activeDir ? activeDir.stops : g.stops;
    g.stops.forEach(function (stp) {
      var act = activeStops.indexOf(stp) >= 0;
      // стрелка — в какую сторону уходят автобусы с этой платформы
      data.stops.push({ lat: stp.lat, lon: stp.lon, active: act && (focused || d.dirFilter || g.stops.length > 1), bearing: act ? platformBearing(stp) : null,
        dim: !act });
      pts.push([stp.lat, stp.lon]);
    });
    if (origin) pts.push([origin.lat, origin.lon]);
    if (!focused) {
      // Все маршруты, которые идут через эту остановку (в выбранную сторону), — тонкими линиями, даже если GPS у них нет
      // и даже ночью, когда рейсов нет; автобусы с GPS рисуются поверх
      var seenPat = {};
      var addPat = function (code) {
        if (!code || seenPat[code]) return;
        seenPat[code] = true;
        var pp = App.nearby.pattern(code);
        if (pp) data.lines.push({ points: pp, kind: 'routes' });
      };
      deps.forEach(function (x) { addPat(x.pattern); });
      stopPatterns(g, d).forEach(function (pt) { addPat(pt.code); });
    }
    if ((focused || d.lineFilter) && first) {
      var full = App.nearby.pattern(first.pattern);
      if (full) data.lines.push({ points: full, kind: 'transit' });
      // Остановки маршрута точками — как на вкладке «Карта»
      var ps = App.nearby.patternStops(first.pattern);
      if (ps) data.routeStops = ps;
    }
    // Как дойти до выбранной остановки: пешеходный путь по улицам (пока грузится — прямая линия)
    if (origin) {
      var dm = function (s) { return App.vehicles.dist(origin.lat, origin.lon, s.lat, s.lon); };
      var target = focused && first ? first.stop : null;
      if (!target) activeStops.forEach(function (stp) { if (!target || dm(stp) < dm(target)) target = stp; });
      if (target && dm(target) > 30 && dm(target) < 3000) {
        var wk = App.planner.walkCached(origin, target);
        if (wk) data.lines.push({ points: wk.points, kind: 'walk' });
        else {
          data.lines.push({ points: [[origin.lat, origin.lon], [target.lat, target.lon]], kind: 'walk' });
          var gid = g.id;
          App.planner.walk(origin, target).then(function () {
            if (state.detail && state.detail.kind === 'stop' && state.detail.stop.id === gid) renderDetail(true);
          }).catch(function () { /* без сети остаётся прямая линия */ });
        }
      }
    }
    var drawn = {};
    deps.forEach(function (x, i) {
      if (!x.vehicle) return;
      var mine = selDep ? x === selDep : i === 0;
      if (selDep && !mine && x.vehicle.id === (selDep.vehicle && selDep.vehicle.id)) return;
      data.vehicles.push({ id: x.vehicle.id, lat: x.vehicle.lat, lon: x.vehicle.lon, line: x.line, mode: x.mode, mine: mine,
        label: x.line + ' → ' + x.headsign + ' · ' + km(x.vehicle.toStop) + tr(' до остановки') });
      var k = lineKey(x);
      if (!drawn[k] && x.vehicle.path && (mine || (!selDep && (d.lineFilter || x.vehicle.toStop < 4000)))) {
        data.lines.push({ points: x.vehicle.path, kind: mine ? 'approach' : 'transit' });
        drawn[k] = true;
      }
      if (x.vehicle.toStop < 6000 && (mine || !focused)) pts.push([x.vehicle.lat, x.vehicle.lon]);
    });
    mv.setData(data);
    mv.fit(pts, 'stop:' + g.id + ':' + (d.lineFilter || '') + ':' + (d.sel || ''));
    var note = $('map-note');
    note.classList.toggle('is-hidden', App.feed.ok || !App.feed.failed);
    note.textContent = tr('Живой GPS автобусов недоступен, показываю по расписанию');
    var parts = [];
    if (App.feed.at) parts.push(tr('Автобусы обновлены в ') + T.hm(App.feed.at));
    parts.push(d.sel ? tr('нажмите на выбранный рейс ещё раз, чтобы снять выбор') : tr('нажмите на рейс в списке, чтобы увидеть его на карте'));
    $('foot-note').textContent = parts.join(' · ');
  }

  $('map-center').addEventListener('click', function () { if (mapView) mapView.recenter(); });
  $('map-expand').addEventListener('click', function () {
    var d = state.detail;
    if (!d) return;
    d.mapBig = !d.mapBig;
    renderDetail(d.kind === 'line' ? 'line' : true);
    setTimeout(function () {
      if (!mapView) return;
      mapView.resize();
      mapView.recenter();
      if (d.mapBig) document.querySelector('#detail .map-box').scrollIntoView({ block: 'start', behavior: 'smooth' });
    }, 60);
  });
  $('detail-star').addEventListener('click', function () {
    var d = state.detail;
    if (!d || d.kind !== 'trip') return;
    var p = d.place;
    if (p.temp || !App.places.get(p.id)) {
      placeSheet({ address: p.name, sub: p.address, lat: p.lat, lon: p.lon }, null);
      return;
    }
    // Убрать звёздочку = удалить место совсем; экран остаётся открытым, звёздочкой можно сохранить снова
    var saved = App.places.get(p.id);
    var idx = App.places.indexOf(p.id);
    App.places.remove(p.id);
    d.place = { id: p.id, name: p.name, address: p.address, sub: p.sub, lat: p.lat, lon: p.lon, temp: true };
    renderDetail(true);
    toast(tr('Место удалено'), { label: tr('Вернуть'), fn: function () {
      App.places.restore(saved, idx);
      if (state.detail && state.detail.place && state.detail.place.id === saved.id) { state.detail.place = saved; renderDetail(true); }
      toast(tr('Место возвращено'));
    } });
  });
  $('detail-more').addEventListener('click', function () {
    var d = state.detail;
    if (!d || d.kind !== 'trip') return;
    var p = App.places.get(d.place.id);
    if (p) placeSheet({ address: p.address, sub: p.sub, lat: p.lat, lon: p.lon }, p);
  });

  // ---------- Напоминания и виджет ----------
  // Первый вариант, на который ещё успеваем.
  function nextOption(trip, now) {
    for (var i = 0; i < trip.options.length; i++) {
      if (trip.status(trip.options[i], now) !== 'late') return trip.options[i];
    }
    return null;
  }
  function linesText(opt) {
    return opt.legs.filter(function (l) { return l.transit; }).map(function (l) { return l.line; }).join(' › ');
  }
  var MODE_WORD = { BUS: tr('Автобус'), TRAM: tr('Трамвай'), TROLLEYBUS: tr('Троллейбус'), RAIL: tr('Поезд'), FERRY: tr('Паром') };

  // Напоминание разовое: на ближайшую поездку. Время пересчитывается по GPS, пока приложение открыто;
  // если приложение закрыто, уведомление придёт по последнему расчёту.
  function syncReminders() {
    var now = Date.now();
    App.places.all().forEach(function (p) {
      if (!p.remind) return;
      if (p.remindAt && now > p.remindAt + 60000) {
        App.places.update(p.id, { remind: false, remindAt: null, remindKey: null });
        App.native.cancel(p.id);
        if (state.detail && state.detail.place && state.detail.place.id === p.id) renderDetail(true);
        return;
      }
      var trip = tripFor(p);
      // Новое напоминание — на ближайший рейс, до выхода к которому ещё есть хотя бы минута.
      var opt = null;
      for (var i = 0; i < trip.options.length && !opt; i++) {
        if (trip.timing(trip.options[i], now).leaveAt > now + 60000) opt = trip.options[i];
      }
      if (!opt && p.remindKey) opt = nextOption(trip, now);
      if (!opt) return;
      var t = trip.timing(opt, now);
      var key = Trip_key(opt);
      // Уже напоминаем про конкретный рейс — не перескакиваем на следующий, пока он не уйдёт.
      if (p.remindKey && p.remindKey !== key && p.remindAt && now < p.remindAt + 60000) {
        var same = trip.options.filter(function (o) { return Trip_key(o) === p.remindKey; })[0];
        if (same) { opt = same; t = trip.timing(opt, now); key = p.remindKey; }
      }
      if (p.remindAt && p.remindKey === key && Math.abs(p.remindAt - t.leaveAt) < 30000) return;
      var ft = opt.firstTransit;
      // Автобус по GPS сдвинулся на 3+ минуты относительно того, что мы уже сказали, — предупредить.
      var told = p.remindKey === key ? (p.remindTold || p.remindAt) : null;
      if (told && t.gps && Math.abs(t.leaveAt - told) >= 3 * 60000 && told - now < 20 * 60000 && t.leaveAt > now) {
        var shift = Math.round((t.leaveAt - told) / 60000);
        App.native.notifyNow(p.id, (shift > 0 ? tr('Автобус опаздывает · ') : tr('Автобус идёт раньше · ')) + p.name,
          linesText(opt) + (shift > 0 ? tr(' опаздывает на ') + shift : tr(' идёт раньше на ') + (-shift)) + ' ' + T.minutesWord(Math.abs(shift)) +
          tr('. Выходи в ') + T.hm(t.leaveAt) + '.');
        told = t.leaveAt;
      }
      var body = (MODE_WORD[ft.mode] || tr('Транспорт')) + ' ' + linesText(opt) + tr(' с остановки ') + ft.stopName + tr(' в ') + T.hm(t.busAt) +
        (t.gps ? tr(' (по GPS)') : '') + tr('. Пешком ') + Math.max(1, Math.round(t.walkMs / 60000)) + tr(' мин.') + tr(' Расчёт: ') + originName() + '.';
      App.native.schedule(p.id, [
        { k: 1, at: t.leaveAt - 5 * 60000, title: tr('Через 5 минут выходить · ') + p.name, body: body },
        { k: 2, at: t.leaveAt, title: tr('Пора выходить · ') + p.name, body: body }
      ]);
      App.places.update(p.id, { remindAt: t.leaveAt, remindKey: key, remindTold: told || t.leaveAt });
    });
    syncStopReminder();
  }

  // ---------- 1. Напоминание на конкретный автобус с остановки ----------
  function stopRem() { try { return JSON.parse(localStorage.getItem('pv.stopRem') || 'null'); } catch (e) { return null; } }
  function setStopRem(r) {
    try { if (r) localStorage.setItem('pv.stopRem', JSON.stringify(r)); else localStorage.removeItem('pv.stopRem'); } catch (e) { /* без памяти */ }
  }
  var STOP_REM_ID = 'stop-reminder';
  function stopLeave(x) {
    var walk = x.stop.distance / 80 * 60000 * cfg.walkFactor; // ~80 м/мин пешком (оценка)
    return x.eta - walk - cfg.bufferMinutes * 60000;
  }
  function findDep(r) {
    var g = groupOf(r.stopId);
    if (!g) return null;
    var found = null;
    groupDeps(g).forEach(function (x) { if (!found && x.tripId === r.tripId) found = x; });
    return found;
  }
  function syncStopReminder() {
    var r = stopRem();
    if (!r) return;
    var now = Date.now();
    if (now > r.leaveAt + 60000) { setStopRem(null); App.native.cancel(STOP_REM_ID); if (state.detail && state.detail.kind === 'stop') renderDetail(true); return; }
    var x = findDep(r);
    if (!x) return;                     // нет свежих данных — уведомление уже стоит по последнему расчёту
    var leave = stopLeave(x);
    if (Math.abs(leave - r.leaveAt) < 30000 && r.scheduled) return;
    var title = x.line + ' → ' + x.headsign;
    var body = tr('С остановки ') + r.stopName + tr(' в ') + T.hm(x.eta) + (x.gps ? tr(' (по GPS)') : '') + tr('. Пешком ~') + Math.max(1, Math.round((x.eta - leave) / 60000) - cfg.bufferMinutes) + tr(' мин.') + tr(' Расчёт: ') + originName() + '.';
    if (r.scheduled && x.gps && Math.abs(leave - r.told) >= 3 * 60000 && r.told - now < 20 * 60000 && leave > now) {
      var shift = Math.round((leave - r.told) / 60000);
      App.native.notifyNow(STOP_REM_ID, (shift > 0 ? tr('Автобус опаздывает · ') : tr('Автобус идёт раньше · ')) + title,
        (shift > 0 ? tr('Опаздывает на ') + shift : tr('Идёт раньше на ') + (-shift)) + ' ' + T.minutesWord(Math.abs(shift)) + tr('. Выходи в ') + T.hm(leave) + '.');
      r.told = leave;
    }
    App.native.schedule(STOP_REM_ID, [
      { k: 1, at: leave - 5 * 60000, title: tr('Через 5 минут выходить · ') + title, body: body },
      { k: 2, at: leave, title: tr('Пора выходить · ') + title, body: body }
    ]);
    r.leaveAt = leave;
    r.told = r.told || leave;
    r.scheduled = true;
    setStopRem(r);
  }
  function toggleStopReminder(x, g) {
    var r = stopRem();
    if (r && r.tripId === x.tripId) {
      setStopRem(null);
      App.native.cancel(STOP_REM_ID);
      toast(tr('Напоминание выключено'));
      renderDetail(true);
      return;
    }
    App.native.allow().then(function (ok) {
      if (!ok) { toast(tr('Разрешите уведомления для Kuhu в настройках телефона')); return; }
      setStopRem({ tripId: x.tripId, stopId: x.stop.id, stopName: g.name, line: x.line, headsign: x.headsign, leaveAt: stopLeave(x), told: null, scheduled: false });
      syncStopReminder();
      toast((r ? tr('Напоминание перенесено: ') : tr('Напомню про ')) + x.line + ' → ' + x.headsign + tr(' в ') + T.hm(x.eta));
      renderDetail(true);
    });
  }

  function toggleReminder(p) {
    if (p.remind) {
      App.places.update(p.id, { remind: false, remindAt: null, remindKey: null });
      App.native.cancel(p.id);
      toast(tr('Напоминание выключено'));
      renderDetail(true);
      return;
    }
    App.native.allow().then(function (ok) {
      if (!ok) { toast(tr('Разрешите уведомления для Kuhu в настройках телефона')); return; }
      App.places.update(p.id, { remind: true, remindAt: null, remindKey: null });
      syncReminders();
      toast(tr('Напомню за 5 минут и когда пора выходить'));
      renderDetail(true);
    });
  }

  function syncWidget() {
    if (!App.native.hasWidget) return;
    var now = Date.now();
    var items = App.places.favorites().slice(0, 3).map(function (p) {
      var trip = tripFor(p);
      var opt = nextOption(trip, now);
      if (!opt) return { name: p.name, leaveAt: 0, note: trip.loading ? tr('считаю…') : trip.error === 'here' ? tr('вы уже здесь') : tr('нет рейсов') };
      var t = trip.timing(opt, now);
      return { name: p.name, leaveAt: Math.round(t.leaveAt / 15000) * 15000, line: linesText(opt), stop: opt.firstTransit.stopName, gps: t.gps };
    });
    App.native.widget({ updated: now, items: items });
  }

  $('detail-bell').addEventListener('click', function () {
    var d = state.detail;
    if (d && d.kind === 'stop' && d.remDep) { toggleStopReminder(d.remDep, d.stop); return; }
    if (!d || d.kind !== 'trip') return;
    var p = App.places.get(d.place.id);
    if (p) toggleReminder(p);
  });

  // ---------- Рядом ----------
  // Одноимённые остановки (две стороны улицы, разные платформы) — одна карточка.
  // Куда едут автобусы с платформы: «Viru keskus, Pelguranna» (две самые частые конечные).
  function platformLabel(st) {
    var cnt = {};
    st.deps.forEach(function (x) { if (x.headsign) cnt[x.headsign] = (cnt[x.headsign] || 0) + 1; });
    var names = Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a]; });
    return names.slice(0, 2).join(', ') + (names.length > 2 ? '…' : '');
  }
  // Курс движения у платформы (градусы от севера по часовой) — по линии самого частого маршрута.
  function platformBearing(st) {
    if (st.bearing !== undefined && st.bearing !== null) return st.bearing;
    if (st.bearingTried && Date.now() - st.bearingTried < 15000) return null;   // не пересчитывать каждую отрисовку
    st.bearingTried = Date.now();
    var cnt = {};
    st.deps.forEach(function (x) { if (x.pattern) cnt[x.pattern] = (cnt[x.pattern] || 0) + 1; });
    if (!st.deps.length) (st.patterns || []).forEach(function (p) { cnt[p.code] = 1; });   // рейсов скоро нет — по маршрутам платформы
    var codes = Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a]; });
    for (var c = 0; c < codes.length; c++) {
      var pts = App.nearby.pattern(codes[c]);
      if (!pts || pts.length < 2) continue;
      var best = 0, bd = Infinity;
      for (var i = 0; i < pts.length; i++) {
        var dd = App.vehicles.dist(st.lat, st.lon, pts[i][0], pts[i][1]);
        if (dd < bd) { bd = dd; best = i; }
      }
      if (bd > 200) continue;
      var a = pts[Math.min(best, pts.length - 2)], b = pts[Math.min(best, pts.length - 2) + 1];
      var dx = (b[1] - a[1]) * Math.cos(a[0] * Math.PI / 180), dy = b[0] - a[0];
      st.bearing = (Math.atan2(dx, dy) * 180 / Math.PI + 360) % 360;
      return st.bearing;
    }
    return null;
  }
  function dirArrow(deg) {
    return deg === null || deg === undefined ? null : h('span.dir-arrow', { style: 'transform: rotate(' + Math.round(deg) + 'deg)', 'aria-hidden': 'true' });
  }

  // Сторона света по курсу: «на запад», «на северо-восток».
  function compassWord(deg) {
    if (deg === null || deg === undefined) return '';
    var w = [tr('на север'), tr('на северо-восток'), tr('на восток'), tr('на юго-восток'), tr('на юг'), tr('на юго-запад'), tr('на запад'), tr('на северо-запад')];
    return w[Math.round(deg / 45) % 8];
  }
  function angleDiff(a, b) { var d = Math.abs(a - b) % 360; return d > 180 ? 360 - d : d; }
  /*
   * Два направления остановки: «туда» и «обратно». Платформы с похожим курсом (±70°) — одно направление.
   * Подпись — самая частая конечная этого направления. Если курс неизвестен, направление = платформа.
   */
  function buildDirs(g) {
    // Направлений у остановки два: «туда» и «обратно». Делим платформы по курсу автобусов:
    // всё, что идёт ±90° от курса ближайшей платформы, — одно направление, остальное — другое.
    var A = { stops: [], bs: [] }, B = { stops: [], bs: [] }, unknown = [];
    var ref = null;
    g.stops.forEach(function (st) { var b = platformBearing(st); if (ref === null && b !== null) ref = b; });
    g.stops.forEach(function (st) {
      var b = platformBearing(st);
      if (b === null || ref === null) { unknown.push(st); return; }
      var t = angleDiff(b, ref) <= 90 ? A : B;
      t.stops.push(st); t.bs.push(b);
    });
    // Платформы без курса — туда, где больше общих конечных
    function stHeads(st) { return st.deps.length ? st.deps.map(function (x) { return x.headsign; }) : (st.patterns || []).map(function (p) { return p.headsign; }); }
    function heads(list) { var o = {}; list.forEach(function (st) { stHeads(st).forEach(function (hs) { o[hs] = 1; }); }); return o; }
    unknown.forEach(function (st) {
      var ha = heads(A.stops), hb = heads(B.stops), sa = 0, sb = 0;
      stHeads(st).forEach(function (hs) { if (ha[hs]) sa++; if (hb[hs]) sb++; });
      // ничего общего ни с одной стороной, а вторая сторона пуста — это и есть обратное направление
      if (sa === 0 && sb === 0 && A.stops.length && !B.stops.length) { B.stops.push(st); return; }
      (sb > sa ? B : A).stops.push(st);
    });
    var dirs = [A, B].filter(function (d) { return d.stops.length; });
    dirs.forEach(function (d, k) {
      d.id = 'd:' + d.stops[0].id;
      if (d.bs.length) {
        var x = 0, y = 0;
        d.bs.forEach(function (b) { x += Math.sin(b * Math.PI / 180); y += Math.cos(b * Math.PI / 180); });
        d.bearing = (Math.atan2(x, y) * 180 / Math.PI + 360) % 360;
      } else d.bearing = null;
      var cnt = {};
      d.stops.forEach(function (st) { stHeads(st).forEach(function (hs) { if (hs) cnt[hs] = (cnt[hs] || 0) + 1; }); });
      var names = Object.keys(cnt).sort(function (a, b) { return cnt[b] - cnt[a]; });
      d.label = names[0] || g.name;
      d.empty = !d.stops.some(function (st) { return st.deps.length; });
      d.compass = compassWord(d.bearing);
      d.more = names.slice(1, 3);
    });
    return dirs;
  }
  function inDir(g, dirId, x) {
    if (!dirId) return true;
    var d = (g.dirs || []).filter(function (y) { return y.id === dirId; })[0];
    return !d || d.stops.indexOf(x.stop) >= 0;
  }
  // Кнопка направления: стрелка, «На запад» и «к Viru keskus» под ней.
  function dirChipKids(d) {
    // Главное — конечная, как на табло автобуса; стрелка показывает сторону света на карте
    return [dirArrow(d.bearing), h('span.dir-chip-text', null, [
      h('b', { text: tr('К ') + d.label }),
      d.more && d.more.length ? h('small', { text: tr('и ') + d.more.join(', ') }) : null
    ])];
  }

  function groupStops(stops) {
    var map = {};
    var out = [];
    stops.forEach(function (st) {
      var g = map[st.name];
      if (!g) { g = map[st.name] = { id: 'g:' + st.name, name: st.name, distance: st.distance, lat: st.lat, lon: st.lon, stops: [] }; out.push(g); }
      st.label = platformLabel(st);
      g.stops.push(st);
      if (st.distance < g.distance) { g.distance = st.distance; g.lat = st.lat; g.lon = st.lon; }
    });
    out.sort(function (a, b) { return a.distance - b.distance; });
    out.forEach(function (g) { g.dirs = buildDirs(g); });
    return out;
  }
  function groupOf(stopId) {
    var gs = state.nearby.groups || [];
    for (var i = 0; i < gs.length; i++) if (gs[i].stops.some(function (x) { return x.id === stopId; })) return gs[i];
    return null;
  }

  function loadNearby(force) {
    var n = state.nearby;
    var origin = App.here.origin();
    if (!origin || n.loading) return;
    if (!force && n.at && Date.now() - n.at < 60000 && !App.movedEnough(n.from, origin)) return;
    n.loading = true;
    if (!n.stops.length) renderNearby();
    App.nearby.load(origin.lat, origin.lon).then(function (stops) {
      n.stops = stops;
      n.groups = groupStops(stops);
      n.error = '';
      n.at = Date.now();
      n.from = { lat: origin.lat, lon: origin.lon };
      if (state.detail && state.detail.kind === 'stop') {
        var same = n.groups.filter(function (g) { return g.id === state.detail.stop.id; })[0];
        if (same) { state.detail.stop = same; renderDetail(true); }
      }
    }).catch(function (e) {
      n.error = tr('Нет связи с Peatus.ee');
    }).then(function () {
      n.loading = false;
      renderNearby();
      renderLiveMap();
    });
  }

  function renderNearby() {
    var box = $('nearby');
    var n = state.nearby;
    n.scroll = {};
    Array.prototype.forEach.call(box.querySelectorAll('.stop-card'), function (c) {
      var r = c.querySelector('.dir-chips');
      if (r && r.scrollLeft) n.scroll[c.getAttribute('data-stop')] = r.scrollLeft;
    });
    clear(box);
    var origin = App.here.origin();
    if (!origin) {
      box.appendChild(h('div.empty', null, [icon('gps', 'empty-ic'), h('h2', { text: tr('Где вы?') }),
        h('p', { text: App.here.denied
          ? tr('Доступ к геолокации запрещён. Откройте настройки телефона → Приложения → Kuhu → Разрешения и включите «Местоположение». Или выберите, откуда считать, вручную.')
          : App.here.error || tr('Разрешите геолокацию или выберите, откуда считать, чтобы увидеть ближайшие остановки.') }),
        h('button.btn', { type: 'button', on: { click: function () { App.here.retry(); } } }, [icon('gps'), h('span', { text: App.here.denied ? tr('Проверить снова') : tr('Включить GPS') })]),
        h('button.btn.btn-quiet', { type: 'button', on: { click: originSheet } }, [h('span', { text: tr('Выбрать, откуда считать') })])]));
      return;
    }
    if (n.loading && !n.stops.length) {
      for (var i = 0; i < 3; i++) box.appendChild(h('div.skeleton-card', null, [h('span.sk.sk-title'), h('span.sk.sk-line'), h('span.sk.sk-line.sk-short')]));
      return;
    }
    if (n.error && !n.stops.length) {
      box.appendChild(h('div.empty', null, [icon('warn', 'empty-ic'), h('h2', { text: tr('Нет связи') }), h('p', { text: n.error + tr('. Проверьте интернет.') }),
        h('button.btn', { type: 'button', on: { click: function () { loadNearby(true); } } }, [icon('refresh'), h('span', { text: tr('Повторить') })])]));
      return;
    }
    if (!(n.groups || []).length) {
      box.appendChild(h('div.empty', null, [icon('signpost', 'empty-ic'), h('h2', { text: tr('Остановок рядом нет') }), h('p', { text: tr('В радиусе 700 м нет остановок.') })]));
      return;
    }
    var now = Date.now();
    n.dir = n.dir || {};
    // В списке — остановки, откуда что-то уходит в ближайшие 2 часа. Ночью рейсов нет нигде — тогда показываем
    // ближайшие остановки и какие линии на них ходят, чтобы можно было посмотреть расписание
    var quiet = !n.stops.some(function (st) { return st.deps.length; });
    if (quiet) box.appendChild(h('p.foot-note.quiet-note', { text: tr('Сейчас рейсов нет — ночь или перерыв. Ниже остановки рядом и линии, которые здесь ходят; время ближайшего рейса — на экране остановки.') }));
    (n.groups || []).filter(function (g) { return quiet || g.stops.some(function (st) { return st.deps.length; }); }).slice(0, 8).forEach(function (g) {
      var oldRow = n.scroll && n.scroll[g.id];
      var dirId = n.dir[g.id] || null;
      if (dirId && !g.dirs.some(function (d) { return d.id === dirId; })) dirId = null;
      var deps = groupDeps(g).filter(function (x) { return inDir(g, dirId, x); });
      // по одному ближайшему на каждую линию с направлением — так видно, что вообще отсюда ходит
      var seen = {};
      var top = deps.filter(function (x) { var k = lineKey(x); if (seen[k]) return false; seen[k] = true; return true; }).slice(0, 5);
      var rows = top.map(function (x) {
        var m = minutes(x.eta - now);
        return h('span.mini-dep' + (x.gps ? '.is-live' : ''), null, [
          lineBadge(x.mode, x.line),
          h('span.mini-head', { text: x.headsign }),
          h('span.mini-when', { text: m <= 0 ? tr('сейчас') : m + tr(' мин') })
        ]);
      });
      var lineCount = Object.keys(seen).length;
      if (!rows.length) {
        var pats = stopPatterns(g, { dirFilter: dirId });
        if (pats.length) {
          lineCount = pats.length;
          rows = pats.slice(0, 5).map(function (pt) { return h('span.mini-dep', null, [lineBadge(pt.mode, pt.line), h('span.mini-head', { text: pt.headsign })]); });
          top = rows;
        } else rows.push(h('span.mini-head', { text: dirId ? tr('В эту сторону в ближайшие 2 часа рейсов нет') : tr('В ближайшие 2 часа ничего') }));
      }
      var dirChips = null;
      if (g.dirs.length > 1) {
        dirChips = h('div.dir-chips', { role: 'radiogroup', 'aria-label': tr('Направление') });
        var mk = function (id, kids, label) {
          var on = (dirId || '') === (id || '');
          return h('button.dir-chip' + (on ? '.is-on' : ''), { type: 'button', role: 'radio', 'aria-checked': String(on), 'aria-label': label, on: { click: function () {
            n.dir[g.id] = id;
            renderNearby();
          } } }, kids);
        };
        g.dirs.forEach(function (dd) {
          dirChips.appendChild(mk(dd.id, dirChipKids(dd), tr('В сторону ') + dd.label));
        });
        dirChips.appendChild(mk(null, [h('span', { text: tr('Оба') })], tr('Оба направления')));
      }
      if (dirChips && oldRow) setTimeout(function () { dirChips.scrollLeft = oldRow; }, 0);
      box.appendChild(h('div.stop-card', { 'data-stop': g.id }, [
        h('button.stop-open', { type: 'button', on: { click: function () { openStop(g, dirId); } } }, [
          h('span.stop-head', null, [
            h('span.stop-name', { text: g.name }),
            h('span.stop-dist', { text: km(g.distance) })
          ]),
          h('span.stop-dir', { text: !lineCount ? (dirId ? tr('В эту сторону рейсов скоро нет') : tr('Рейсов скоро нет')) : lineCount + ' ' + T.plural(lineCount, tr('маршрут'), tr('маршрута'), tr('маршрутов')) +
            (dirId ? tr(' в эту сторону') : g.dirs.length > 1 ? tr(' в обе стороны') : '') })
        ]),
        dirChips,
        h('button.stop-open', { type: 'button', on: { click: function () { openStop(g, dirId); } } }, [
          h('span.mini-deps', null, rows),
          lineCount > top.length ? h('span.stop-more', { text: tr('Ещё ') + (lineCount - top.length) + tr(' — откройте остановку') }) : null
        ])
      ]));
    });
    if (n.error && n.at) box.appendChild(h('p.foot-note.is-warn', { text: tr('Нет связи с Peatus.ee — показаны данные от ') + T.hm(n.at) }));
    if (!App.feed.ok && App.feed.failed) box.appendChild(h('p.foot-note', { text: tr('Живой GPS автобусов недоступен — время по расписанию.') }));
    if (state.detail && state.detail.kind === 'stop') markCurrent('[data-stop="' + state.detail.stop.id + '"]');
  }

  // ---------- Карта всего транспорта ----------
  var live = { view: null, filter: 'ALL', centered: false, sel: null, route: null, routeFor: null };
  var MODE_NAME = { BUS: tr('Автобус'), TRAM: tr('Трамвай'), TROLLEYBUS: tr('Троллейбус') };
  try { live.filter = localStorage.getItem('pv.liveFilter') || 'ALL'; } catch (e) { /* по умолчанию все */ }
  if (live.filter === 'STOPS') live.filter = 'ALL';   // вкладки «Остановки» больше нет

  function ensureLiveMap() {
    if (live.view) return live.view;
    live.view = App.mapView.create($('live-map'));
    live.view.map.on('moveend', function () { renderLiveMap(); });
    return live.view;
  }

  // Остановки у центра карты, когда её увели от «Отсюда»
  var panTimer = null;
  function panLoad(c) {
    clearTimeout(panTimer);
    panTimer = setTimeout(function () {
      var from = { lat: c.lat, lon: c.lng };
      App.nearby.load(from.lat, from.lon).then(function (stops) {
        live.pan = { from: from, stops: stops, groups: groupStops(stops) };
        renderLiveMap();
      }).catch(function () { /* без сети остановки просто не рисуем */ });
    }, 600);
  }

  function renderLiveMap() {
    if (state.tab !== 'map') return;
    var mv = ensureLiveMap();
    var map = mv.map;
    var origin = App.here.origin();
    // Центр карты следует за «Отсюда»: первый GPS-фикс после «пока от дома», смена дома/точки/режима.
    // Дрейф GPS карту не двигает, чтобы не выдёргивать её из-под пальца.
    var okey = !origin ? '' : origin.fallback ? 'fallback' : (origin.pick || origin.home || origin.work) ? origin.lat.toFixed(4) + ',' + origin.lon.toFixed(4) : 'gps';
    if (origin && live.originKey !== okey) { live.originKey = okey; map.setView([origin.lat, origin.lon], 15, { animate: false }); return; } // moveend перерисует
    var bounds = map.getBounds().pad(0.25);
    var c = map.getCenter();
    // Выбранная машина: найти её свежие координаты
    var selV = null;
    if (live.sel) App.feed.vehicles.forEach(function (v) { if (v.id === live.sel.id) selV = v; });
    var list = App.feed.vehicles.filter(function (v) {
      if (live.sel && v.id === live.sel.id) return true;
      if (live.sel) return v.mode === live.sel.mode && String(v.line) === String(live.sel.line) && bounds.contains([v.lat, v.lon]);
      return (live.filter === 'ALL' || v.mode === live.filter) && bounds.contains([v.lat, v.lon]);
    });
    // На мелком масштабе машин сотни — оставляем ближайшие к центру, чтобы карта не тормозила.
    if (list.length > 250) {
      list.sort(function (a, b) { return App.vehicles.dist(a.lat, a.lon, c.lat, c.lng) - App.vehicles.dist(b.lat, b.lon, c.lat, c.lng); });
      list = list.slice(0, 250);
    }
    var data = { lines: [], stops: [], vehicles: list.map(function (v) {
      var label = (MODE_NAME[v.mode] || tr('Транспорт')) + ' ' + v.line + (v.destination ? ' → ' + v.destination : '');
      return { id: v.id || (v.mode + v.line + v.lat), lat: v.lat, lon: v.lon, line: v.line, mode: v.mode,
        mine: !!(live.sel && v.id === live.sel.id), label: label,
        onTap: function () { selectVehicle(v); } };
    }) };
    if (live.sel && live.route && live.routeFor === live.sel.id) {
      data.lines.push({ points: live.route.points, kind: 'route' });
      data.routeStops = live.route.stops;
      // путь от машины до конечной — тот же янтарь, но ярче
      if (selV) {
        var onP = App.vehicles.onPattern(live.route.points, selV, live.route.points[live.route.points.length - 1][0], live.route.points[live.route.points.length - 1][1]);
        if (onP && onP.path) data.lines.push({ points: onP.path, kind: 'approach' });
      }
    }
    applyMe(data);
    if (map.getZoom() >= 14) {
      // Остановки вокруг центра карты (а не только вокруг «Отсюда»): если карту увели далеко — подгружаем заново
      var n0 = state.nearby, src = null;
      if (n0.from && App.vehicles.dist(c.lat, c.lng, n0.from.lat, n0.from.lon) < 450) src = { stops: n0.stops, groups: n0.groups || [] };
      else if (live.pan && App.vehicles.dist(c.lat, c.lng, live.pan.from.lat, live.pan.from.lon) < 450) src = live.pan;
      else panLoad(c);
      if (src) src.stops.forEach(function (st) {
        var g = null;
        src.groups.forEach(function (x) { if (!g && x.stops.some(function (y) { return y.id === st.id; })) g = x; });
        data.stops.push({ lat: st.lat, lon: st.lon, bearing: platformBearing(st), active: !!(state.detail && state.detail.stop && g && state.detail.stop.id === g.id),
          onTap: function () { if (g) openStop(g); } });
      });
    }
    mv.setData(data);
    // Полоска «Транспорт на карте: N · обновлено в …» убрана; показываем её только когда что-то не так
    var status = $('live-status');
    var warn = !App.feed.ok && App.feed.failed;
    status.classList.toggle('is-warn', warn);
    status.classList.toggle('is-hidden', !warn);
    status.textContent = warn ? tr('Живой GPS транспорта недоступен') : '';
  }

  // Нажали на машину: показать её маршрут целиком и куда она едет.
  function selectVehicle(v) {
    live.sel = { id: v.id, line: v.line, mode: v.mode, destination: v.destination };
    live.route = null;
    live.routeFor = null;
    var card = $('live-card');
    card.classList.remove('is-hidden');
    var badge = $('live-card-badge');
    clear(badge);
    badge.appendChild(lineBadge(v.mode, v.line));
    $('live-card-title').textContent = (MODE_NAME[v.mode] || tr('Транспорт')) + ' ' + v.line + (v.destination ? ' → ' + v.destination : '');
    $('live-card-sub').textContent = tr('Ищу маршрут…');
    renderLiveMap();
    App.nearby.routeFor(v).then(function (r) {
      if (!live.sel || live.sel.id !== v.id) return;
      if (!r) { $('live-card-sub').textContent = tr('Маршрут этого транспорта не нашла (возможно, объезд или рейс в депо)'); return; }
      live.route = r;
      live.routeFor = v.id;
      var n = r.stops.length;
      $('live-card-sub').textContent = n + ' ' + T.plural(n, tr('остановка'), tr('остановки'), tr('остановок')) + ' · ' + (r.stops[0] ? r.stops[0].name : '') + ' → ' + r.headsign;
      ensureLiveMap().map.fitBounds(L.latLngBounds(r.points), { padding: [40, 40], maxZoom: 16 });
      renderLiveMap();
    }).catch(function () {
      if (live.sel && live.sel.id === v.id) $('live-card-sub').textContent = tr('Нет связи с Peatus.ee');
    });
  }
  $('live-card-close').addEventListener('click', function () {
    live.sel = null; live.route = null; live.routeFor = null;
    $('live-card').classList.add('is-hidden');
    renderLiveMap();
  });

  Array.prototype.forEach.call(document.querySelectorAll('#live-filter button'), function (b) {
    b.setAttribute('aria-checked', String(b.getAttribute('data-mode') === live.filter));
    b.addEventListener('click', function () {
      live.filter = b.getAttribute('data-mode');
      try { localStorage.setItem('pv.liveFilter', live.filter); } catch (e) { /* без памяти */ }
      Array.prototype.forEach.call(document.querySelectorAll('#live-filter button'), function (x) { x.setAttribute('aria-checked', String(x === b)); });
      renderLiveMap();
    });
  });
  $('live-me').addEventListener('click', function () {
    // Показываем настоящее место телефона, а не выбранные «Дом» или «Работа»
    var o = App.here.gps;
    if (!o) { App.here.retry(); toast(App.here.error || tr('Ищу GPS…')); return; }
    ensureLiveMap().map.setView([o.lat, o.lon], Math.max(15, ensureLiveMap().map.getZoom()), { animate: true });
  });

  // ---------- Расписание (как transport.tallinn.ee) ----------
  var tt = { list: null, error: '', mode: 'BUS', q: '', loading: false };
  try { tt.mode = localStorage.getItem('pv.ttMode') || 'BUS'; } catch (e) { /* по умолчанию автобусы */ }
  var TT_MODE = { BUS: tr('Автобусы'), TROLLEYBUS: tr('Троллейбусы'), TRAM: tr('Трамваи'), NIGHT: tr('Ночные') };
  var TT_ORDER = ['BUS', 'TROLLEYBUS', 'TRAM', 'NIGHT'];
  var TT_DAY = { wd: tr('Будни'), sat: tr('Суббота'), sun: tr('Воскресенье') };

  function loadLines() {
    if (tt.list || tt.loading) return;
    tt.loading = true;
    renderLines();
    App.timetable.lines().then(function (list) { tt.list = list; tt.error = ''; }, function () { tt.error = tr('Нет связи с Peatus.ee'); })
      .then(function () { tt.loading = false; renderLines(); });
  }

  function renderLines() {
    var box = $('lines');
    var modesBox = $('line-modes');
    clear(box);
    clear(modesBox);
    if (!tt.list) {
      if (tt.error) {
        box.appendChild(h('div.empty', null, [icon('warn', 'empty-ic'), h('h2', { text: tr('Нет связи') }), h('p', { text: tt.error + tr('. Проверьте интернет.') }),
          h('button.btn', { type: 'button', on: { click: function () { tt.error = ''; loadLines(); } } }, [icon('refresh'), h('span', { text: tr('Повторить') })])]));
      } else {
        var sk = h('div.line-grid');
        for (var i = 0; i < 16; i++) sk.appendChild(h('span.sk.line-tile-sk'));
        box.appendChild(sk);
      }
      return;
    }
    var modes = [];
    tt.list.forEach(function (l) { var c = l.cat || l.mode; if (modes.indexOf(c) < 0) modes.push(c); });
    modes.sort(function (a, b) { return TT_ORDER.indexOf(a) - TT_ORDER.indexOf(b); });
    if (modes.indexOf(tt.mode) < 0) tt.mode = modes[0];
    var q = tt.q.trim().toLowerCase();
    if (!q && modes.length > 1) {
      modes.forEach(function (m) {
        var on = m === tt.mode;
        modesBox.appendChild(h('button.mode-chip.mode-' + m.toLowerCase() + (on ? '.is-on' : ''), { type: 'button', role: 'radio', 'aria-checked': String(on), on: { click: function () {
          tt.mode = m;
          try { localStorage.setItem('pv.ttMode', m); } catch (e) { /* без памяти */ }
          renderLines();
        } } }, [icon(m === 'NIGHT' ? 'moon' : App.modeIcon(m)), h('span', { text: TT_MODE[m] || m })]));
      });
    }
    // С запросом ищем по всем видам транспорта: номер с начала («3» → 3, 34, 34A) или слово из названия
    var list = tt.list.filter(function (l) {
      if (!q) return (l.cat || l.mode) === tt.mode;
      return l.line.toLowerCase().indexOf(q) === 0 || l.name.toLowerCase().indexOf(q) >= 0;
    });
    if (!list.length) { box.appendChild(h('p.foot-note', { text: tr('Такой линии нет.') })); return; }
    var grid = h('div.line-grid');
    list.forEach(function (l) {
      var cur = state.detail && state.detail.kind === 'line' && state.detail.line.key === l.key;
      grid.appendChild(h('button.line-tile.mode-' + l.mode.toLowerCase() + (l.cat === 'NIGHT' ? '.is-night' : '') + (cur ? '.is-current' : ''), { type: 'button', 'data-line': l.key,
        'aria-label': (l.cat === 'NIGHT' ? tr('Ночной автобус') : MODE_NAME[l.mode] || tr('Линия')) + ' ' + l.line + ', ' + l.name, title: l.name, on: { click: function () { openLine(l); } } }, [
        h('b', { text: l.line })
      ]));
    });
    box.appendChild(grid);
    box.appendChild(h('p.foot-note', { text: tr('Расписание Tallinna Linnatransport по данным Peatus.ee.') }));
  }
  $('line-search').addEventListener('input', function () { tt.q = $('line-search').value; renderLines(); });

  function openLine(l) {
    state.prevDetail = null;
    var today = new Date();
    state.detail = { kind: 'line', line: l, key: l.key, day: (function (t) { return l.cat === 'NIGHT' && t === 'wd' ? 'sat' : t; })(App.timetable.typeOf(App.timetable.serviceToday())), dirId: null, dirs: null, stop: null, seq: 0 };
    markCurrent('[data-line="' + l.key + '"]');
    renderDetail('line');
    showDetail();
    loadLineDirs(state.detail);
  }
  function lineDate(d) { return App.timetable.dateFor(d.day); }
  function loadLineDirs(d) {
    var my = ++d.seq;
    d.dirs = null;
    d.err = '';
    App.timetable.directions(d.line, lineDate(d)).then(function (dirs) {
      if (state.detail !== d || my !== d.seq) return;
      d.dirs = dirs;
      // остаёмся в том же направлении, если оно есть в этот день
      var same = d.dirId ? dirs.filter(function (x) { return x.id === d.dirId || x.to === d.dirTo; })[0] : null;
      var dir = same || dirs[0] || null;
      d.dirId = dir ? dir.id : null;
      d.dirTo = dir ? dir.to : '';
      if (d.stop) loadLineTimes(d); else renderDetail('line');
    }, function () {
      if (state.detail !== d || my !== d.seq) return;
      d.err = tr('Нет связи с Peatus.ee. Проверьте интернет.');
      renderDetail('line');
    });
    renderDetail('line');
  }
  function curDir(d) { return (d.dirs || []).filter(function (x) { return x.id === d.dirId; })[0] || null; }
  function loadLineTimes(d) {
    var dir = curDir(d);
    var my = ++d.seq;
    d.times = null;
    d.err = '';
    if (!dir) { renderDetail('line'); return; }
    // та же остановка в этом направлении; если её нет в этот день — по названию
    var st = dir.stops.filter(function (x) { return x.gtfsId === d.stop.gtfsId; })[0] || dir.stops.filter(function (x) { return x.name === d.stop.name; })[0];
    if (!st) { d.times = []; d.noStop = true; renderDetail('line'); return; }
    d.noStop = false;
    d.stop = st;
    App.timetable.times(st.gtfsId, dir.codes, lineDate(d)).then(function (list) {
      if (state.detail !== d || my !== d.seq) return;
      d.times = list;
      renderDetail('line');
      // прокрутить к текущему часу
      setTimeout(function () { var el = document.querySelector('#facts .tt-hour.is-now'); if (el) el.scrollIntoView({ block: 'center' }); }, 30);
    }, function () {
      if (state.detail !== d || my !== d.seq) return;
      d.err = tr('Нет связи с Peatus.ee. Проверьте интернет.');
      renderDetail('line');
    });
    renderDetail('line');
  }
  // Нажали на время — весь этот рейс: остановки и время на каждой
  function openLineTrip(d, x) {
    if (!x.trip) return;
    d.trip = { id: x.trip, sec: x.sec, headsign: x.headsign };
    d.tripData = null;
    d.tripErr = '';
    if (!isSplit()) history.pushState({ pv: 'tt' }, '');
    renderDetail('line');
    $('detail-scroll').scrollTop = 0;
    var t = d.trip;
    App.timetable.trip(t.id, lineDate(d)).then(function (data) {
      if (state.detail !== d || d.trip !== t) return;
      d.tripData = data || { stops: [], points: [] };
      renderDetail('line');
      setTimeout(function () { var el = document.querySelector('#facts .tt-trip .is-here'); if (el) el.scrollIntoView({ block: 'center' }); }, 30);
    }, function () {
      if (state.detail !== d || d.trip !== t) return;
      d.tripErr = tr('Нет связи с Peatus.ee. Проверьте интернет.');
      renderDetail('line');
    });
  }
  // Нажали на остановку в рейсе — экран остановки: что отсюда уходит (по расписанию и GPS). «Назад» вернёт в рейс.
  function openStopFromTimetable(stop) {
    var from = state.detail;
    toast(tr('Загружаю остановку ') + stop.name + '…');
    App.nearby.load(stop.lat, stop.lon, 150).then(function (stops) {
      if (state.detail !== from) return;
      var o = App.here.origin();
      stops.forEach(function (st) { st.distance = o ? App.vehicles.dist(o.lat, o.lon, st.lat, st.lon) : 0; });
      var groups = groupStops(stops);
      var g = groups.filter(function (x) { return x.name === stop.name; })[0] ||
        groups.slice().sort(function (a, b) { return App.vehicles.dist(stop.lat, stop.lon, a.lat, a.lon) - App.vehicles.dist(stop.lat, stop.lon, b.lat, b.lon); })[0];
      if (!g) { toast(tr('С этой остановки в ближайшие 2 часа ничего не уходит')); return; }
      g.fromTT = true;       // расстояние «от вас» тут не показываем
      g.id = 'tt:' + g.id;   // своя группа, не путать с «Рядом»
      state.prevDetail = from;
      if (!isSplit()) history.pushState({ pv: 'tt' }, '');
      state.detail = { kind: 'stop', stop: g, key: '', lineFilter: null, dirFilter: null, sel: null };
      renderDetail(true);
      $('detail-scroll').scrollTop = 0;
      setTimeout(function () { ensureMap().resize(); if (mapView) mapView.recenter(); }, 50);
    }, function () { toast(tr('Нет связи с Peatus.ee')); });
  }
  // Назад с остановки, открытой из расписания, — в тот же рейс. true — обработали.
  function stackBack(fromPop) {
    if (!state.detail || !state.prevDetail) return false;
    state.detail = state.prevDetail;
    state.prevDetail = null;
    renderDetail('line');
    if (state.detail.showMap) setTimeout(function () { ensureMap().resize(); renderLineMap(state.detail); }, 30);
    if (!fromPop && !isSplit() && history.state && history.state.pv === 'tt') silentBack();
    return true;
  }
  function renderLineTrip(d, dir) {
    var facts = $('facts');
    var t = d.trip;
    var date = lineDate(d);
    var mid = new Date(date.getTime()); mid.setHours(0, 0, 0, 0);
    var hm = function (sec) { var hh = Math.floor(sec / 3600) % 24, mm = Math.floor(sec % 3600 / 60); return hh + ':' + String(mm).padStart(2, '0'); };
    $('detail-sub').textContent = tr('Рейс в ') + hm(t.sec) + tr(' от ') + d.stop.name + ' → ' + (t.headsign || (dir ? dir.to : ''));
    if (d.tripErr) { facts.appendChild(h('p.foot-note', { text: d.tripErr })); return; }
    if (!d.tripData) { facts.appendChild(ttSkeleton()); return; }
    var stops = d.tripData.stops;
    if (!stops.length) { facts.appendChild(h('p.foot-note', { text: tr('Не удалось загрузить рейс.') })); return; }
    var isToday = App.timetable.ymd(date) === App.timetable.ymd(App.timetable.serviceToday());
    var nowSec = (Date.now() - mid.getTime()) / 1000;
    // где по расписанию автобус сейчас: последняя пройденная остановка
    var atIdx = -1;
    if (isToday && nowSec >= stops[0].sec && nowSec <= stops[stops.length - 1].sec) {
      stops.forEach(function (s, i) { if (s.sec <= nowSec) atIdx = i; });
    }
    var list = h('ol.tt-trip');
    stops.forEach(function (s, i) {
      var mine = s.stop.gtfsId === d.stop.gtfsId;
      var past = isToday && s.sec < nowSec - 30;
      list.appendChild(h('li', null, [h('button.tt-trip-row' + (mine ? '.is-here' : '') + (past ? '.is-past' : '') + (i === atIdx ? '.is-bus' : '') +
        (i === 0 ? '.is-first' : '') + (i === stops.length - 1 ? '.is-last' : ''), { type: 'button',
        'aria-label': hm(s.sec) + ', ' + s.stop.name + tr('. Какой транспорт здесь останавливается'), on: { click: function () { openStopFromTimetable(s.stop); } } }, [
        h('b.tt-trip-time', { text: hm(s.sec) }),
        h('span.tt-dot', { 'aria-hidden': 'true' }),
        h('span.tt-stop-name', { text: s.stop.name }),
        mine ? h('small', { text: tr('вы здесь садитесь') }) : i === atIdx ? h('small.tt-bus-now', { text: tr('сейчас тут (по расписанию)') }) : null
      ])]));
    });
    facts.appendChild(list);
    var mins = Math.round((stops[stops.length - 1].sec - t.sec) / 60);
    $('foot-note').textContent = tr('Время по расписанию. От ') + d.stop.name + tr(' до конечной ') + mins + tr(' мин.');
  }
  function openLineStop(d, stop) {
    d.stop = stop;
    if (!isSplit()) history.pushState({ pv: 'tt' }, '');
    $('detail-scroll').scrollTop = 0;
    loadLineTimes(d);
  }
  // Из расписания остановки — назад к списку остановок. true — обработали.
  function lineStopBack(fromPop) {
    var d = state.detail;
    if (!d || d.kind !== 'line' || !(d.stop || d.trip)) return false;
    if (d.trip) {   // из рейса — назад к расписанию остановки, к текущему часу
      d.trip = null; d.tripData = null;
      setTimeout(function () { var el = document.querySelector('#facts .tt-hour.is-now'); if (el) el.scrollIntoView({ block: 'center' }); }, 30);
    }
    else { d.stop = null; d.times = null; d.seq++; }
    renderDetail('line');
    if (!fromPop && !isSplit() && history.state && history.state.pv === 'tt') silentBack();
    return true;
  }

  function renderLineDetail(d) {
    var l = d.line;
    var dir = curDir(d);
    $('detail-name').textContent = (l.cat === 'NIGHT' ? tr('Ночной автобус') : MODE_NAME[l.mode] || tr('Линия')) + ' ' + l.line;
    var mb = $('detail-map');
    mb.classList.toggle('is-on', !!d.showMap);
    mb.setAttribute('aria-pressed', String(!!d.showMap));
    mb.setAttribute('aria-label', d.showMap ? tr('Скрыть карту') : tr('Маршрут на карте'));
    if (d.showMap) setTimeout(function () { if (state.detail === d) renderLineMap(d); }, 0);
    $('detail-sub').textContent = d.stop ? d.stop.name + (dir ? ' → ' + dir.to : '') : l.name;
    ['detail-star', 'detail-more', 'detail-bell', 'steps', 'hero'].forEach(function (id) { $(id).classList.add('is-hidden'); });
    clear($('options'));
    $('foot-note').textContent = '';

    // Направление и день
    var box = $('line-chips');
    box.classList.remove('is-hidden');
    clear(box);
    if (d.dirs && d.dirs.length > 1) {
      var dirRow = h('div.chip-row', { role: 'radiogroup', 'aria-label': tr('Направление') });
      d.dirs.forEach(function (x) {
        var on = x.id === d.dirId;
        dirRow.appendChild(h('button.dir-chip' + (on ? '.is-on' : ''), { type: 'button', role: 'radio', 'aria-checked': String(on), 'aria-label': tr('В сторону ') + x.to, on: { click: function () {
          if (x.id === d.dirId) return;
          d.dirId = x.id;
          d.dirTo = x.to;
          if (d.stop) loadLineTimes(d); else renderDetail('line');
        } } }, [h('span.dir-chip-text', null, [h('b', { text: '→ ' + x.to }), h('small', { text: tr('от ') + x.from })])]));
      });
      box.appendChild(dirRow);
    }
    var dayRow = h('div.chip-row', { role: 'radiogroup', 'aria-label': tr('День') });
    var todayType = App.timetable.typeOf(App.timetable.serviceToday());
    ['wd', 'sat', 'sun'].forEach(function (t) {
      var on = d.day === t;
      dayRow.appendChild(h('button.dir-chip.day-chip' + (on ? '.is-on' : ''), { type: 'button', role: 'radio', 'aria-checked': String(on), 'aria-label': TT_DAY[t] + (t === todayType ? tr(', сегодня') : ''), on: { click: function () {
        if (d.day === t) return;
        d.day = t;
        loadLineDirs(d);
      } } }, [h('span.dir-chip-text', null, [h('b', { text: TT_DAY[t] }), t === todayType ? h('small', { text: tr('сегодня') }) : null])]));
    });
    box.appendChild(dayRow);
    box.classList.toggle('is-hidden', !!d.trip);   // в рейсе направление и день уже выбраны

    var facts = $('facts');
    clear(facts);
    if (d.err) {
      facts.appendChild(h('div.empty', null, [icon('warn', 'empty-ic'), h('p', { text: d.err }),
        h('button.btn', { type: 'button', on: { click: function () { loadLineDirs(d); } } }, [icon('refresh'), h('span', { text: tr('Повторить') })])]));
      return;
    }
    if (!d.dirs) { facts.appendChild(ttSkeleton()); return; }
    if (!dir) { facts.appendChild(h('p.foot-note', { text: tr('В этот день линия не ходит.') })); return; }

    if (d.trip) { renderLineTrip(d, dir); return; }
    if (!d.stop) {
      // Остановки направления — нажмите, чтобы открыть расписание
      facts.appendChild(h('p.tt-hint', { text: tr('Выберите остановку, чтобы увидеть расписание') }));
      var list = h('ol.tt-stops');
      dir.stops.forEach(function (st, i) {
        var last = i === dir.stops.length - 1;
        list.appendChild(h('li', null, [h('button.tt-stop' + (i === 0 ? '.is-first' : '') + (last ? '.is-last' : ''), { type: 'button', on: { click: function () { openLineStop(d, st); } } }, [
          h('span.tt-dot', { 'aria-hidden': 'true' }),
          h('span.tt-stop-name', { text: st.name }),
          last ? h('small', { text: tr('конечная') }) : icon('back', 'tt-go')
        ])]));
      });
      facts.appendChild(list);
      return;
    }

    // Расписание остановки по часам
    facts.appendChild(h('button.tt-stop-link', { type: 'button', on: { click: function () { openStopFromTimetable(d.stop); } } }, [
      icon('signpost'), h('span', { text: tr('Все автобусы на остановке ') + d.stop.name }), icon('back', 'tt-go')
    ]));
    if (d.noStop) { facts.appendChild(h('p.foot-note', { text: tr('В этот день в эту сторону отсюда рейсов нет.') })); return; }
    if (!d.times) { facts.appendChild(ttSkeleton()); return; }
    if (!d.times.length) {
      facts.appendChild(h('p.foot-note', { text: d.stop.name === dir.to ? tr('Это конечная — отсюда в эту сторону автобусы не уходят.') : tr('В этот день рейсов нет.') }));
      return;
    }
    var date = lineDate(d);
    var isToday = App.timetable.ymd(date) === App.timetable.ymd(App.timetable.serviceToday());
    var mid = new Date(date.getTime()); mid.setHours(0, 0, 0, 0);   // время в расписании — от полуночи этого дня, ночью бывает 25:30
    var nowSec = (Date.now() - mid.getTime()) / 1000;
    var next = isToday ? d.times.filter(function (x) { return x.sec >= nowSec - 30; })[0] : null;
    // буквы для укороченных рейсов: «a — до Hobujaama»
    var marks = {};
    var letters = 'abcdefg';
    d.times.forEach(function (x) {
      if (x.headsign && x.headsign !== dir.to && !marks[x.headsign] && Object.keys(marks).length < letters.length) marks[x.headsign] = letters.charAt(Object.keys(marks).length);
    });
    if (isToday) {
      facts.appendChild(h('div.tt-next', null, next ? [
        h('span', { text: tr('Ближайший') }),
        h('b', { text: T.hm(mid.getTime() + next.sec * 1000) }),
        h('span', { text: ttIn(next.sec - nowSec) })
      ] : [h('span', { text: tr('Сегодня рейсов больше нет') })]));
    } else {
      facts.appendChild(h('div.tt-next', null, [h('span', { text: TT_DAY[d.day] + ', ' + date.toLocaleDateString(App.i18n.locale(), { day: 'numeric', month: 'long' }) })]));
    }
    var table = h('div.tt-table', { role: 'table', 'aria-label': tr('Расписание по часам') });
    var byHour = {};
    var hours = [];
    d.times.forEach(function (x) {
      var hr = Math.floor(x.sec / 3600);
      if (!byHour[hr]) { byHour[hr] = []; hours.push(hr); }
      byHour[hr].push(x);
    });
    var nowHour = Math.floor(nowSec / 3600);
    hours.forEach(function (hr) {
      var cells = byHour[hr].map(function (x) {
        var past = isToday && x.sec < nowSec - 30;
        var m = String(Math.floor(x.sec % 3600 / 60)).padStart(2, '0');
        var mk = marks[x.headsign];
        return h('button.tt-min' + (past ? '.is-past' : '') + (x === next ? '.is-next' : '') + (x.low ? '.is-low' : ''), { type: 'button', role: 'cell',
          'aria-label': String(hr % 24).padStart(2, '0') + ':' + m + (x.headsign ? tr(', до ') + x.headsign : '') + (x.low ? tr(', низкопольный') : '') + tr('. Показать весь рейс'),
          on: { click: function () { openLineTrip(d, x); } } }, [
          h('span', { text: m }), mk ? h('sup', { text: mk }) : null
        ]);
      });
      table.appendChild(h('div.tt-hour' + (isToday && hr === (next ? Math.floor(next.sec / 3600) : nowHour) ? '.is-now' : '') + (isToday && hr < nowHour ? '.is-past' : ''), { role: 'row' }, [
        h('b.tt-h', { role: 'rowheader', text: String(hr % 24).padStart(2, '0') }),
        h('span.tt-mins', null, cells)
      ]));
    });
    facts.appendChild(table);
    // Рейсы после полуночи (ночные автобусы) относятся к этому дню, но это уже ночь на следующий
    if (d.times.some(function (x) { return x.sec >= 86400; })) {
      var nextDay = new Date(date.getTime() + 86400000);
      var NA = [tr('на воскресенье'), tr('на понедельник'), tr('на вторник'), tr('на среду'), tr('на четверг'), tr('на пятницу'), tr('на субботу')];
      facts.appendChild(h('p.tt-legend', null, [h('span', { text: tr('Время после 00:00 — это уже ночь ') + NA[nextDay.getDay()] + '.' })]));
    }
    if (d.times.some(function (x) { return x.low; })) {
      facts.appendChild(h('p.tt-legend', null, [h('span.tt-low-sample', { text: '12' }), h('span', { text: tr(' — низкопольный автобус (можно с коляской)') })]));
    }
    var legend = Object.keys(marks);
    if (legend.length) {
      facts.appendChild(h('p.tt-legend', null, legend.map(function (hs) { return h('span', null, [h('sup', { text: marks[hs] }), h('span', { text: tr(' — до ') + hs })]); })));
    }
    $('foot-note').textContent = tr('Время по расписанию. Где автобус сейчас — во вкладке «Рядом» или «Карта».');
  }
  // Маршрут линии на карте: линия выбранного направления, остановки и машины этой линии по GPS сейчас
  function renderLineMap(d) {
    var dir = curDir(d);
    var mv = ensureMap();
    var data = { lines: [], vehicles: [], stops: [], routeStops: [] };
    var origin = App.here.origin();
    applyMe(data);
    var pts = [];
    if (d.trip && d.tripData && d.tripData.points.length > 1) {
      data.lines.push({ points: d.tripData.points, kind: 'transit' });
      data.routeStops = d.tripData.stops.map(function (s) { return s.stop; });
      pts = d.tripData.points.slice();
      if (d.stop) data.stop = { lat: d.stop.lat, lon: d.stop.lon, name: d.stop.name };
    } else if (dir) {
      data.lines.push({ points: dir.points, kind: 'transit' });
      data.routeStops = dir.stops;
      pts = dir.points.slice();
      if (d.stop) data.stop = { lat: d.stop.lat, lon: d.stop.lon, name: d.stop.name };
    }
    var l = d.line;
    (App.feed.ok ? App.feed.vehicles : []).forEach(function (v) {
      if (String(v.line).toUpperCase() !== l.line.toUpperCase() || ((v.mode === 'TRAM') !== (l.mode === 'TRAM'))) return;
      var mine = dir && v.destination ? App.vehicles.sameName(v.destination, dir.to) : false;
      data.vehicles.push({ id: v.id, lat: v.lat, lon: v.lon, line: v.line, mode: l.mode, mine: mine,
        label: l.line + (v.destination ? ' → ' + v.destination : '') });
    });
    mv.setData(data);
    mv.fit(d.stop ? [[d.stop.lat, d.stop.lon]].concat(pts) : pts, 'line:' + l.key + ':' + (d.dirId || '') + ':' + (d.stop ? d.stop.gtfsId : '') + ':' + (d.trip && d.tripData ? d.trip.id : ''));
    var note = $('map-note');
    note.classList.toggle('is-hidden', App.feed.ok || !App.feed.failed);
    note.textContent = tr('Живой GPS недоступен — показываю только маршрут');
  }
  $('detail-map').addEventListener('click', function () {
    var d = state.detail;
    if (!d || d.kind !== 'line') return;
    d.showMap = !d.showMap;
    renderDetail('line');
    if (d.showMap) setTimeout(function () { ensureMap().resize(); renderLineMap(d); }, 30);
  });
  function ttIn(sec) {
    var m = Math.round(sec / 60);
    if (m <= 0) return tr('сейчас');
    if (m < 60) return tr('через ') + m + tr(' мин');
    return tr('через ') + Math.floor(m / 60) + tr(' ч ') + (m % 60) + tr(' мин');
  }
  function ttSkeleton() {
    var w = h('div.tt-skel');
    for (var i = 0; i < 6; i++) w.appendChild(h('span.sk.sk-line'));
    return w;
  }

  // ---------- Вкладки ----------
  function setTab(tab) {
    state.tab = tab;
    Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (b) {
      var on = b.getAttribute('data-tab') === tab;
      b.classList.toggle('is-active', on);
      b.setAttribute('aria-current', on ? 'page' : 'false');
    });
    $('view-places').classList.toggle('is-hidden', tab !== 'places');
    $('view-nearby').classList.toggle('is-hidden', tab !== 'nearby');
    $('view-map').classList.toggle('is-hidden', tab !== 'map');
    $('view-lines').classList.toggle('is-hidden', tab !== 'lines');
    // «Отсюда» влияет на места, «Рядом» и карту (центр и остановки вокруг); в расписании — нет
    $('origin').classList.toggle('is-hidden', tab === 'lines');
    if (tab === 'lines') loadLines();
    appEl.classList.toggle('tab-map', tab === 'map');
    if (tab === 'nearby' || tab === 'map') loadNearby(false);
    if (tab === 'map') setTimeout(function () { ensureLiveMap().resize(); renderLiveMap(); }, 30);
    try { localStorage.setItem('pv.tab', tab); } catch (e) { /* без памяти */ }
  }
  Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (b) {
    b.addEventListener('click', function () {
      // на узком экране вкладки видны и поверх остановки или поездки — нажатие возвращает в раздел
      if (state.detail && !isSplit()) closeDetail();
      setTab(b.getAttribute('data-tab'));
    });
  });

  // ---------- События ----------
  $('search').addEventListener('input', onSearch);
  $('search').addEventListener('focus', function () { if (!$('search').value.trim()) renderRecent(); });
  $('search').addEventListener('blur', function () {
    setTimeout(function () { if (!$('search').value.trim() && document.activeElement !== $('search')) renderSuggest([], ''); }, 150);
  });
  $('search').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { var f = $('suggest').querySelector('.suggest-item'); if (f) f.click(); }
    if (e.key === 'Escape') resetSearch();
  });
  $('search-clear').addEventListener('click', function () { resetSearch(); $('search').focus(); });
  $('search-map').addEventListener('click', pickDestination);
  $('btn-settings').addEventListener('click', settingsSheet);
  $('origin').addEventListener('click', originSheet);
  App.places.onChange(function () { renderPlaces(); });
  splitMq.addEventListener('change', function () { if (mapView) setTimeout(function () { mapView.resize(); }, 50); });

  var lastOrigin = null;
  App.onLive(function (kind) {
    if (kind === 'here') {
      renderOrigin();
      var o = App.here.origin();
      if (o && App.movedEnough(lastOrigin, o)) {
        lastOrigin = { lat: o.lat, lon: o.lon };
        renderPlaces();
        if (state.tab === 'nearby' || state.tab === 'map') loadNearby(false);
        if (state.tab === 'map') renderLiveMap();
        if (state.detail && state.detail.kind === 'trip') {
          state.detail.trip.refresh(o, { withStops: true }).then(function () { renderDetail(true); });
        }
      }
    }
    if (kind === 'feed') {
      tickPlaces();
      if (state.tab === 'nearby') renderNearby();
      if (state.tab === 'map') renderLiveMap();
      if (state.detail) renderDetail(true);
      updateRideFab();
    }
  });

  // Раз в секунду — отсчёты; маршрут открытой поездки — раз в planSeconds; «Рядом» — раз в минуту.
  setInterval(function () {
    if (document.hidden) return;
    tickPlaces();
    updateRideFab();
    var d = state.detail;
    if (d) {
      renderDetail(false);
      var o = App.here.origin();
      if (d.kind === 'trip' && o && d.trip.stale(o, cfg.planSeconds)) {
        d.trip.refresh(o, { withStops: true }).then(function () { renderDetail(true); tickPlaces(); });
      }
    }
    var origin = App.here.origin();
    if (origin) Object.keys(cardRefs).forEach(function (id) {
      var tr = cardRefs[id].trip;
      if (tr.stale(origin, cfg.listPlanSeconds)) enqueue(tr);
    });
    if (state.tab === 'nearby' || state.tab === 'map') loadNearby(false);
    if (origin) App.places.all().forEach(function (p) {
      if (p.remind && !cardRefs[p.id]) { var tr = tripFor(p); if (tr.stale(origin, cfg.listPlanSeconds)) enqueue(tr); }
    });
    if (stopRem()) loadNearby(false);
    if (Date.now() % 5000 < 1000) { syncReminders(); syncWidget(); }
  }, 1000);

  // Приложение свёрнуто — не тратим батарею и трафик.
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { syncReminders(); syncWidget(); App.feed.stop(); App.here.stop(); }
    else {
      App.feed.start(); App.here.start(); setTimeout(autoCheckUpdate, 1500);
      // Вернулись в приложение: время и место устарели — пересчитать всё сразу
      Object.keys(cardRefs).forEach(function (id) { cardRefs[id].trip.planAt = 0; });
      if (state.detail && state.detail.trip) state.detail.trip.planAt = 0;
    }
  });

  // ---------- Кнопка и жест «назад» на Android ----------
  // Закрываем по порядку то, что открыто внутри приложения; из главного экрана — свернуть, а не закрыть.
  function handleBack() {
    if (state.detail && state.detail.riding) { closeDetail(); return true; }
    if (picker.open) { closePicker(); return true; }
    if (onb.open) { if (onb.step > 0 && onb.step < WIZ.length) setupWizard(onb.step - 1, -1); return true; }
    if (sheetOpen) { closeSheet(); return true; }
    if (document.activeElement === $('search') || $('search').value || !$('suggest').classList.contains('is-hidden')) {
      resetSearch(); $('search').blur(); return true;
    }
    if (stackBack()) return true;
    if (lineStopBack()) return true;
    if (state.detail) { closeDetail(); return true; }
    if (live.sel) { $('live-card-close').click(); return true; }
    if (state.tab !== 'places') { setTab('places'); return true; }
    return false;
  }
  (function () {
    var C = window.Capacitor;
    if (!(C && C.isNativePlatform && C.isNativePlatform())) return;
    var CapApp = (C.Plugins && C.Plugins.App) || (C.registerPlugin ? C.registerPlugin('App') : null);
    if (!CapApp || !CapApp.addListener) return;
    CapApp.addListener('backButton', function () { if (!handleBack() && CapApp.minimizeApp) CapApp.minimizeApp(); });
  })();
  App.handleBack = handleBack;

  // ---------- Старт ----------
  App.applyTheme();
  resumeSetup();
  App.here.start();
  App.feed.start();
  renderOrigin();
  renderPlaces();
  var savedTab = 'places';
  try { savedTab = localStorage.getItem('pv.tab') || 'places'; } catch (e) { /* по умолчанию */ }
  setTab(['nearby', 'map', 'lines'].indexOf(savedTab) >= 0 ? savedTab : 'places');
  setTimeout(autoCheckUpdate, 5000);
  App.update.ready();
  // Высота таб-бара — чтобы экран остановки или поездки не закрывал вкладки на узком экране
  function syncTabbarH() { var tb = document.querySelector('.tabbar'); if (tb) document.documentElement.style.setProperty('--tabbar-h', tb.offsetHeight + 'px'); }
  syncTabbarH();
  window.addEventListener('resize', syncTabbarH);

  App.ui = { openTrip: openTrip, openStop: openStop, state: state, toast: toast };
})(window.App = window.App || {});
