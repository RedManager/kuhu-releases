/*
 * Поездка «отсюда → место»: варианты от Peatus.ee + «наш» автобус по GPS.
 * Логика та же, что на экране гостя в ТВ-версии:
 *  1. Peatus.ee даёт варианты и рейс по расписанию;
 *  2. по расписанию остановки понимаем, какой по очереди автобус этой линии — наш;
 *  3. по GPS находим его, считаем путь по дороге до остановки (~20 км/ч, оценка);
 *  4. «выходи» = прибытие автобуса − дорога пешком − запас − сборы.
 */
(function (App) {
  'use strict';

  var SOON_MS = 10 * 60000;
  var GO_MS = 3 * 60000;

  function Trip(place) {
    this.place = place;
    this.options = [];
    this.deps = {};
    this.locks = {};
    this.stops = {};
    this.est = {};
    this.loading = true;
    this.error = '';
    this.updated = 0;
    this.inFlight = false;
    this.planFrom = null;
    this.planAt = 0;
  }

  function tripKey(o) { return o.firstTransit.tripId || String(o.start); }
  Trip.key = tripKey;

  // Машины нужной линии, которые едут к нашей остановке в нужную сторону.
  Trip.prototype.nearby = function (opt) {
    if (!opt) return { mine: null, others: [] };
    var self = this;
    var tl = null;
    opt.legs.forEach(function (l) { if (!tl && l.transit) tl = l; });
    var ft = opt.firstTransit;
    var now = Date.now();
    var key = tripKey(opt);
    var exclude = [];
    var skip = [];
    Object.keys(self.locks).forEach(function (k) {
      if (k !== key) { exclude.push(self.locks[k]); skip.push(k); }
    });
    var rank = App.vehicles.rankOf(self.deps[ft.stopId], ft, now, skip);
    var near = App.vehicles.approaching(App.feed.vehicles, ft, tl ? tl.points : null, rank, (ft.departure - now) / 60000,
      { lockId: self.locks[key], exclude: exclude, others: App.nearby.cachedOthers(ft.line, ft.mode) });
    // Автобус ближе 1,5 км — закрепляем за рейсом, чтобы не спутать со следующим.
    if (near.mine && !self.locks[key] && near.mine.toStop < 1500) self.locks[key] = near.mine.id;
    return near;
  };

  Trip.prototype.timing = function (opt, now) {
    var cfg = App.config;
    var ft = opt.firstTransit;
    var near = this.nearby(opt);
    if (near.departed) return { departed: true, near: near };
    var busAt = ft.departure;
    var gps = false;
    var gpsAt = App.feed.at;
    if (near.mine && gpsAt) {
      // Считаем от момента GPS-снимка, а не от «сейчас», иначе отсчёт стоит между обновлениями.
      // Мелкие скачки вверх (до 45 с) игнорируем, чтобы цифры шли ровно вниз.
      var key = tripKey(opt);
      var prev = this.est[key];
      if (prev && prev.gpsAt === gpsAt) {
        busAt = prev.busAt;
      } else {
        busAt = gpsAt + near.mine.toStop / App.vehicles.SPEED * 60000;
        if (near.mine.viaLoop) busAt = Math.max(busAt, ft.departure);   // после разворота раньше расписания не уйдёт
        if (prev && busAt > prev.busAt && busAt - prev.busAt < 45000) busAt = prev.busAt;
        this.est[key] = { gpsAt: gpsAt, busAt: busAt };
      }
      gps = true;
    }
    var walk = Math.max(0, ft.departure - opt.start) * cfg.walkFactor;
    var latest = busAt - walk;
    return {
      busAt: busAt, latest: latest, walkMs: walk,
      leaveAt: latest - (cfg.bufferMinutes + cfg.prepMinutes) * 60000,
      gps: gps, near: near, sched: ft.departure
    };
  };

  Trip.prototype.status = function (opt, now) {
    if (!opt) return this.loading ? 'loading' : 'none';
    var t = this.timing(opt, now);
    if (t.departed || now > t.latest) return 'late';
    var left = t.leaveAt - now;
    if (left <= GO_MS) return 'go';
    if (left <= SOON_MS) return 'soon';
    return 'relax';
  };

  // Убрать варианты, на которые уже не успеть. Возвращает true, если список изменился.
  Trip.prototype.prune = function (now) {
    var self = this;
    var before = self.options.length;
    self.options = self.options.filter(function (o) {
      var t = self.timing(o, now);
      var keep = !t.departed && now <= t.latest;
      if (!keep && tripKey(o) !== self.pinKey) delete self.locks[tripKey(o)];   // за выбранным рейсом продолжаем следить
      return keep;
    });
    return self.options.length !== before;
  };

  Trip.prototype.refresh = function (origin, opts) {
    var self = this;
    opts = opts || {};
    if (self.inFlight || !origin) return Promise.resolve(false);
    if (App.vehicles.dist(origin.lat, origin.lon, self.place.lat, self.place.lon) < 150) {
      self.loading = false;
      self.options = [];
      self.error = 'here';
      // Запомнить, когда и откуда проверяли: иначе stale() сразу снова «устарело», и карточка
      // пересчитывается по кругу без паузы — приложение зависает (Дом рядом с GPS или Дом как точка отправления)
      self.planAt = Date.now();
      self.planFrom = { lat: origin.lat, lon: origin.lon };
      return Promise.resolve(true);
    }
    self.inFlight = true;
    var cfg = App.config;
    // Peatus.ee отдаёт лишь несколько «лучших» вариантов, и часть линий в них не попадает.
    // Спрашиваем дважды — сейчас и чуть позже — и объединяем: так в списке больше автобусов.
    var t0 = Date.now();
    var planP = Promise.all([
      App.planner.plan(origin, self.place, 10),
      App.planner.plan(origin, self.place, 10, t0 + 12 * 60000).catch(function () { return []; })
    ]).then(function (r) {
      // Один и тот же первый рейс — один вариант (тот, что раньше довозит)
      var best = {};
      r[0].concat(r[1]).forEach(function (o) {
        if (App.config.noIntercity && App.isIntercity(o)) return;   // настройка «только городской транспорт»
        var k = tripKey(o);
        if (!best[k] || o.end < best[k].end) best[k] = o;
      });
      return Object.keys(best).map(function (k) { return best[k]; });
    });
    var depsP = planP.then(function (list) {
      var ids = [];
      list.forEach(function (o) { var id = o.firstTransit.stopId; if (id && ids.indexOf(id) < 0) ids.push(id); });
      return Promise.all(ids.map(function (id) {
        return App.planner.stopDepartures(id).then(function (d) { self.deps[id] = d; }).catch(function () { /* без расписания — просто ближайший */ });
      }));
    });
    var stopsP = opts.withStops ? planP.then(function (list) {
      return Promise.all(list.slice(0, 8).map(function (o) {
        var id = o.firstTransit.tripId;
        if (!id || self.stops[id]) return null;
        return App.planner.tripStops(id).then(function (l) { if (l) self.stops[id] = l; }).catch(function () { /* только расстояние */ });
      }));
    }) : null;
    return Promise.all([planP, depsP, stopsP]).then(function (res) {
      var now = Date.now();
      var fresh = res[0];
      // Peatus.ee отдаёт только рейсы «в будущем по расписанию». Если наш автобус по GPS опаздывает
      // и мы ещё успеваем — оставляем старый вариант, даже если в новом ответе его нет.
      if (!App.movedEnough(self.planFrom, origin)) {
        var keys = fresh.map(tripKey);
        self.options.forEach(function (o) { if (keys.indexOf(tripKey(o)) < 0) { fresh.push(o); keys.push(tripKey(o)); } });
      }
      // Один и тот же автобус с той же остановки в ту же минуту — один вариант (оставляем тот, что раньше довозит)
      var uniq = {};
      fresh.forEach(function (o) {
        var f = o.firstTransit;
        var k = f.line + '|' + f.headsign + '|' + f.stopName + '|' + Math.round(f.departure / 60000);
        if (!uniq[k] || o.end < uniq[k].end) uniq[k] = o;
      });
      fresh = Object.keys(uniq).map(function (k) { return uniq[k]; });
      self.options = fresh.filter(function (o) {
        if (App.config.noIntercity && App.isIntercity(o)) return false;
        var t = self.timing(o, now);
        return !t.departed && now <= t.latest;
      }).sort(function (a, b) { return self.timing(a, now).latest - self.timing(b, now).latest; }).slice(0, cfg.options);
      self.error = '';
      self.errorAt = 0;
      self.updated = now;
      self.planFrom = { lat: origin.lat, lon: origin.lon };
      self.planAt = now;
      return true;
    }).catch(function (err) {
      self.error = tr('Нет связи с Peatus.ee') + (err && err.status ? ' (' + err.status + ')' : '');
      self.errorAt = Date.now();   // повтор не чаще раза в 10 с, а не по кругу
      return true;
    }).then(function (changed) {
      self.loading = false;
      self.inFlight = false;
      return changed;
    });
  };

  // Нужно ли пересчитать маршрут: давно не считали, сдвинулись, или вариантов стало мало.
  Trip.prototype.stale = function (origin, maxAgeSec) {
    if (this.inFlight) return false;
    if (this.errorAt && Date.now() - this.errorAt < 10000) return false;
    if (!this.planAt) return true;
    if (App.movedEnough(this.planFrom, origin)) return true;
    // Первый вариант уже ушёл или не успеть — не ждать полной минуты, искать следующие рейсы
    var o0 = this.options[0];
    if (o0 && Date.now() - this.planAt > 15000) {
      var t0 = this.timing(o0, Date.now());
      if (t0.departed || Date.now() > t0.latest) return true;
    }
    if (this.options.length < Math.min(2, App.config.options)) return Date.now() - this.planAt > 20000;
    return Date.now() - this.planAt > maxAgeSec * 1000;
  };

  App.Trip = Trip;
})(window.App = window.App || {});
