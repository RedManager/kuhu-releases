/*
 * Настройки и сохранённые места. Всё хранится в памяти телефона (localStorage).
 * App.config — те же поля, что в ТВ-версии, чтобы planner/vehicles/geocode работали без изменений.
 */
(function (App) {
  'use strict';

  var KEY_SETTINGS = 'pv.settings';
  var KEY_PLACES = 'pv.places';

  function read(key, fallback) {
    try {
      var v = localStorage.getItem(key);
      return v ? JSON.parse(v) : fallback;
    } catch (e) { return fallback; }
  }
  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch (e) { /* память недоступна — работаем без сохранения */ }
  }

  var DEFAULTS = {
    bufferMinutes: 2,   // запас: выйти на столько минут раньше, чем впритык
    prepMinutes: 0,     // сборы до выхода на улицу (обувь, куртка, лифт)
    walkFactor: 1.2,    // поправка на скорость ходьбы (1 = как считает Peatus.ee)
    options: 16,        // сколько вариантов держать на экране поездки (сначала видно 5, остальные — «Показать ещё»)
    home: null,         // { address, lat, lon } — «дом», если GPS нет или выбран как точка отправления
    work: null          // { address, lat, lon } — «работа»: точка отправления и быстрая кнопка «На работу»
  };

  var s = read(KEY_SETTINGS, {});
  App.config = {
    bufferMinutes: typeof s.bufferMinutes === 'number' ? s.bufferMinutes : DEFAULTS.bufferMinutes,
    prepMinutes: typeof s.prepMinutes === 'number' ? s.prepMinutes : DEFAULTS.prepMinutes,
    walkFactor: typeof s.walkFactor === 'number' ? s.walkFactor : DEFAULTS.walkFactor,
    options: DEFAULTS.options,
    home: s.home || DEFAULTS.home,
    work: s.work || DEFAULTS.work,
    noIntercity: s.noIntercity === true,   // «только городской транспорт Таллинна» (по умолчанию выключено)
    theme: s.theme === 'light' || s.theme === 'dark' ? s.theme : 'auto',   // выбирается в настройках
    refreshSeconds: 10,          // живые автобусы
    planSeconds: 45,             // пересчёт маршрута для открытой поездки
    listPlanSeconds: 90,         // пересчёт маршрута для карточек избранного
    plannerUrl: 'https://api.peatus.ee/routing/v1/routers/estonia/index/graphql',
    gpsUrl: 'https://transport.tallinn.ee/gps.txt',
    geocodeUrl: 'https://inaadress.maaamet.ee/inaadress/gazetteer?address='
  };

  App.settings = {
    save: function (patch) {
      Object.keys(patch).forEach(function (k) { App.config[k] = patch[k]; });
      write(KEY_SETTINGS, {
        bufferMinutes: App.config.bufferMinutes, prepMinutes: App.config.prepMinutes,
        walkFactor: App.config.walkFactor, home: App.config.home, work: App.config.work, theme: App.config.theme,
        noIntercity: App.config.noIntercity === true
      });
      if (patch.theme) App.applyTheme();
    }
  };

  // ---------- Тема ----------
  var darkMq = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  App.isDark = function () {
    if (App.config.theme === 'dark') return true;
    if (App.config.theme === 'light') return false;
    return !!(darkMq && darkMq.matches);
  };
  App.applyTheme = function () {
    var root = document.documentElement;
    if (App.config.theme === 'auto') root.removeAttribute('data-theme');
    else root.setAttribute('data-theme', App.config.theme);
    var metas = document.querySelectorAll('meta[name="theme-color"]');
    Array.prototype.forEach.call(metas, function (m) { m.removeAttribute('media'); m.setAttribute('content', App.isDark() ? '#111318' : '#f3f4f6'); });
    // Значки в строке состояния (часы, батарея) — под цвет фона: на светлом тёмные, на тёмном светлые
    try {
      var SB = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SystemBars;
      if (SB && SB.setStyle) SB.setStyle({ style: App.isDark() ? 'DARK' : 'LIGHT' }).catch(function () {});
    } catch (e) { /* в браузере плагина нет */ }
    document.dispatchEvent(new CustomEvent('pv-theme'));
  };
  document.addEventListener('resume', function () { if (App.applyTheme) App.applyTheme(); });
  if (darkMq && darkMq.addEventListener) darkMq.addEventListener('change', function () { if (App.config.theme === 'auto') App.applyTheme(); });

  // ---------- Места ----------
  // { id, name, address, lat, lon, fav, created }
  var places = read(KEY_PLACES, null);
  if (!Array.isArray(places)) places = [];
  // Места без звёздочки больше не храним: убрать из избранного = удалить (раньше они уходили в «Другие места»)
  if (places.some(function (p) { return p.fav === false; })) { places = places.filter(function (p) { return p.fav !== false; }); write(KEY_PLACES, places); }
  var listeners = [];

  function persist() {
    write(KEY_PLACES, places);
    listeners.forEach(function (fn) { fn(places); });
  }

  App.places = {
    all: function () { return places.slice(); },
    get: function (id) { for (var i = 0; i < places.length; i++) if (places[i].id === id) return places[i]; return null; },
    favorites: function () { return places.filter(function (p) { return p.fav; }); },
    others: function () { return places.filter(function (p) { return !p.fav; }); },
    add: function (p) {
      var place = {
        id: 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        name: (p.name || p.address || tr('Место')).trim(), address: p.address || '', sub: p.sub || '',
        lat: p.lat, lon: p.lon, fav: p.fav !== false, created: Date.now()
      };
      places.push(place);
      persist();
      return place;
    },
    update: function (id, patch) {
      var p = this.get(id);
      if (!p) return null;
      Object.keys(patch).forEach(function (k) { p[k] = patch[k]; });
      persist();
      return p;
    },
    remove: function (id) {
      places = places.filter(function (p) { return p.id !== id; });
      persist();
    },
    // Вернуть удалённое место на прежнее место в списке (кнопка «Вернуть» в подсказке)
    restore: function (place, index) {
      if (this.get(place.id)) return place;
      places.splice(Math.max(0, Math.min(index, places.length)), 0, place);
      persist();
      return place;
    },
    indexOf: function (id) { for (var i = 0; i < places.length; i++) if (places[i].id === id) return i; return -1; },
    // Порядок избранного: перетаскивать на телефоне неудобно, поэтому «выше/ниже».
    move: function (id, dir) {
      var i = -1;
      places.forEach(function (p, k) { if (p.id === id) i = k; });
      var j = i + dir;
      while (j >= 0 && j < places.length && places[j].fav !== places[i].fav) j += dir;
      if (i < 0 || j < 0 || j >= places.length) return;
      var t = places[i]; places[i] = places[j]; places[j] = t;
      persist();
    },
    // Новый порядок избранного (ids сверху вниз) — после перетаскивания карточек
    reorderFav: function (ids) {
      var favs = ids.map(function (id) { return places.filter(function (p) { return p.id === id && p.fav; })[0]; }).filter(Boolean);
      places.forEach(function (p) { if (p.fav && favs.indexOf(p) < 0) favs.push(p); });
      places = favs.concat(places.filter(function (p) { return !p.fav; }));
      persist();
    },
    onChange: function (fn) { listeners.push(fn); }
  };
})(window.App = window.App || {});
