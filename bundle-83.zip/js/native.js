/*
 * Возможности телефона: уведомления «пора выходить» и виджет на главном экране.
 * В приложении (Android) — через Capacitor: LocalNotifications и свой мост PvWidget.
 * На компьютере (Chrome) уведомления работают, только пока окно открыто; виджета нет.
 */
(function (App) {
  'use strict';

  var C = window.Capacitor;
  var isNative = !!(C && C.isNativePlatform && C.isNativePlatform());
  function plugin(name) {
    if (!isNative) return null;
    if (C.Plugins && C.Plugins[name]) return C.Plugins[name];
    return C.registerPlugin ? C.registerPlugin(name) : null;
  }
  var LN = plugin('LocalNotifications');
  // Точные будильники — только в своей APK. В сборке для Google Play разрешения SCHEDULE_EXACT_ALARM нет:
  // будильник неточный (Android может задержать его, но не присылает раньше), поэтому ставим его с запасом.
  var EXACT = window.PV_STORE !== 'play';
  var EARLY = EXACT ? 0 : 2 * 60000;   // запас для неточного будильника (догадка; проверить на телефоне)
  var W = plugin('PvWidget');
  // Чаевые через Google Play Billing — мост есть только в сборке для Google Play (tips.js ждёт window.PvBilling)
  if (window.PV_STORE === 'play') {
    var B = plugin('PvBilling');
    if (B) {
      window.PvBilling = {
        purchase: function (sku) { return B.purchase({ sku: sku }); },
        prices: function (skus) { return B.prices({ skus: skus }).then(function (r) { return (r && r.prices) || {}; }); }
      };
    }
  }

  var channel = null;
  function ensureChannel() {
    if (!LN) return Promise.resolve();
    if (!channel) {
      channel = LN.createChannel({
        id: 'leave', name: tr('Пора выходить'), description: tr('Напоминания, когда выходить к автобусу'),
        importance: 5, visibility: 1, vibration: true
      }).catch(function () { /* канал не обязателен на старых Android */ });
    }
    return channel;
  }

  // Числовой id уведомления из id места: k = 1 (за 5 минут) или 2 (пора).
  function idFor(placeId, k) {
    var x = 0;
    for (var i = 0; i < placeId.length; i++) x = (x * 31 + placeId.charCodeAt(i)) | 0;
    return (Math.abs(x) % 100000) * 10 + k;
  }

  // Спросить разрешение. true — можно уведомлять.
  function allow() {
    if (LN) {
      return LN.checkPermissions().then(function (p) {
        return p.display === 'granted' ? p : LN.requestPermissions();
      }).then(function (p) {
        if (p.display !== 'granted') return false;
        if (!EXACT || !LN.checkExactNotificationSetting) return true;
        // Android 12+: для точного времени нужно разрешение «Будильники и напоминания».
        return LN.checkExactNotificationSetting().then(function (s) {
          if (s && s.exact_alarm === 'granted') return true;
          if (App.ui) App.ui.toast(tr('Включите «Будильники и напоминания», чтобы уведомление пришло минута в минуту'));
          return LN.changeExactNotificationSetting().then(function () { return true; }, function () { return true; });
        }, function () { return true; });
      }).catch(function () { return false; });
    }
    if ('Notification' in window) {
      if (Notification.permission === 'granted') return Promise.resolve(true);
      return Notification.requestPermission().then(function (p) { return p === 'granted'; });
    }
    return Promise.resolve(false);
  }

  var webTimers = {};
  function cancel(placeId) {
    (webTimers[placeId] || []).forEach(clearTimeout);
    delete webTimers[placeId];
    if (!LN) return Promise.resolve();
    return LN.cancel({ notifications: [{ id: idFor(placeId, 1) }, { id: idFor(placeId, 2) }] }).catch(function () { /* нечего отменять */ });
  }

  // list: [{ k, at, title, body }]
  function schedule(placeId, list) {
    var now = Date.now();
    var items = list.filter(function (x) { return x.at > now + 5000; }).map(function (x) {
      return { k: x.k, at: Math.max(x.at - EARLY, now + 5000), title: x.title, body: x.body };
    });
    return cancel(placeId).then(function () {
      if (!items.length) return null;
      if (LN) {
        return ensureChannel().then(function () {
          return LN.schedule({ notifications: items.map(function (x) {
            return {
              id: idFor(placeId, x.k), title: x.title, body: x.body, channelId: 'leave',
              smallIcon: 'ic_stat_pv', schedule: { at: new Date(x.at), allowWhileIdle: true },
              isExactNotification: EXACT, extra: { placeId: placeId }
            };
          }) });
        }).catch(function () { /* без уведомления — не критично */ });
      }
      if ('Notification' in window && Notification.permission === 'granted') {
        webTimers[placeId] = items.map(function (x) {
          return setTimeout(function () { try { new Notification(x.title, { body: x.body, icon: 'img/icon.png', tag: placeId + x.k }); } catch (e) { /* без уведомления */ } }, x.at - Date.now());
        });
      }
      return null;
    });
  }

  // Нажали на уведомление — открыть это место.
  if (LN && LN.addListener) {
    LN.addListener('localNotificationActionPerformed', function (e) {
      var id = e && e.notification && e.notification.extra && e.notification.extra.placeId;
      var p = id && App.places.get(id);
      if (p && App.ui) App.ui.openTrip(p);
    });
  }

  var lastWidget = '';
  function widget(data) {
    if (!W) return;
    var key = JSON.stringify(data.items);
    if (key === lastWidget && Date.now() - (widget.at || 0) < 120000) return;
    lastWidget = key;
    widget.at = Date.now();
    W.update({ data: JSON.stringify(data) }).catch(function () { /* виджета может не быть */ });
  }

  // Срочное уведомление сейчас (k = 3): «автобус опаздывает, выходи позже».
  function notifyNow(placeId, title, body) {
    if (LN) {
      return ensureChannel().then(function () {
        return LN.schedule({ notifications: [{ id: idFor(placeId, 3), title: title, body: body, channelId: 'leave', smallIcon: 'ic_stat_pv',
          schedule: { at: new Date(Date.now() + 1500), allowWhileIdle: true }, isExactNotification: EXACT, extra: { placeId: placeId } }] });
      }).catch(function () { /* без уведомления */ });
    }
    if ('Notification' in window && Notification.permission === 'granted') {
      try { new Notification(title, { body: body, icon: 'img/icon.png', tag: placeId + 3 }); } catch (e) { /* без уведомления */ }
    }
    return Promise.resolve();
  }

  App.native = { notifyNow: notifyNow, exact: EXACT,
    isNative: isNative, canNotify: !!LN || 'Notification' in window, hasWidget: !!W,
    allow: allow, schedule: schedule, cancel: cancel, widget: widget
  };
})(window.App = window.App || {});
