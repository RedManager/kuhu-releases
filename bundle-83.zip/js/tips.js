/*
 * Поддержка разработчика («чаевые»). Приложение остаётся бесплатным, ничего не открывается за деньги.
 * Покупки — через Google Play Billing, только в сборке для Google Play (window.PV_STORE === 'play'
 * и подключённый мост window.PvBilling.purchase(sku) → Promise). В тестовой сборке экран есть, но платить нельзя.
 * Напоминание — карточка на каждой 10-й завершённой поездке: «Позже» скрывает до следующей десятой,
 * «Больше не показывать» отключает насовсем.
 */
(function (App) {
  'use strict';
  var KEY = 'pv.tips';
  var EVERY = 10;
  var SKUS = { small: 'tip_small', medium: 'tip_medium', large: 'tip_large' };

  var T = {
    en: {
      'Поддержать Kuhu': 'Support Kuhu',
      'Kuhu бесплатный, без рекламы и без аккаунтов. Если он помогает вам вовремя выходить из дома, можно угостить разработчика.': 'Kuhu is free, with no ads and no accounts. If it helps you leave home on time, you can treat the developer.',
      'Эспрессо': 'Espresso', 'Маленькое спасибо': 'A small thank you',
      'Капучино': 'Cappuccino', 'Чтобы работалось бодрее': 'To keep the work going',
      'На вкусняшки и игрушки собаки разработчика': "For treats and toys for the developer's dog",
      'Собака будет очень рада': 'The dog will be very happy',
      'Оплата через Google Play. Все функции приложения остаются бесплатными, чаевые ничего не открывают.': 'Paid through Google Play. All features stay free; tips unlock nothing.',
      'Покупки заработают в версии из Google Play': 'Payments will work in the Google Play version',
      'Спасибо, мне очень приятно!': 'Thank you, I really appreciate it!',
      'Kuhu помог?': 'Did Kuhu help?',
      'Угостите разработчика, чтобы он мог дальше развивать приложение.': 'Treat the developer so they can keep improving the app.',
      'Открыть': 'Open', 'Позже': 'Later', 'Больше не показывать': "Don't show again"
    },
    et: {
      'Поддержать Kuhu': 'Toeta Kuhut',
      'Kuhu бесплатный, без рекламы и без аккаунтов. Если он помогает вам вовремя выходить из дома, можно угостить разработчика.': 'Kuhu on tasuta, ilma reklaamita ja ilma kontodeta. Kui see aitab sul õigel ajal kodust väljuda, võid arendajat kostitada.',
      'Эспрессо': 'Espresso', 'Маленькое спасибо': 'Väike aitäh',
      'Капучино': 'Cappuccino', 'Чтобы работалось бодрее': 'Et töö edeneks',
      'На вкусняшки и игрушки собаки разработчика': 'Arendaja koera maiuste ja mänguasjade jaoks',
      'Собака будет очень рада': 'Koer on väga õnnelik',
      'Оплата через Google Play. Все функции приложения остаются бесплатными, чаевые ничего не открывают.': 'Makse käib Google Play kaudu. Kõik funktsioonid jäävad tasuta, jootraha ei ava midagi.',
      'Покупки заработают в версии из Google Play': 'Maksed hakkavad tööle Google Play versioonis',
      'Спасибо, мне очень приятно!': 'Aitäh, mul on väga hea meel!',
      'Kuhu помог?': 'Kas Kuhu aitas?',
      'Угостите разработчика, чтобы он мог дальше развивать приложение.': 'Kostita arendajat, et ta saaks äppi edasi arendada.',
      'Открыть': 'Ava', 'Позже': 'Hiljem', 'Больше не показывать': 'Ära näita enam'
    }
  };
  var L = window.PV_LANG || (window.PV_LANG = { en: {}, et: {} });
  ['en', 'et'].forEach(function (k) {
    L[k] = L[k] || {};
    Object.keys(T[k]).forEach(function (s) { if (L[k][s] === undefined) L[k][s] = T[k][s]; });
  });

  function read() {
    try { return JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) { return {}; }
  }
  function write(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) { /* без памяти */ } }
  // Для проверки на ПК: localStorage.setItem('pv.tipsDemo','1') показывает карточку без Google Play
  function demo() { try { return localStorage.getItem('pv.tipsDemo') === '1'; } catch (e) { return false; } }

  document.addEventListener('DOMContentLoaded', function () {
    var d = document.createElement('div');
    d.style.display = 'none';
    d.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg">' +
      '<symbol id="i-heart" viewBox="0 0 256 256"><path d="M178,40c-20.65,0-38.73,8.88-50,23.89C116.73,48.88,98.65,40,78,40a62.07,62.07,0,0,0-62,62c0,70,103.79,126.66,108.21,129a8,8,0,0,0,7.58,0C136.21,228.66,240,172,240,102A62.07,62.07,0,0,0,178,40ZM128,214.8C109.74,204.16,32,155.69,32,102A46.06,46.06,0,0,1,78,56c19.45,0,35.78,10.36,42.6,27a8,8,0,0,0,14.8,0c6.82-16.67,23.15-27,42.6-27a46.06,46.06,0,0,1,46,46C224,155.61,146.24,204.15,128,214.8Z"/></symbol>' +
      '<symbol id="i-cup" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M5 9h11v5a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5V9zM16 10h1.5a2.5 2.5 0 0 1 0 5H16M8 3v2M12 3v2"/></symbol>' +
      '<symbol id="i-cup2" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="M4 8h13v6a6 6 0 0 1-6 6h-1a6 6 0 0 1-6-6V8zM17 10h1.5a2.5 2.5 0 0 1 0 5H17M9 3c0 1.2 1 1.2 1 2.4M13 3c0 1.2 1 1.2 1 2.4"/></symbol>' +
      '</svg>';
    document.body.appendChild(d);
  });

  App.tips = {
    EVERY: EVERY,
    skus: SKUS,
    canPay: function () {
      return window.PV_STORE === 'play' && !!(window.PvBilling && window.PvBilling.purchase);
    },
    count: function () { return read().n || 0; },
    // Вызывается, когда поездка доехала до конца
    countTrip: function () { var s = read(); s.n = (s.n || 0) + 1; write(s); },
    due: function () {
      var s = read();
      if (s.never) return false;
      if (!App.tips.canPay() && !demo()) return false;
      return (s.n || 0) > 0 && s.n % EVERY === 0 && s.shown !== s.n;
    },
    later: function () { var s = read(); s.shown = s.n || 0; write(s); },
    never: function () { var s = read(); s.never = true; write(s); },
    // Цены из Google Play в валюте покупателя: { small: '1,99 €', ... }; без Play — пустой объект
    prices: function () {
      if (!App.tips.canPay() || !window.PvBilling.prices) return Promise.resolve({});
      var ids = Object.keys(SKUS).map(function (k) { return SKUS[k]; });
      return Promise.resolve(window.PvBilling.prices(ids)).then(function (p) {
        var out = {};
        Object.keys(SKUS).forEach(function (k) { if (p && p[SKUS[k]]) out[k] = p[SKUS[k]]; });
        return out;
      }).catch(function () { return {}; });
    },
    buy: function (tier) {
      if (!App.tips.canPay()) return Promise.reject(new Error('unavailable'));
      return Promise.resolve(window.PvBilling.purchase(SKUS[tier])).then(function (r) { App.tips.never(); return r; });
    }
  };
})(window.App = window.App || {});
