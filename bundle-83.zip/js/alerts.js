/*
 * Сообщения о сбоях и объездах от Tallinna Linnatransport: transport.tallinn.ee/announcements.json
 * Поля: transport (Buss/Tramm/Trolli), routes («55» или «7, 13, 15»), stops, title, info (текст, эстонский),
 *       publication_start_time/_end_time и valid_start_time/_end_time («дд.мм.гггг [чч:мм]»).
 * Лента не задокументирована и может измениться, поэтому любая ошибка = «сообщений нет», приложение работает как раньше.
 */
(function (App) {
  'use strict';
  var URL = 'https://transport.tallinn.ee/announcements.json';
  var CACHE = 'pv.alerts';
  var TTL = 10 * 60 * 1000;
  var list = [];       // разобранные и действующие сообщения
  var loadedAt = 0;
  var pending = null;

  var T = {
    en: {
      'Изменения и объезды': 'Service changes and detours', 'Сейчас действуют сообщения: ': 'Active notices: ',
      'Сообщение от Tallinna Linnatransport': 'Notice from Tallinna Linnatransport',
      'Текст на эстонском, как его публикует перевозчик.': 'The text is in Estonian, as published by the operator.',
      'Линии: ': 'Lines: ', 'Действует: ': 'In effect: ', 'Сообщений о сбоях сейчас нет.': 'No disruption notices right now.',
      'Изменение в движении': 'Service change', 'Сообщений: ': 'Notices: ', 'Есть изменения в движении': 'Service changes on this route', 'Закрыть': 'Close'
    },
    et: {
      'Изменения и объезды': 'Muudatused ja ümbersõidud', 'Сейчас действуют сообщения: ': 'Kehtivaid teateid: ',
      'Сообщение от Tallinna Linnatransport': 'Tallinna Linnatranspordi teade',
      'Текст на эстонском, как его публикует перевозчик.': 'Tekst on perevedaja avaldatud kujul.',
      'Линии: ': 'Liinid: ', 'Действует: ': 'Kehtib: ', 'Сообщений о сбоях сейчас нет.': 'Häireteateid praegu pole.',
      'Изменение в движении': 'Liikluse muudatus', 'Сообщений: ': 'Teateid: ', 'Есть изменения в движении': 'Sellel marsruudil on liikluses muudatusi', 'Закрыть': 'Sulge'
    }
  };
  var L = window.PV_LANG || (window.PV_LANG = { en: {}, et: {} });
  ['en', 'et'].forEach(function (k) {
    L[k] = L[k] || {};
    Object.keys(T[k]).forEach(function (s) { if (L[k][s] === undefined) L[k][s] = T[k][s]; });
  });

  // «05.11.2026 14:30» или «09.11.2026» → Date (для даты без времени endOfDay решает конец суток)
  function parseDate(s, endOfDay) {
    var m = /(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/.exec(String(s || ''));
    if (!m) return null;
    var hasTime = m[4] !== undefined;
    return new Date(+m[3], +m[2] - 1, +m[1], hasTime ? +m[4] : (endOfDay ? 23 : 0), hasTime ? +m[5] : (endOfDay ? 59 : 0));
  }
  function validEnd(o) {
    var v = o && o.valid_end_time;
    return typeof v === 'string' ? v : '';
  }

  // HTML из ленты → обычный текст, без вставки разметки на страницу
  function plain(s) {
    s = String(s == null ? '' : s);
    try {
      var doc = new DOMParser().parseFromString(s.replace(/<br\s*\/?>/gi, '\n').replace(/<\/p>/gi, '\n'), 'text/html');
      return (doc.body.textContent || '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    } catch (e) { return s.replace(/<[^>]+>/g, ' ').trim(); }
  }

  function modeOf(t) {
    t = String(t || '').toLowerCase();
    if (t.indexOf('troll') === 0) return 'TROLLEYBUS';
    if (t.indexOf('tram') === 0) return 'TRAM';
    if (t.indexOf('buss') === 0 || t.indexOf('bus') === 0 || t.indexOf('авто') === 0) return 'BUS';
    return '';
  }
  function key(s) { return String(s || '').toUpperCase().replace(/\s+/g, '').replace(/^T(?=\d)/, ''); }
  function routesOf(s) {
    return String(s == null ? '' : s).split(/[^0-9A-Za-zÄÖÜÕäöüõ]+/).filter(function (x) { return /\d/.test(x); }).map(key);
  }

  function parse(raw, now) {
    if (!Array.isArray(raw)) return [];
    var out = [];
    raw.forEach(function (o, i) {
      if (!o || typeof o !== 'object') return;
      var from = parseDate(o.publication_start_time, false);
      var to = parseDate(o.publication_end_time, true);
      if (from && now < from) return;
      if (to && now > to) return;
      var vTo = parseDate(validEnd(o), true);
      if (vTo && now > vTo) return;
      out.push({
        id: i, title: plain(o.title), text: plain(o.info), mode: modeOf(o.transport),
        routes: routesOf(o.routes), routesText: String(o.routes || '').trim(),
        until: to || vTo || null, from: parseDate(o.valid_start_time, false)
      });
    });
    return out.filter(function (a) { return a.title || a.text; });
  }

  function apply(raw) { list = parse(raw, new Date()); loadedAt = Date.now(); }

  try { var c = JSON.parse(localStorage.getItem(CACHE) || 'null'); if (c && c.raw) apply(c.raw); loadedAt = (c && c.at) || 0; } catch (e) { /* без памяти */ }

  function load(force) {
    if (!force && Date.now() - loadedAt < TTL) return Promise.resolve(list);
    if (pending) return pending;
    pending = fetch(URL + '?t=' + Date.now()).then(function (r) {
      if (!r.ok) throw new Error('alerts ' + r.status);
      return r.json();
    }).then(function (raw) {
      apply(raw);
      try { localStorage.setItem(CACHE, JSON.stringify({ at: Date.now(), raw: raw })); } catch (e) { /* без памяти */ }
      return list;
    }).catch(function () { return list; }).then(function (x) { pending = null; return x; });
    return pending;
  }

  App.alerts = {
    load: load,
    all: function () { return list.slice(); },
    // Сообщения про конкретную линию: номер + вид транспорта (если в сообщении он указан)
    forLine: function (line, mode) {
      var k = key(line);
      return list.filter(function (a) {
        if (a.routes.indexOf(k) < 0) return false;
        return !a.mode || !mode || a.mode === String(mode).toUpperCase();
      });
    },
    // Линия → есть ли сообщение (для точки на плитке)
    has: function (line, mode) { return App.alerts.forLine(line, mode).length > 0; },
    // Сообщения без привязки к линиям (общие)
    general: function () { return list.filter(function (a) { return !a.routes.length; }); },
    _parse: parse
  };
})(window.App = window.App || {});
