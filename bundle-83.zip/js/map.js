/*
 * Карта на Leaflet. Светлая тема — карта Земельного департамента Эстонии (Maa- ja Ruumiamet),
 * тёмная — CARTO Dark (OpenStreetMap). Если пользователь двигал карту, сами не прыгаем:
 * вернуть вид можно кнопкой «по центру».
 */
(function (App) {
  'use strict';

  // Подложка — карта Земельного департамента Эстонии (без ключа). Для тёмной темы та же карта,
  // перекрашенная CSS-фильтром (.pv-tiles-dark): CARTO Dark теперь требует платный ключ.
  var LIGHT = { url: 'https://tiles.maaamet.ee/tm/tms/1.0.0/kaart@GMC/{z}/{x}/{y}.png', tms: true, attr: 'Aluskaart © Maa- ja Ruumiamet', max: 18 };
  var FALLBACK = { url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', tms: false, attr: '© OpenStreetMap', max: 19 };

  function isDark() { return App.isDark ? App.isDark() : false; }

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function modeIcon(mode) {
    var m = String(mode || '').toUpperCase();
    if (m === 'TRAM') return 'tram';
    if (m === 'RAIL') return 'train';
    if (m === 'FERRY') return 'boat';
    return 'bus';
  }
  App.modeIcon = modeIcon;

  function create(el) {
    var map = L.map(el, {
      zoomControl: false, attributionControl: true, zoomSnap: 0.25, minZoom: 9, maxZoom: 19,
      tapTolerance: 12
    }).setView([59.437, 24.7536], 13);
    map.attributionControl.setPrefix('');

    var base = null;
    var failed = 0;
    var current = LIGHT;
    function setBase(src) {
      current = src;
      if (base) map.removeLayer(base);
      base = L.tileLayer(src.url, { tms: src.tms, attribution: src.attr, maxZoom: 19, maxNativeZoom: src.max, detectRetina: false,
        crossOrigin: false, className: isDark() ? 'pv-tiles-dark' : '' });
      failed = 0;
      base.on('tileerror', function () {
        failed++;
        if (failed === 6 && src !== FALLBACK) setBase(FALLBACK);
      });
      base.addTo(map);
    }
    setBase(LIGHT);
    var shownDark = isDark();
    document.addEventListener('pv-theme', function () {
      if (isDark() !== shownDark) { shownDark = isDark(); setBase(current); }
    });

    var lineLayer = L.layerGroup().addTo(map);
    var markerLayer = L.layerGroup().addTo(map);
    var vehicleMarkers = {};   // id -> marker (двигаем, а не пересоздаём — меньше мигания)
    var touched = false;
    var lastFitKey = '';
    var lastFitPts = null;

    map.on('dragstart zoomstart', function (e) { if (e && e.hard !== false && !map._pvFitting) touched = true; });

    function pinIcon(kind, html, label) {
      return L.divIcon({
        className: 'pv-marker pv-' + kind,
        html: html || '',
        iconSize: null,
        iconAnchor: null
      });
    }

    function svgUse(id) { return '<svg class="ic" aria-hidden="true"><use href="#i-' + id + '"/></svg>'; }

    function fit(points, key, force) {
      var pts = (points || []).filter(function (p) { return p && isFinite(p[0]) && isFinite(p[1]); });
      if (!pts.length) return;
      lastFitPts = pts;
      if (!force && touched && key === lastFitKey) return;
      if (key !== lastFitKey) touched = false;
      lastFitKey = key;
      map._pvFitting = true;
      if (pts.length === 1) map.setView(pts[0], 16, { animate: false });
      else map.fitBounds(L.latLngBounds(pts), { padding: [36, 36], maxZoom: 17, animate: false });
      setTimeout(function () { map._pvFitting = false; }, 50);
    }

    /*
     * data: {
     *   me: {lat, lon, acc}, dest: {lat, lon, name}, stop: {lat, lon, name},
     *   lines: [{ points, kind: 'walk'|'transit'|'approach' }],
     *   vehicles: [{ id, lat, lon, line, mode, mine }]
     * }
     */
    // Курс маршрута у точки: ближайший к ней отрезок пути, в градусах от севера; null — пути нет
    function bearingAt(path, lat, lon) {
      if (!path || path.length < 2) return null;
      var best = 0, bd = Infinity, k = Math.cos(lat * Math.PI / 180);
      for (var i = 0; i < path.length - 1; i++) {
        var dy = path[i][0] - lat, dx = (path[i][1] - lon) * k, d2 = dx * dx + dy * dy;
        if (d2 < bd) { bd = d2; best = i; }
      }
      var a = path[best], b = path[best + 1];
      var ex = (b[1] - a[1]) * k, ey = b[0] - a[0];
      if (!ex && !ey) return null;
      return (Math.atan2(ex, ey) * 180 / Math.PI + 360) % 360;
    }
    function setData(data) {
      lineLayer.clearLayers();
      markerLayer.clearLayers();
      (data.lines || []).forEach(function (l) {
        if (!l.points || l.points.length < 2) return;
        if (l.kind === 'approach') {
          L.polyline(l.points, { className: 'pv-line pv-line-approach-under', weight: 9, interactive: false }).addTo(lineLayer);
        }
        L.polyline(l.points, { className: 'pv-line pv-line-' + l.kind + (l.kind === 'transit' && l.mode ? ' pv-m-' + String(l.mode).toLowerCase() : ''), weight: l.kind === 'walk' ? 4 : l.kind === 'routes' ? 4 : 5, interactive: false }).addTo(lineLayer);
      });
      (data.routeStops || []).forEach(function (st) {
        L.circleMarker([st.lat, st.lon], { radius: 5, className: 'pv-route-stop', interactive: false }).addTo(lineLayer);
      });
      if (data.me) {
        if (data.me.acc && data.me.acc > 25) {
          L.circle([data.me.lat, data.me.lon], { radius: data.me.acc, className: 'pv-acc', interactive: false }).addTo(markerLayer);
        }
        L.marker([data.me.lat, data.me.lon], { icon: pinIcon(data.me.home ? 'home' : 'me', data.me.home ? '<span class="pv-dot">' + svgUse('home') + '</span>' : '<span class="pv-dot"></span>'), keyboard: false, zIndexOffset: 500 }).addTo(markerLayer);
      }
      if (data.origin) {
        L.marker([data.origin.lat, data.origin.lon], { icon: pinIcon('home', '<span class="pv-dot">' + svgUse(data.origin.kind) + '</span>'), keyboard: false, zIndexOffset: 450 })
          .bindTooltip(esc(data.origin.label || ''), { direction: 'top', offset: [0, -14], className: 'pv-tip' }).addTo(markerLayer);
      }
      if (data.stop) {
        var sb = bearingAt(data.stop.path, data.stop.lat, data.stop.lon);
        var sWest = sb !== null && Math.sin(sb * Math.PI / 180) < 0;
        L.marker([data.stop.lat, data.stop.lon], { icon: pinIcon('stop' + (sWest ? ' is-left' : ''), '<span class="pv-stop-sq">' + svgUse('signpost') + '</span>'), keyboard: false, zIndexOffset: 300 })
          .bindTooltip(esc(data.stop.name), { direction: 'top', offset: [0, -14], className: 'pv-tip' }).addTo(markerLayer);
      }
      (data.stops || []).forEach(function (s) {
        // Направление — самим значком: табличка вправо (на восток) или влево (на запад), без отдельных стрелок
        var west = s.bearing !== null && s.bearing !== undefined && Math.sin(s.bearing * Math.PI / 180) < 0;
        L.marker([s.lat, s.lon], { icon: pinIcon('stop' + (west ? ' is-left' : '') + (s.active ? ' is-active' : '') + (s.dim ? ' is-dim' : ''), '<span class="pv-stop-sq">' + svgUse('signpost') + '</span>'), keyboard: false, zIndexOffset: s.active ? 200 : 0 })
          .on('click', function () { if (s.onTap) s.onTap(); }).addTo(markerLayer);
      });
      if (data.dest) {
        L.marker([data.dest.lat, data.dest.lon], { icon: pinIcon('dest', '<span class="pv-pin">' + svgUse('flag') + '</span>'), keyboard: false, zIndexOffset: 400 }).addTo(markerLayer);
      }
      var seen = {};
      (data.vehicles || []).forEach(function (v) {
        var id = v.id || (v.line + ':' + v.lat + ':' + v.lon);
        seen[id] = true;
        var html = '<span class="pv-bus m-' + String(v.mode || 'BUS').toLowerCase() + '">' + svgUse(modeIcon(v.mode)) + '<b>' + esc(v.line) + '</b></span>';
        var m = vehicleMarkers[id];
        if (!m) {
          m = L.marker([v.lat, v.lon], { icon: pinIcon('vehicle' + (v.mine ? ' is-mine' : ''), html), keyboard: false, zIndexOffset: v.mine ? 900 : 600 });
          vehicleMarkers[id] = m;
          m._pvMine = v.mine;
          if (v.label) m.bindTooltip(esc(v.label), { direction: 'top', offset: [0, -16], className: 'pv-tip' });
          if (v.onTap) m.on('click', function () { v.onTap(m); });
          m.addTo(map);
        } else {
          m.setLatLng([v.lat, v.lon]);
          if (v.label && m.getTooltip() && m.getTooltip().getContent() !== esc(v.label)) m.setTooltipContent(esc(v.label));
          if (m._pvMine !== v.mine) { m.setIcon(pinIcon('vehicle' + (v.mine ? ' is-mine' : ''), html)); m.setZIndexOffset(v.mine ? 900 : 600); m._pvMine = v.mine; }
        }
      });
      Object.keys(vehicleMarkers).forEach(function (id) {
        if (!seen[id]) { map.removeLayer(vehicleMarkers[id]); delete vehicleMarkers[id]; }
      });
    }

    // Карта внутри листаемого экрана: одним пальцем листаем страницу, а не двигаем карту.
    var locked = false;
    function setLocked(on) {
      if (on === locked) return;
      locked = on;
      ['dragging', 'touchZoom', 'doubleClickZoom', 'scrollWheelZoom', 'boxZoom', 'keyboard'].forEach(function (k) {
        if (map[k]) { if (on) map[k].disable(); else map[k].enable(); }
      });
      el.classList.toggle('is-locked', on);
    }

    return {
      map: map,
      setLocked: setLocked,
      setData: setData,
      fit: fit,
      recenter: function () { touched = false; if (lastFitPts) fit(lastFitPts, lastFitKey, true); },
      resize: function () { map.invalidateSize({ animate: false }); },
      destroy: function () { map.remove(); }
    };
  }

  App.mapView = { create: create };
})(window.App = window.App || {});
