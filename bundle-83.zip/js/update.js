/*
 * Проверка обновлений. Готовые APK лежат в отдельном ПУБЛИЧНОМ репозитории (там только файлы приложения,
 * кода и ключей нет): latest.json — номер последней сборки и что нового, Kuhu.apk — сам файл.
 * Приложение раз в несколько часов заглядывает в latest.json; если номер больше своего — предлагает обновиться.
 * Обновление ставится поверх (подпись та же), все места и настройки сохраняются.
 * OTA: если изменился только код приложения (www), качается маленький архив bundle-N.zip и применяется без установки APK.
 * Если сборка меняет нативную часть (latest.json: shell больше номера установленного APK) — как раньше, через APK.
 * Сборка для Google Play (window.PV_STORE === 'play'): ничего этого нет, обновления приходят только через Play.
 */
(function (App) {
  'use strict';

  var BASE = 'https://raw.githubusercontent.com/RedManager/kuhu-releases/main/';
  var EVERY = 6 * 3600000;       // как часто проверять само
  var SNOOZE = 24 * 3600000;     // сколько не напоминать после «Позже»

  var STORE = window.PV_STORE === 'play';   // сборка для Google Play — обновляет сам Play
  function mine() { return Number(window.PV_BUILD) || 0; }
  function get(k) { try { return Number(localStorage.getItem(k)) || 0; } catch (e) { return 0; } }
  function put(k, v) { try { localStorage.setItem(k, String(v)); } catch (e) { /* без хранилища */ } }

  // Что нового: массив строк или { ru: [], en: [], et: [] } — берём язык приложения
  function pickNotes(n) {
    var l = n && !Array.isArray(n) ? (n[App.i18n.lang] || n.en || n.ru || []) : n;
    return Array.isArray(l) ? l.map(String) : [];
  }

  // Плагин OTA-обновлений (только в APK) и «оболочка»: номер сборки самого APK. Содержимое www может быть новее.
  function updater() {
    var C = window.Capacitor;
    if (STORE || !(C && C.isNativePlatform && C.isNativePlatform())) return null;
    return (C.Plugins && C.Plugins.CapacitorUpdater) || (C.registerPlugin ? C.registerPlugin('CapacitorUpdater') : null);
  }
  var shellP = null;
  function shell() {
    if (!shellP) {
      var C = window.Capacitor;
      var a = C && C.Plugins && C.Plugins.App;
      shellP = a && a.getInfo ? a.getInfo().then(function (i) { return Number(i && i.build) || 0; }).catch(function () { return 0; }) : Promise.resolve(0);
    }
    return shellP;
  }
  // Приложение запустилось нормально — без этого плагин через 15 с откатит на прошлую версию
  function ready() { var u = updater(); if (u && u.notifyAppReady) u.notifyAppReady().catch(function () { /* без плагина */ }); }

  // Что сейчас лежит в репозитории: { build, notes[], apk, bundle, shell } или null, если не достучались.
  function fetchLatest() {
    return fetch(BASE + 'latest.json?t=' + Date.now(), { cache: 'no-store' }).then(function (r) {
      if (!r.ok) throw new Error('HTTP ' + r.status);
      return r.json();
    }).then(function (j) {
      var b = Number(j && j.build);
      if (!b) throw new Error(tr('нет номера сборки'));
      return { build: b, notes: pickNotes(j.notes), apk: BASE + (j.apk || 'Kuhu.apk'), bundle: j.bundle ? BASE + j.bundle : '', checksum: String(j.checksum || ''), shell: Number(j.shell) || 0 };
    });
  }

  /*
   * check({ force }) → Promise<{ state: 'new'|'same'|'dev', latest }>.
   * Без force: не чаще раза в EVERY и молчит про версию, отложенную кнопкой «Позже».
   * Ошибка сети не бросается наружу при фоновой проверке — только при ручной (force).
   */
  function check(opts) {
    var force = !!(opts && opts.force);
    if (STORE) return Promise.resolve({ state: 'store' });   // Google Play обновляет сам
    if (!mine()) return Promise.resolve({ state: 'dev' });   // запуск не из APK — нечего обновлять
    if (!force && Date.now() - get('pv.updAt') < EVERY) return Promise.resolve({ state: 'same' });
    return fetchLatest().then(function (latest) {
      put('pv.updAt', Date.now());
      if (latest.build <= mine()) return { state: 'same', latest: latest };
      if (!force && get('pv.updSnoozeBuild') === latest.build && Date.now() - get('pv.updSnoozeAt') < SNOOZE) return { state: 'same', latest: latest };
      // По воздуху можно, если есть архив, плагин и наша оболочка не старее той, что нужна этой сборке
      return shell().then(function (sh) {
        latest.ota = !!(latest.bundle && latest.checksum && updater() && sh > 0 && sh >= latest.shell);
        return { state: 'new', latest: latest };
      });
    }).catch(function (e) {
      if (force) throw e;
      return { state: 'same' };
    });
  }

  function snooze(build) { put('pv.updSnoozeBuild', build); put('pv.updSnoozeAt', Date.now()); }

  // Скачать APK: системный браузер сам скачает файл; дальше — открыть его и нажать «Обновить».
  function download(latest) {
    if (STORE) return;
    var C = window.Capacitor;
    var app = C && C.Plugins && C.Plugins.App;
    if (app && app.openUrl) { app.openUrl({ url: latest.apk }).catch(function () { window.location.href = latest.apk; }); return; }
    window.location.href = latest.apk;
  }

  // Обновить по воздуху: скачать архив www (≈1 МБ) и перезапустить приложение. Ошибка — наружу, чтобы предложить APK.
  function apply(latest) {
    var u = updater();
    if (!u || !latest.bundle || !latest.checksum) return Promise.reject(new Error('no updater'));
    return u.download({ url: latest.bundle, version: String(latest.build), checksum: latest.checksum }).then(function (b) { return u.set({ id: b.id }); });
  }

  App.update = { store: STORE, mine: mine, check: check, snooze: snooze, download: download, apply: apply, ready: ready };
})(window.App = window.App || {});
