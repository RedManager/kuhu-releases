/* Форматирование времени. */
(function (App) {
  'use strict';
  function p(n) { return (n < 10 ? '0' : '') + n; }

  App.time = {
    hm: function (ms) { var d = new Date(ms); return p(d.getHours()) + ':' + p(d.getMinutes()); },
    // Обратный отсчёт: 7:05, 1:02:30
    countdown: function (ms) {
      var s = Math.max(0, Math.floor(ms / 1000));
      var hh = Math.floor(s / 3600);
      var mm = Math.floor((s % 3600) / 60);
      var ss = s % 60;
      return hh ? hh + ':' + p(mm) + ':' + p(ss) : mm + ':' + p(ss);
    },
    // «воскресенье, 25 октября»
    dayLong: function (ms) {
      var d = new Date(ms);
      var W = [tr('воскресенье'), tr('понедельник'), tr('вторник'), tr('среда'), tr('четверг'), tr('пятница'), tr('суббота')];
      var M = [tr('января'), tr('февраля'), tr('марта'), tr('апреля'), tr('мая'), tr('июня'), tr('июля'), tr('августа'), tr('сентября'),
        tr('октября'), tr('ноября'), tr('декабря')];
      return W[d.getDay()] + ', ' + d.getDate() + ' ' + M[d.getMonth()];
    },
    greeting: function (ms) {
      var hr = new Date(ms).getHours();
      if (hr < 5) return tr('Доброй ночи');
      if (hr < 12) return tr('Доброе утро');
      if (hr < 18) return tr('Добрый день');
      return tr('Добрый вечер');
    },
    plural: function (n, one, few, many) {
      if (App.i18n && App.i18n.lang !== 'ru') return Math.abs(n) === 1 ? one : many;   // en/et: одно или много
      var a = Math.abs(n) % 100, b = a % 10;
      if (a > 10 && a < 20) return many;
      if (b === 1) return one;
      if (b >= 2 && b <= 4) return few;
      return many;
    },
    stopsWord: function (n) {
      if (App.i18n && App.i18n.lang !== 'ru') return Math.abs(n) === 1 ? tr('остановка') : tr('остановок');
      var a = Math.abs(n) % 100;
      var b = a % 10;
      if (a > 10 && a < 20) return tr('остановок');
      if (b === 1) return tr('остановка');
      if (b > 1 && b < 5) return tr('остановки');
      return tr('остановок');
    },
    minutesWord: function (n) {
      if (App.i18n && App.i18n.lang !== 'ru') return Math.abs(n) === 1 ? tr('минуту') : tr('минут');
      var a = Math.abs(n) % 100;
      var b = a % 10;
      if (a > 10 && a < 20) return tr('минут');
      if (b === 1) return tr('минуту');
      if (b > 1 && b < 5) return tr('минуты');
      return tr('минут');
    }
  };
})(window.App = window.App || {});
