/*
 * Маршрут «от двери до двери» через Peatus.ee (OpenTripPlanner, GraphQL).
 * Возвращает варианты поездки в удобном виде:
 * { leaveAt, start, end, firstTransit: { mode, line, headsign, stopName, departure, realTime, delay },
 *   walkToStopMin, legs: [{ mode, line, from, to, start, end, points: [[lat,lon],...] }] }
 */
(function (App) {
  'use strict';

  var QUERY = 'query($fromLat: Float!, $fromLon: Float!, $toLat: Float!, $toLon: Float!, $n: Int!, $date: String, $time: String) {' +
    ' plan(from: {lat: $fromLat, lon: $fromLon}, to: {lat: $toLat, lon: $toLon}, numItineraries: $n, date: $date, time: $time) {' +
    '  itineraries { startTime endTime duration walkDistance' +
    '   legs { mode startTime endTime realTime departureDelay duration distance transitLeg' +
    '    from { name lat lon stop { gtfsId code name } }' +
    '    to { name lat lon }' +
    '    route { gtfsId shortName longName mode agency { gtfsId } }' +
    '    trip { gtfsId tripHeadsign pattern { patternGeometry { points } } }' +
    '    legGeometry { points } } } } }';

  // Расшифровка полилинии (формат Google, точность 5 знаков).
  function decode(str) {
    var points = [];
    var index = 0;
    var lat = 0;
    var lng = 0;
    while (str && index < str.length) {
      var b;
      var shift = 0;
      var result = 0;
      do { b = str.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
      lat += (result & 1) ? ~(result >> 1) : (result >> 1);
      shift = 0;
      result = 0;
      do { b = str.charCodeAt(index++) - 63; result |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20);
      lng += (result & 1) ? ~(result >> 1) : (result >> 1);
      points.push([lat / 1e5, lng / 1e5]);
    }
    return points;
  }

  // Троллейбусы Таллинна в справочнике записаны как BUS; узнаём их по коду маршрута («…_trol_84») или названию.
  function routeMode(route, mode) {
    if (route && (/_trol_/.test(route.gtfsId || '') || /trollibuss/i.test(route.longName || ''))) return 'TROLLEYBUS';
    return mode || (route && route.mode) || 'BUS';
  }
  App.routeMode = routeMode;

  // Городской транспорт Таллинна — перевозчик Tallinna Linnatransport. Всё остальное (автобусы других перевозчиков,
  // поезда, паромы) считаем «междугородним» (догадка: так и называет это пользователь). Если перевозчик неизвестен — не трогаем.
  var CITY_AGENCY = 'estonia:tallinn_10312960';
  App.isIntercity = function (opt) {
    return (opt.legs || []).some(function (l) { return l.transit && l.agency && l.agency !== CITY_AGENCY; });
  };

  function normalize(it) {
    var buffer = (App.config.bufferMinutes + App.config.prepMinutes) * 60000;
    var legs = (it.legs || []).map(function (l) {
      return {
        mode: l.route ? routeMode(l.route, l.mode) : l.mode,
        transit: !!l.transitLeg || (l.mode !== 'WALK' && l.mode !== 'BICYCLE'),
        agency: l.route && l.route.agency ? l.route.agency.gtfsId : '',
        line: l.route ? (l.route.shortName || l.route.longName || '') : '',
        headsign: l.trip ? (l.trip.tripHeadsign || '') : '',
        tripId: l.trip ? l.trip.gtfsId : '',
        pattern: l.trip && l.trip.pattern && l.trip.pattern.patternGeometry ? decode(l.trip.pattern.patternGeometry.points) : [],
        stopId: l.from && l.from.stop ? l.from.stop.gtfsId : '',
        from: l.from ? l.from.name : '',
        fromLat: l.from ? l.from.lat : null,
        fromLon: l.from ? l.from.lon : null,
        to: l.to ? l.to.name : '',
        toLat: l.to ? l.to.lat : null,
        toLon: l.to ? l.to.lon : null,
        start: l.startTime,
        end: l.endTime,
        realTime: !!l.realTime,
        delay: l.departureDelay || 0,
        minutes: Math.round((l.duration || 0) / 60),
        points: l.legGeometry ? decode(l.legGeometry.points) : []
      };
    });
    var firstTransitIndex = -1;
    for (var i = 0; i < legs.length; i++) if (legs[i].transit) { firstTransitIndex = i; break; }
    var ft = firstTransitIndex >= 0 ? legs[firstTransitIndex] : null;
    var walkBefore = 0;
    for (var j = 0; j < firstTransitIndex; j++) walkBefore += legs[j].minutes;
    return {
      start: it.startTime,
      end: it.endTime,
      leaveAt: it.startTime - buffer,
      walkToStopMin: walkBefore,
      transfers: Math.max(0, legs.filter(function (l) { return l.transit; }).length - 1),
      firstTransit: ft ? {
        mode: ft.mode, line: ft.line, headsign: ft.headsign, stopName: ft.from,
        tripId: ft.tripId, stopId: ft.stopId, pattern: ft.pattern,
        stopLat: ft.fromLat, stopLon: ft.fromLon, departure: ft.start, realTime: ft.realTime, delay: ft.delay
      } : null,
      legs: legs
    };
  }

  // at — время отправления (мс); без него — «сейчас».
  function plan(from, to, n, at) {
    var vars = { fromLat: from.lat, fromLon: from.lon, toLat: to.lat, toLon: to.lon, n: n };
    if (at) {
      var d = new Date(at);
      var p2 = function (x) { return (x < 10 ? '0' : '') + x; };
      vars.date = d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate());
      vars.time = p2(d.getHours()) + ':' + p2(d.getMinutes()) + ':00';
    }
    var send = function (query) {
      return fetch(App.config.plannerUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ query: query, variables: vars })
      }).then(function (res) {
        if (!res.ok) { var e = new Error('Peatus.ee ' + res.status); e.status = res.status; throw e; }
        return res.json();
      }).then(function (json) {
        if (json.errors && json.errors.length) throw new Error(json.errors[0].message || tr('Ошибка планировщика'));
        return json;
      });
    };
    // «Для коляски»: просим планировщик искать доступные маршруты. Если он не понимает параметр — считаем как обычно
    var first = App.config.wheelchair === true
      ? send(QUERY.replace('numItineraries: $n,', 'numItineraries: $n, wheelchair: true,')).catch(function (e) {
          if (e && e.status) throw e;   // сеть/сервер недоступны — это не про параметр
          return send(QUERY);
        })
      : send(QUERY);
    return first.then(function (json) {
      var its = (json.data && json.data.plan && json.data.plan.itineraries) || [];
      return its.map(normalize)
        .filter(function (x) { return x.firstTransit; })
        .sort(function (a, b) { return a.start - b.start; });
    });
  }

  // Расписание остановки (начиная с 10 минут назад): какие рейсы и в каком порядке придут.
  var DEPS = 'query($id: String!, $start: Long!) { stop(id: $id) {' +
    ' stoptimesWithoutPatterns(startTime: $start, numberOfDepartures: 30, omitNonPickups: true) {' +
    '  serviceDay realtimeDeparture trip { gtfsId tripHeadsign route { shortName } } } } }';

  function stopDepartures(stopId) {
    var start = Math.floor(Date.now() / 1000) - 600;
    return fetch(App.config.plannerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ query: DEPS, variables: { id: stopId, start: start } })
    }).then(function (res) { return res.json(); }).then(function (json) {
      var st = json.data && json.data.stop;
      return ((st && st.stoptimesWithoutPatterns) || []).map(function (d) {
        return {
          time: (d.serviceDay + d.realtimeDeparture) * 1000,
          line: d.trip && d.trip.route ? d.trip.route.shortName : '',
          headsign: d.trip ? d.trip.tripHeadsign : '',
          tripId: d.trip ? d.trip.gtfsId : ''
        };
      }).sort(function (a, b) { return a.time - b.time; });
    });
  }

  // Остановки рейса по порядку — чтобы посчитать, сколько остановок автобусу осталось до нашей.
  var STOPS = 'query($id: String!) { trip(id: $id) { pattern { stops { gtfsId name lat lon } } } }';
  var stopsCache = {};

  function tripStops(tripId) {
    if (!tripId) return Promise.resolve(null);
    if (stopsCache[tripId]) return Promise.resolve(stopsCache[tripId]);
    return fetch(App.config.plannerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ query: STOPS, variables: { id: tripId } })
    }).then(function (res) { return res.json(); }).then(function (json) {
      var t = json.data && json.data.trip;
      var list = t && t.pattern && t.pattern.stops ? t.pattern.stops.map(function (s) {
        return { id: s.gtfsId, name: s.name, lat: s.lat, lon: s.lon };
      }) : null;
      if (list) stopsCache[tripId] = list;
      return list;
    });
  }

  // Пешеходный путь (по улицам) от точки до точки: [[lat, lon], ...]. Кэш по округлённым координатам.
  var WALKQ = 'query($fromLat: Float!, $fromLon: Float!, $toLat: Float!, $toLon: Float!) {' +
    ' plan(from: {lat: $fromLat, lon: $fromLon}, to: {lat: $toLat, lon: $toLon}, numItineraries: 1, transportModes: [{mode: WALK}]) {' +
    '  itineraries { walkDistance duration legs { legGeometry { points } } } } }';
  var walkCache = {};
  function walkKey(a, b) { return [a.lat, a.lon, b.lat, b.lon].map(function (v) { return v.toFixed(4); }).join(','); }
  function walkCached(from, to) { var c = walkCache[walkKey(from, to)]; return c && c.points ? c : null; }
  function walk(from, to) {
    var k = walkKey(from, to);
    if (walkCache[k]) return walkCache[k].p;
    var entry = { p: null, points: null };
    entry.p = fetch(App.config.plannerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ query: WALKQ, variables: { fromLat: from.lat, fromLon: from.lon, toLat: to.lat, toLon: to.lon } })
    }).then(function (r) { return r.json(); }).then(function (j) {
      var it = j.data && j.data.plan && j.data.plan.itineraries && j.data.plan.itineraries[0];
      if (!it) throw new Error('no walk');
      var pts = [];
      (it.legs || []).forEach(function (l) { if (l.legGeometry && l.legGeometry.points) pts = pts.concat(decode(l.legGeometry.points)); });
      if (pts.length < 2) throw new Error('no walk');
      entry.points = pts; entry.meters = it.walkDistance; entry.sec = it.duration;
      return entry;
    }).catch(function (e) { delete walkCache[k]; throw e; });
    walkCache[k] = entry;
    return entry.p;
  }

  App.planner = { walk: walk, walkCached: walkCached, plan: plan, decode: decode, stopDepartures: stopDepartures, tripStops: tripStops };
})(window.App = window.App || {});
