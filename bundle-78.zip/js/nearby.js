/*
 * «Рядом»: ближайшие остановки, что от них уходит, и где сейчас эти автобусы по GPS.
 * Расписание — Peatus.ee; живое время — по ближайшей машине той же линии в ту же сторону,
 * которая ещё не проехала остановку (та же логика, что для поездки).
 */
(function (App) {
  'use strict';

  var Q = 'query($lat: Float!, $lon: Float!, $r: Int!) { stopsByRadius(lat: $lat, lon: $lon, radius: $r, first: 25) {' +
    ' edges { node { distance stop { gtfsId name code lat lon vehicleMode patterns { code headsign route { shortName mode } }' +
    '  stoptimesWithoutPatterns(numberOfDepartures: 20, omitNonPickups: true, timeRange: 7200) {' +
    '   serviceDay realtimeDeparture trip { gtfsId tripHeadsign pattern { code } route { gtfsId shortName longName mode } } } } } } } }';

  var PQ = 'query($id: String!) { pattern(id: $id) { code patternGeometry { points } stops { name lat lon } } }';
  var patterns = {};   // code -> [[lat,lon]...]
  var patternStopsBy = {};   // code -> [{name, lat, lon}]
  var pending = {};

  function gql(query, variables) {
    return fetch(App.config.plannerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ query: query, variables: variables })
    }).then(function (r) {
      if (!r.ok) { var e = new Error('Peatus.ee ' + r.status); e.status = r.status; throw e; }
      return r.json();
    }).then(function (j) {
      if (j.errors && j.errors.length) throw new Error(j.errors[0].message || tr('Ошибка Peatus.ee'));
      return j.data;
    });
  }

  function pattern(code) {
    if (!code) return Promise.resolve(null);
    if (patterns[code]) return Promise.resolve(patterns[code]);
    if (pending[code]) return pending[code];
    pending[code] = gql(PQ, { id: code }).then(function (d) {
      var p = d.pattern && d.pattern.patternGeometry ? App.planner.decode(d.pattern.patternGeometry.points) : null;
      if (p) patterns[code] = p;
      if (d.pattern && d.pattern.stops) patternStopsBy[code] = d.pattern.stops;
      delete pending[code];
      return p;
    }).catch(function () { delete pending[code]; return null; });
    return pending[code];
  }

  function headsignOf(t) {
    if (t.trip && t.trip.tripHeadsign) return String(t.trip.tripHeadsign);
    var ln = t.trip && t.trip.route && t.trip.route.longName ? String(t.trip.route.longName) : '';
    var parts = ln.split(/\s*[-–—]\s*/);
    return parts.length > 1 ? parts[parts.length - 1] : (ln || '');
  }

  // Загрузить остановки вокруг точки. Остановки без отправлений в ближайшие 2 часа не показываем.
  function load(lat, lon, radius) {
    return gql(Q, { lat: lat, lon: lon, r: radius || 700 }).then(function (d) {
      var edges = (d.stopsByRadius && d.stopsByRadius.edges) || [];
      var stops = edges.map(function (e) {
        var s = e.node.stop;
        var deps = (s.stoptimesWithoutPatterns || []).map(function (t) {
          return {
            time: (t.serviceDay + t.realtimeDeparture) * 1000,
            line: t.trip && t.trip.route ? String(t.trip.route.shortName || '') : '',
            mode: t.trip && t.trip.route ? App.routeMode(t.trip.route, t.trip.route.mode) : s.vehicleMode,
            // У некоторых пригородных рейсов в Peatus.ee нет конечной — берём конец названия маршрута
            headsign: headsignOf(t),
            tripId: t.trip ? t.trip.gtfsId : '',
            pattern: t.trip && t.trip.pattern ? t.trip.pattern.code : ''
          };
        }).filter(function (x) { return x.time > Date.now() - 60000; }).sort(function (a, b) { return a.time - b.time; });
        return {
          id: s.gtfsId, name: s.name, code: s.code, lat: s.lat, lon: s.lon, mode: s.vehicleMode,
          distance: e.node.distance, deps: deps,
          // какие маршруты здесь вообще ходят — чтобы понять сторону платформы, даже если рейсов скоро нет
          patterns: (s.patterns || []).map(function (p) { return { code: p.code, headsign: p.headsign || '', line: p.route ? String(p.route.shortName || '') : '', mode: p.route ? App.routeMode(p.route, p.route.mode) : s.vehicleMode }; })
        };
      // Платформы без рейсов на 2 часа оставляем: иначе у остановки «пропадает» одна сторона.
      // Убираем только платформы, через которые вообще ничего не ходит.
      }).filter(function (s) { return s.deps.length || s.patterns.length; });
      stops.sort(function (a, b) { return a.distance - b.distance; });
      // Геометрию линий подгружаем в фоне — для живого времени и карты.
      // Платформ берём до 25: у одноимённой остановки вторая сторона улицы часто дальше десятой по счёту,
      // и без неё не получалось разделить направления. Геометрию грузим для 8 ближайших остановок (по названию).
      var names = [];
      stops.forEach(function (s) { if (names.indexOf(s.name) < 0 && names.length < 16) names.push(s.name); });
      var codes = {};
      stops.forEach(function (s) {
        if (names.indexOf(s.name) < 0) return;
        s.deps.forEach(function (x) { if (x.pattern) codes[x.pattern] = true; });
        if (!s.deps.length) s.patterns.slice(0, 2).forEach(function (p) { codes[p.code] = true; });
      });
      return Promise.all(Object.keys(codes).map(pattern)).then(function () { return stops; });
    });
  }

  // Куда уходят автобусы с остановки: «в сторону Viru keskus, Pelguranna».
  function directionText(stop) {
    var seen = [];
    stop.deps.forEach(function (d) { if (d.headsign && seen.indexOf(d.headsign) < 0) seen.push(d.headsign); });
    return seen.slice(0, 3).join(', ');
  }

  /*
   * Живое время для отправлений остановки. Для каждой пары «линия + направление» берём подъезжающие
   * машины по порядку удалённости: первое отправление — ближайшая машина, второе — следующая.
   * Если оценка по GPS расходится с расписанием больше чем на 20 минут — не верим, оставляем расписание.
   * Возвращает deps с полями eta (мс), gps (bool), vehicle.
   */
  function live(stop) {
    // Один расчёт на данные GPS (раз в 10 с): переключение вкладок и перерисовки не пересчитывают заново
    var ck = (App.feed.at || 0) + '|' + Math.floor(Date.now() / 15000) + '|' + stop.deps.length;
    if (stop.__liveKey === ck && stop.__live) return stop.__live;
    stop.__liveKey = ck;
    stop.__live = liveCalc(stop);
    return stop.__live;
  }
  function liveCalc(stop) {
    var groups = {};
    var now = Date.now();
    var gpsAt = App.feed.at || now;
    return stop.deps.map(function (d) {
      var key = d.mode + '|' + d.line + '|' + d.headsign;
      if (!groups[key]) {
        var pts = patterns[d.pattern];
        var ahead = [];
        if (App.feed.ok && pts) {
          var near = App.vehicles.approaching(App.feed.vehicles,
            { line: d.line, mode: d.mode, headsign: d.headsign, pattern: pts, stopLat: stop.lat, stopLon: stop.lon }, null, 0, null, { others: App.nearby.cachedOthers(d.line, d.mode) });
          ahead = (near.mine ? [near.mine] : []).concat(near.others || []).filter(function (v) { return v.path; });
          ahead.sort(function (a, b) { return a.toStop - b.toStop; });
        }
        groups[key] = { ahead: ahead, used: 0 };
      }
      var g = groups[key];
      var out = { time: d.time, line: d.line, mode: d.mode, headsign: d.headsign, tripId: d.tripId, pattern: d.pattern, eta: d.time, gps: false, vehicle: null };
      var v = g.ahead[g.used];
      if (v) {
        var eta = gpsAt + v.toStop / App.vehicles.SPEED * 60000;
        if (v.viaLoop) eta = Math.max(eta, d.time);   // после разворота раньше расписания не уйдёт
        if (Math.abs(eta - d.time) < 20 * 60000) {
          out.eta = eta;
          out.gps = true;
          // копия: approaching() переписывает поля машины при расчёте для другой остановки
          out.vehicle = { id: v.id, lat: v.lat, lon: v.lon, line: v.line, mode: v.mode, toStop: v.toStop, path: v.path, viaLoop: !!v.viaLoop };
          g.used++;
        }
      }
      return out;
    }).filter(function (x) { return x.eta > now - 30000; }).sort(function (a, b) { return a.eta - b.eta; });
  }

  /*
   * Маршрут машины с карты: по номеру линии берём все варианты маршрута из Peatus.ee
   * (в Эстонии много линий «44» в разных городах), и выбираем тот, рядом с которым машина сейчас едет
   * и чья конечная совпадает с табло машины. Возвращает { points, stops, headsign } или null.
   */
  var RQ = 'query($name: String!) { routes(name: $name) { shortName mode patterns { code headsign' +
    ' patternGeometry { points } stops { name lat lon } } } }';
  var routeCache = {};
  function routeList(mode, line) {
    var key = mode + '|' + line;
    return routeCache[key] || (routeCache[key] = gql(RQ, { name: String(line) }).then(function (d) {
      var out = [];
      (d.routes || []).forEach(function (r) {
        if (String(r.shortName).toUpperCase() !== String(line).toUpperCase()) return;
        if ((mode === 'TRAM') !== (r.mode === 'TRAM')) return;
        (r.patterns || []).forEach(function (pt) {
          if (!pt.patternGeometry) return;
          out.push({ code: pt.code, headsign: pt.headsign, points: App.planner.decode(pt.patternGeometry.points), stops: pt.stops || [] });
        });
      });
      return out;
    }).catch(function (e) { delete routeCache[key]; throw e; }));
  }
  // Другие варианты маршрута линии (обратное направление) — для расчёта «через разворот». Пока не загрузились — null.
  var othersReady = {};
  function cachedOthers(line, mode) {
    var m = String(mode || '').toUpperCase() === 'TRAM' ? 'TRAM' : 'BUS';
    var key = m + '|' + line;
    if (othersReady[key]) return othersReady[key];
    routeList(m, line).then(function (list) { othersReady[key] = list.map(function (x) { return x.points; }); }).catch(function () { /* без обратного маршрута */ });
    return null;
  }
  function routeFor(v) {
    var p = routeList(v.mode, v.line);
    return p.then(function (patterns) {
      var best = null;
      var bestScore = Infinity;
      patterns.forEach(function (pt) {
        var d = App.vehicles.distToLine(pt.points, v.lat, v.lon);
        if (d > 300) return;
        var score = d + (v.destination && App.vehicles.sameName(pt.headsign, v.destination) ? 0 : 400);
        if (score < bestScore) { bestScore = score; best = pt; }
      });
      return best;
    });
  }

  App.nearby = { routeFor: routeFor, cachedOthers: cachedOthers, load: load, live: live, pattern: function (code) { return patterns[code] || null; }, patternStops: function (code) { return patternStopsBy[code] || null; }, directionText: directionText };
})(window.App = window.App || {});
