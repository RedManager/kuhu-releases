/*
 * Языки: русский (исходный текст), английский, эстонский. Ключ перевода — русская фраза.
 * Язык: выбор в настройках («Авто» — по языку телефона; для остальных языков — английский).
 * Смена языка перезагружает страницу, поэтому строки переводятся в момент показа.
 */
(function (App) {
  'use strict';
  var DICT = window.PV_LANG || { en: {}, et: {} };
  var SUPPORTED = ['ru', 'en', 'et'];

  function stored() { try { return localStorage.getItem('pv.lang') || 'auto'; } catch (e) { return 'auto'; } }
  function detect() {
    var s = stored();
    if (SUPPORTED.indexOf(s) >= 0) return s;
    var n = String((navigator.languages && navigator.languages[0]) || navigator.language || 'en').slice(0, 2).toLowerCase();
    return SUPPORTED.indexOf(n) >= 0 ? n : 'en';
  }
  var lang = detect();

  function tr(s) {
    if (lang === 'ru') return s;
    var v = DICT[lang] && DICT[lang][s];
    return v === undefined ? s : v;
  }

  // Статичная разметка index.html: тексты и подписи переводим при старте
  function translateDom() {
    if (lang === 'ru') return;
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    var n;
    while ((n = walker.nextNode())) {
      var t = n.nodeValue.trim();
      if (t && /[А-Яа-яЁё]/.test(t)) { var v = tr(t); if (v !== t) n.nodeValue = n.nodeValue.replace(t, v); }
    }
    ['aria-label', 'placeholder', 'title', 'alt'].forEach(function (a) {
      Array.prototype.forEach.call(document.querySelectorAll('[' + a + ']'), function (el) {
        var t = el.getAttribute(a);
        if (t && /[А-Яа-яЁё]/.test(t)) el.setAttribute(a, tr(t));
      });
    });
  }

  document.documentElement.lang = lang;
  window.tr = tr;
  translateDom();
  App.i18n = {
    lang: lang,
    choice: stored,
    set: function (v) { try { localStorage.setItem('pv.lang', v); } catch (e) { /* без хранилища */ } window.location.reload(); },
    translateDom: translateDom,
    locale: function () { return lang === 'ru' ? 'ru-RU' : lang === 'et' ? 'et-EE' : 'en-GB'; }
  };
})(window.App = window.App || {});
