/*
 * Живые координаты транспорта Таллина: transport.tallinn.ee/gps.txt
 * Строка: тип,линия,долгота,широта,,курс,id,статус,?,конечная
 * Тип: 1 — троллейбус/спец., 2 — автобус, 3 — трамвай (номер с буквой: T1, T2…).
 * Координаты — в миллионных долях градуса.
 */
  // Курс 0..360; 999 и прочее — «неизвестен» (NaN), чтобы не отбрасывать такую машину как «едет в другую сторону»
  function hdg(x) { var h = parseInt(x, 10); return isFinite(h) && h >= 0 && h <= 360 ? h : NaN; }
(function (App) {
  'use strict';

  var TYPE_TO_MODE = { '1': 'TROLLEYBUS', '2': 'BUS', '3': 'TRAM' };

  function parse(text) {
    return text.split(/\r?\n/).map(function (line) {
      var p = line.split(',');
      if (p.length < 4) return null;
      var lon = parseInt(p[2], 10) / 1e6;
      var lat = parseInt(p[3], 10) / 1e6;
      if (!isFinite(lat) || !isFinite(lon) || !lat) return null;
      return {
        mode: TYPE_TO_MODE[p[0]] || 'BUS', line: (p[1] || '').trim(), lat: lat, lon: lon,
        heading: hdg(p[5]), id: p[6] || '', destination: (p[9] || '').trim()
      };
    }).filter(Boolean);
  }

  function load() {
    return fetch(App.config.gpsUrl + '?t=' + Date.now()).then(function (res) {
      if (!res.ok) throw new Error('GPS ' + res.status);
      return res.text();
    }).then(parse);
  }

  // «T1» и «1» — один и тот же трамвай; регистр и пробелы не важны.
  function lineKey(s) { return String(s || '').toUpperCase().replace(/\s+/g, '').replace(/^T(?=\d)/, ''); }

  // Сравнение названий конечных без диакритики и регистра: «Pelguranna» ~ «PELGURANNA».
  function nameKey(s) {
    return String(s || '').toLowerCase()
      .replace(/[äà]/g, 'a').replace(/[öõô]/g, 'o').replace(/[ü]/g, 'u').replace(/[š]/g, 's').replace(/[ž]/g, 'z')
      .replace(/[^a-z0-9]/g, '');
  }
  function sameName(a, b) {
    a = nameKey(a);
    b = nameKey(b);
    if (!a || !b) return false;
    var n = Math.min(5, a.length, b.length);
    return a.indexOf(b) === 0 || b.indexOf(a) === 0 || a.slice(0, n) === b.slice(0, n);
  }

  // Кольцевые линии (по списку Jelena): у них конечная на табло не говорит о направлении,
  // поэтому машину выбираем по форме маршрута и курсу, а не по названию конечной.
  var CIRC_TRAM = ['1', '2', '3', '4', '5'];
  var CIRC_BUS = ['4', '6', '21', '21B', '24', '40', '41', '41B', '73', '91', '92', '93', '94', '95', '96', '111', '111A', '123', 'V4', 'V4A', 'V6', 'V6A', 'V7', 'V7A'];
  function isCircular(line, mode) {
    var k = String(line || '').toUpperCase().replace(/\s+/g, '');
    if (String(mode || '').toUpperCase() === 'TRAM') return CIRC_TRAM.indexOf(k.replace(/^T(?=\d)/, '')) >= 0;
    return CIRC_BUS.indexOf(k) >= 0;
  }

  function forLine(all, line) {
    var key = lineKey(line);
    return all.filter(function (v) { return lineKey(v.line) === key; });
  }

  // Расстояние в метрах (приближение для города).
  function dist(aLat, aLon, bLat, bLon) {
    var k = 111320;
    var dx = (bLon - aLon) * k * Math.cos(aLat * Math.PI / 180);
    var dy = (bLat - aLat) * k;
    return Math.sqrt(dx * dx + dy * dy);
  }

  // Расстояние от точки до ломаной, начиная с отметки skipMeters от её начала.
  function distToPath(lat, lon, points, skipMeters) {
    var walked = 0;
    var best = Infinity;
    for (var i = 1; i < points.length; i++) {
      var a = points[i - 1];
      var b = points[i];
      var seg = dist(a[0], a[1], b[0], b[1]);
      walked += seg;
      if (walked < skipMeters) continue;
      // проекция точки на отрезок
      var k = 111320;
      var cos = Math.cos(lat * Math.PI / 180);
      var ax = a[1] * k * cos;
      var ay = a[0] * k;
      var bx = b[1] * k * cos;
      var by = b[0] * k;
      var px = lon * k * cos;
      var py = lat * k;
      var dx = bx - ax;
      var dy = by - ay;
      var t = dx || dy ? ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy) : 0;
      t = Math.max(0, Math.min(1, t));
      var ex = ax + t * dx - px;
      var ey = ay + t * dy - py;
      best = Math.min(best, Math.sqrt(ex * ex + ey * ey));
    }
    return best;
  }

  /*
   * «Через разворот»: машина едет не к нашей остановке, а в другую сторону или уже проехала её,
   * но на конечной развернётся и придёт к нам следующим рейсом (так ходят кольцевые линии и трамваи).
   * Путь = до конца своего маршрута + стоянка на конечной + от начала нашего маршрута до остановки.
   * others — другие варианты маршрута этой линии (обратное направление). Возвращает { toStop, path } или null.
   */
  var LAYOVER_M = 1000;      // стоянка на конечной ≈ 3 мин × 330 м/мин (оценка)
  var LOOP_MAX_M = 15000;    // дальше этого (≈ 45 мин) через разворот не считаем
  function patLen(pts) { return pts.__len || (pts.__len = pathLength(pts)); }
  function loopVia(v, P, others, transit, fromStart) {
    var end = P[P.length - 1];
    var startToEnd = dist(P[0][0], P[0][1], end[0], end[1]);
    var onP = onPattern(P, v, transit.stopLat, transit.stopLon);
    var i, R, onR;
    // 1) уже проехала нашу остановку по нашему же маршруту
    if (onP && onP.passed) {
      var cs = candidates(P, v.lat, v.lon, 40, 150, v.heading);
      if (!cs.length) return null;
      var c = cs.reduce(function (a, b) { return b.along > a.along ? b : a; });
      var rest = patLen(P) - c.along;
      var tail = [[v.lat, v.lon]].concat(P.slice(c.i + 1));
      if (startToEnd < 600) {                       // кольцо: конец рядом с началом
        var t1 = rest + LAYOVER_M + fromStart.toStop;
        return t1 <= LOOP_MAX_M ? { toStop: t1, path: tail.concat(fromStart.path) } : null;
      }
      for (i = 0; i < (others || []).length; i++) {  // туда-обратно: проехать конец, всё обратное направление и вернуться
        R = others[i];
        if (!R || R.length < 2 || dist(R[0][0], R[0][1], end[0], end[1]) > 600) continue;
        var t2 = rest + LAYOVER_M + patLen(R) + LAYOVER_M + fromStart.toStop;
        if (t2 <= LOOP_MAX_M) return { toStop: t2, path: tail.concat(R, fromStart.path) };
      }
      return null;
    }
    if (onP) return null;                            // едет к остановке напрямую — это не наш случай
    // 2) едет по обратному направлению: до его конца, там разворот, потом к нам
    var best = null;
    for (i = 0; i < (others || []).length; i++) {
      R = others[i];
      if (!R || R.length < 2) continue;
      var rEnd = R[R.length - 1];
      if (dist(rEnd[0], rEnd[1], P[0][0], P[0][1]) > 600) continue;   // обратный маршрут должен кончаться у начала нашего
      onR = onPattern(R, v, rEnd[0], rEnd[1]);
      if (!onR || onR.passed) continue;
      var t3 = onR.toStop + LAYOVER_M + fromStart.toStop;
      if (t3 <= LOOP_MAX_M && (!best || t3 < best.toStop)) best = { toStop: t3, path: onR.path.concat(fromStart.path) };
    }
    return best;
  }

  /*
   * Какая машина — «наша».
   * rank — сколько автобусов этой линии в эту сторону придут на остановку раньше нашего рейса
   *        (по расписанию остановки). Наш — (rank+1)-й по удалённости среди подъезжающих.
   * minutesLeft — через сколько минут наш рейс по расписанию: помогает, если соседний автобус
   *        опаздывает или идёт с опережением (берём лучшего по времени из соседей по очереди).
   * Подъезжающие = та же линия, в нужную сторону и ещё не проехали остановку.
   * Возвращает { mine, others, rank, byDirection, notYet }.
   */
  var STILL_MS = 6 * 60000;
  var SPEED_M_PER_MIN = 330; // средняя скорость по дороге с учётом остановок, ~20 км/ч (оценка)

  // Ближайшая точка на ломаной среди отрезков [from..to): { i — начало отрезка, d — расстояние, p — точка на отрезке }.
  function nearestOnPath(points, lat, lon, from, to) {
    var best = { i: -1, d: Infinity, p: null };
    var k = 111320;
    var cos = Math.cos(lat * Math.PI / 180);
    var px = lon * k * cos;
    var py = lat * k;
    for (var i = Math.max(0, from); i < to && i + 1 < points.length; i++) {
      var a = points[i];
      var b = points[i + 1];
      var ax = a[1] * k * cos;
      var ay = a[0] * k;
      var dx = b[1] * k * cos - ax;
      var dy = b[0] * k - ay;
      var len2 = dx * dx + dy * dy;
      var t = len2 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
      t = Math.max(0, Math.min(1, t));
      var ex = ax + t * dx - px;
      var ey = ay + t * dy - py;
      var d = Math.sqrt(ex * ex + ey * ey);
      if (d < best.d) best = { i: i, d: d, p: [a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1])] };
    }
    return best;
  }

  // Расстояние вдоль линии от её начала до точки проекции (результат nearestOnPath).
  function cumulative(points) {
    if (points.__cum) return points.__cum;
    var cum = [0];
    for (var i = 1; i < points.length; i++) {
      cum.push(cum[i - 1] + dist(points[i - 1][0], points[i - 1][1], points[i][0], points[i][1]));
    }
    points.__cum = cum;
    return cum;
  }
  function alongAt(points, near) {
    if (!near || near.i < 0) return null;
    var cum = cumulative(points);
    return cum[near.i] + dist(points[near.i][0], points[near.i][1], near.p[0], near.p[1]);
  }

  /*
   * Сколько остановок машине осталось проехать до нашей (нашу не считаем).
   * stops — остановки рейса по порядку [{lat, lon}], v — машина с полями along/stopAlong.
   */
  function stopsLeft(pattern, stops, v) {
    if (!pattern || !stops || !v || v.along === null || v.along === undefined || v.stopAlong === null) return null;
    var n = 0;
    stops.forEach(function (st) {
      var p = nearestOnPath(pattern, st.lat, st.lon, 0, pattern.length - 1);
      if (p.d > 80) return;                          // остановка в стороне от линии — не считаем
      var a = alongAt(pattern, p);
      if (a > v.along + 30 && a < v.stopAlong - 30) n++;
    });
    return n;
  }

  function pathLength(points) {
    var sum = 0;
    for (var i = 1; i < points.length; i++) sum += dist(points[i - 1][0], points[i - 1][1], points[i][0], points[i][1]);
    return sum;
  }

  /*
   * По полной линии рейса (pattern) — где машина относительно нашей остановки:
   * { passed, toStop (м по дороге), path: [[lat,lon]...] от машины до остановки } или null, если машина не на этой линии.
   */
  // Рамка линии (с запасом) — чтобы не считать расстояние до линии для машин в другом конце города.
  function bbox(points) {
    if (points.__bbox) return points.__bbox;
    var b = { s: 90, n: -90, w: 180, e: -180 };
    points.forEach(function (p) { if (p[0] < b.s) b.s = p[0]; if (p[0] > b.n) b.n = p[0]; if (p[1] < b.w) b.w = p[1]; if (p[1] > b.e) b.e = p[1]; });
    points.__bbox = b;
    return b;
  }
  // Все места, где точка близка к линии (у кольцевого маршрута линия проходит одну улицу дважды).
  // tol — на сколько метров можно быть дальше лучшего совпадения; heading — курс машины (градусы) или NaN.
  function candidates(points, lat, lon, tol, maxD, heading) {
    var k = 111320;
    var cos = Math.cos(lat * Math.PI / 180);
    var px = lon * k * cos;
    var py = lat * k;
    var n = points.length - 1;
    var ds = new Array(n);
    var ts = new Array(n);
    var best = Infinity;
    for (var i = 0; i < n; i++) {
      var a = points[i];
      var b = points[i + 1];
      var ax = a[1] * k * cos;
      var ay = a[0] * k;
      var dx = b[1] * k * cos - ax;
      var dy = b[0] * k - ay;
      var len2 = dx * dx + dy * dy;
      var t = len2 ? ((px - ax) * dx + (py - ay) * dy) / len2 : 0;
      t = Math.max(0, Math.min(1, t));
      var ex = ax + t * dx - px;
      var ey = ay + t * dy - py;
      ds[i] = Math.sqrt(ex * ex + ey * ey);
      ts[i] = t;
      if (ds[i] < best) best = ds[i];
    }
    if (best > maxD) return [];
    var cum = cumulative(points);
    var out = [];
    for (var j = 0; j < n; j++) {
      if (ds[j] > best + tol) continue;
      if ((j > 0 && ds[j - 1] < ds[j]) || (j < n - 1 && ds[j + 1] < ds[j])) continue; // не локальный минимум
      var pt = [points[j][0] + ts[j] * (points[j + 1][0] - points[j][0]), points[j][1] + ts[j] * (points[j + 1][1] - points[j][1])];
      var along = cum[j] + dist(points[j][0], points[j][1], pt[0], pt[1]);
      if (out.length && along - out[out.length - 1].along < 100) {
        if (ds[j] < out[out.length - 1].d) out[out.length - 1] = { i: j, d: ds[j], p: pt, along: along };
        continue;
      }
      out.push({ i: j, d: ds[j], p: pt, along: along });
    }
    if (isFinite(heading) && out.length > 1) {
      var fit = out.filter(function (c) {
        var a = points[c.i];
        var b = points[c.i + 1];
        var br = Math.atan2((b[1] - a[1]) * cos, b[0] - a[0]) * 180 / Math.PI;
        var diff = Math.abs(((br - heading) % 360 + 540) % 360 - 180);
        return diff < 100;
      });
      if (fit.length) out = fit;
    } else if (isFinite(heading) && heading !== 0 && out.length === 1) {
      // Одно совпадение, но машина едет строго навстречу маршруту (трамваи ходят по тем же путям в обе стороны)
      var c1 = out[0];
      var a1 = points[c1.i];
      var b1 = points[c1.i + 1];
      var br1 = Math.atan2((b1[1] - a1[1]) * cos, b1[0] - a1[0]) * 180 / Math.PI;
      var diff1 = Math.abs(((br1 - heading) % 360 + 540) % 360 - 180);
      if (diff1 > 135) return [];
    }
    return out;
  }

  function onPattern(pattern, v, stopLat, stopLon) {
    if (!pattern || pattern.length < 2) return null;
    var bb = bbox(pattern);
    // ~200 м запаса: дальше рамки — точно не на линии (быстрая проверка без перебора всей линии)
    if (v.lat < bb.s - 0.002 || v.lat > bb.n + 0.002 || v.lon < bb.w - 0.004 || v.lon > bb.e + 0.004) return null;
    // Остановки на линии одни и те же для всех машин — считаем один раз
    var cache = pattern.__stops || (pattern.__stops = {});
    var sk = stopLat.toFixed(6) + ',' + stopLon.toFixed(6);
    var ss = cache[sk] || (cache[sk] = candidates(pattern, stopLat, stopLon, 30, 1e9, NaN));
    var vs = candidates(pattern, v.lat, v.lon, 40, 150, v.heading);
    if (!vs.length || !ss.length) return null;        // машина не на этом маршруте (объезд, депо)
    // Пара «где машина» + «где остановка» с наименьшим путём вперёд по линии.
    var best = null;
    vs.forEach(function (c) {
      if (c.d > 100) return;
      ss.forEach(function (st) {
        var gap = st.along - c.along;
        if (gap < -1) return;
        if (!best || gap < best.gap) best = { gap: gap, c: c, st: st };
      });
    });
    if (!best) return { passed: true };               // на линии, но уже после нашей остановки (во всех проходах)
    var path = [best.c.p].concat(pattern.slice(best.c.i + 1, best.st.i + 1)).concat([best.st.p]);
    return { passed: false, toStop: pathLength(path), path: path, along: best.c.along, stopAlong: best.st.along };
  }

  // opts: { lockId — машина, уже закреплённая за этим рейсом; exclude — машины, закреплённые за другими рейсами }
  function approaching(all, transit, legPoints, rank, minutesLeft, opts) {
    opts = opts || {};
    var exclude = opts.exclude || [];
    // Трамвай 1 и автобус 1 — разные линии: сравниваем и вид транспорта (трамвай / не трамвай).
    var line = forLine(all, transit.line).filter(function (v) {
      return !transit.mode || (v.mode === 'TRAM') === (String(transit.mode).toUpperCase() === 'TRAM');
    });
    var circ = isCircular(transit.line, transit.mode);
    var dir = circ ? line : transit.headsign ? line.filter(function (v) { return sameName(v.destination, transit.headsign); }) : [];
    var byDirection = dir.length > 0;
    var pool = (byDirection ? dir : line).filter(function (v) { return exclude.indexOf(v.id) < 0; });
    var ahead = pool.filter(function (v) {
      v.path = null;
      v.along = null;
      v.stopAlong = null;
      var onP = onPattern(transit.pattern, v, transit.stopLat, transit.stopLon);
      if (onP) {
        if (onP.passed) return false;
        v.toStop = onP.toStop;
        v.path = onP.path;
        v.along = onP.along;
        v.stopAlong = onP.stopAlong;
        return true;
      }
      if (transit.pattern && transit.pattern.length > 1) {
        // Линия рейса известна, а машина не на ней: после конечной едет в парк, стоит на разворотном кольце
        // или уже выполняет другой рейс (табло ещё показывает старую конечную). Это не наш автобус.
        // Исключение — машина ждёт у начала маршрута (в пределах 400 м от первой точки).
        var start = transit.pattern[0];
        var d0 = dist(v.lat, v.lon, start[0], start[1]);
        if (d0 > 400) return false;
        var fromStart = onPattern(transit.pattern, { lat: start[0], lon: start[1] }, transit.stopLat, transit.stopLon);
        if (!fromStart || fromStart.passed) return false;
        v.toStop = d0 + fromStart.toStop;
        v.path = [[v.lat, v.lon]].concat(fromStart.path);
        return true;
      }
      v.toStop = dist(v.lat, v.lon, transit.stopLat, transit.stopLon) * 1.3; // по прямой + запас на повороты
      if (!legPoints || legPoints.length < 2) return true;
      return distToPath(v.lat, v.lon, legPoints, 250) > 120;
    });
    // Рейс ещё не начался или машина уже проехала остановку: она развернётся на конечной и придёт следующим рейсом
    line.forEach(function (v) { v.viaLoop = false; });
    if (transit.pattern && transit.pattern.length > 1 && !opts.noLoop) {
      var P0 = transit.pattern[0];
      var fromStartP = onPattern(transit.pattern, { lat: P0[0], lon: P0[1] }, transit.stopLat, transit.stopLon);
      if (fromStartP && !fromStartP.passed) {
        line.forEach(function (v) {
          if (ahead.indexOf(v) >= 0 || exclude.indexOf(v.id) >= 0) return;
          var lp = loopVia(v, transit.pattern, opts.others, transit, fromStartP);
          if (!lp) return;
          v.toStop = lp.toStop; v.path = lp.path; v.along = null; v.stopAlong = null; v.viaLoop = true;
          ahead.push(v);
        });
      }
    }
    // Стоит на месте дольше 6 минут посреди маршрута — GPS машины завис (или она сломалась): не наш автобус
    ahead = ahead.filter(function (v) { return !(v.still > STILL_MS && v.toStop > 400); });
    ahead.sort(function (a, b) { return a.toStop - b.toStop; });

    var res = { mine: null, others: ahead, rank: rank || 0, byDirection: byDirection, notYet: false, departed: false };
    if (!byDirection) return res;

    // Закреплённая машина: пока она едет к остановке — это наш автобус; проехала — рейс ушёл.
    if (opts.lockId) {
      var locked = null;
      var inFeed = false;
      pool.forEach(function (v) { if (v.id === opts.lockId) inFeed = true; });
      ahead.forEach(function (v) { if (v.id === opts.lockId) locked = v; });
      if (locked) {
        res.mine = locked;
        res.others = ahead.filter(function (v) { return v !== locked; });
        return res;
      }
      if (inFeed) { res.departed = true; res.others = ahead; return res; }
    }
    rank = rank || 0;
    if (rank >= ahead.length) {
      res.notYet = true;
      res.coming = comingBack(line, dir, transit, rank - ahead.length);
      return res;
    }

    var best = ahead[rank];
    if (typeof minutesLeft === 'number') {
      var bestScore = Infinity;
      [rank - 1, rank, rank + 1].forEach(function (i) {
        var v = ahead[i];
        if (!v) return;
        var score = Math.abs(v.toStop / SPEED_M_PER_MIN - minutesLeft) + (i === rank ? 0 : 3);
        if (score < bestScore) { bestScore = score; best = v; }
      });
    }
    res.mine = best;
    res.others = ahead.filter(function (v) { return v !== best; });
    return res;
  }

  /*
   * Наш рейс ещё не начался: машина этой линии едет в обратную сторону к начальной конечной и там развернётся.
   * Берём n-ю по близости к началу нашего маршрута (до 8 км по прямой). Это догадка, поэтому время не трогаем —
   * только показываем машину на карте. { v, toStart (м по прямой), terminal }
   */
  function comingBack(line, dir, transit, n) {
    var pts = transit.pattern;
    if (!pts || pts.length < 2) return null;
    var start = pts[0];
    var back = line.filter(function (v) { return dir.indexOf(v) < 0; }).map(function (v) {
      return { v: v, d: dist(v.lat, v.lon, start[0], start[1]) };
    }).filter(function (x) { return x.d < 8000; });
    back.sort(function (a, b) { return a.d - b.d; });
    var x = back[Math.max(0, n)];
    return x ? { v: x.v, toStart: x.d, terminal: x.v.destination || '' } : null;
  }

  // Сколько рейсов той же линии в ту же сторону придут раньше нашего (по расписанию остановки).
  function rankOf(deps, transit, now, skipTrips) {
    skipTrips = skipTrips || [];
    if (!deps || !deps.length) return 0;
    var key = lineKey(transit.line);
    var same = deps.filter(function (d) {
      return lineKey(d.line) === key && sameName(d.headsign, transit.headsign) &&
        (d.tripId === transit.tripId || skipTrips.indexOf(d.tripId) < 0);
    });
    var idx = -1;
    same.forEach(function (d, i) { if (idx < 0 && transit.tripId && d.tripId === transit.tripId) idx = i; });
    var before = idx >= 0 ? same.slice(0, idx) : same.filter(function (d) { return d.time < transit.departure - 30000; });
    // Рейсы, которые по расписанию ушли больше 2 минут назад, считаем уже уехавшими.
    return before.filter(function (d) { return d.time >= now - 120000; }).length;
  }

  // Расстояние (м) от точки до линии маршрута — чтобы понять, по какому варианту маршрута едет машина.
  function distToLine(points, lat, lon) {
    if (!points || points.length < 2) return Infinity;
    return nearestOnPath(points, lat, lon, 0, points.length - 1).d;
  }

  App.vehicles = { load: load, parse: parse, forLine: forLine, approaching: approaching, rankOf: rankOf, dist: dist, stopsLeft: stopsLeft,
    sameName: sameName, isCircular: isCircular, distToLine: distToLine, onPattern: onPattern, SPEED: SPEED_M_PER_MIN };
})(window.App = window.App || {});
