/* Адрес → координаты через In-ADS (Земельный департамент Эстонии). */
(function (App) {
  'use strict';
  var cache = {};

  // Поиск адреса. Без запятой считаем, что это Таллинн. Возвращает { address (коротко), full, lat, lon }.
  function find(text) {
    var q = String(text || '').trim();
    if (!q) return Promise.reject(new Error(tr('Напиши адрес')));
    if (q.indexOf(',') < 0) q += ', Tallinn';
    if (cache[q]) return Promise.resolve(cache[q]);
    return fetch(App.config.geocodeUrl + encodeURIComponent(q)).then(function (r) {
      if (!r.ok) throw new Error(tr('Адресный сервис не ответил (') + r.status + ')');
      return r.json();
    }).then(function (j) {
      var a = j && j.addresses && j.addresses[0];
      if (!a || !a.viitepunkt_b) throw new Error(tr('Не нашла такой адрес. Проверь улицу и номер дома.'));
      var full = a.pikkaadress || '';
      var parts = full.split(',');
      var out = {
        address: (parts[parts.length - 1] || text).trim().replace(/ tn /, ' '),
        full: full,
        lat: parseFloat(a.viitepunkt_b),
        lon: parseFloat(a.viitepunkt_l)
      };
      cache[q] = out;
      return out;
    });
  }

  // ---- Эстонские буквы без эстонской клавиатуры ----
  // На ТВ нет ä, õ, ö, ü, š, ž. Поэтому «Jarve» ищем и как «Järve»: перебираем варианты первого слова
  // (улицы) и оставляем только адреса, которые совпадают с введённым, если убрать точки над буквами.
  var PLAIN = { 'ä': 'a', 'ö': 'o', 'õ': 'o', 'ü': 'u', 'š': 's', 'ž': 'z' };
  function plain(t) {
    return String(t || '').toLowerCase().replace(/[äöõüšž]/g, function (c) { return PLAIN[c]; });
  }
  var ACCENTS = { a: ['ä'], o: ['õ', 'ö'], u: ['ü'], s: ['š'], z: ['ž'] };

  function variants(q) {
    var m = q.match(/^[^\s,0-9]+/);
    if (!m) return [q];
    var word = m[0], tail = q.slice(word.length);
    var lower = word.toLowerCase();
    var pos = [];
    for (var i = 0; i < lower.length; i++) if (ACCENTS[lower[i]]) pos.push(i);
    var out = [q];
    function put(w) { var v = w + tail; if (out.indexOf(v) < 0) out.push(v); }
    function swap(w, i, c) {
      var ch = w[i] === w[i].toUpperCase() ? c.toUpperCase() : c;
      return w.slice(0, i) + ch + w.slice(i + 1);
    }
    // одна замена (самые частые: ä, õ, ü, потом ö, š, ž)
    ['ä', 'õ', 'ü', 'ö', 'š', 'ž'].forEach(function (c) {
      pos.forEach(function (i) { if (ACCENTS[lower[i]].indexOf(c) >= 0) put(swap(word, i, c)); });
    });
    // две одинаковые подряд: Vääna, Rüütli
    pos.forEach(function (i) {
      if (lower[i + 1] === lower[i]) ACCENTS[lower[i]].forEach(function (c) { put(swap(swap(word, i, c), i + 1, c)); });
    });
    return out.slice(0, 7); // не больше 7 запросов за раз — ТВ и сервис не перегружаем
  }

  function parseList(addresses) {
    return (addresses || []).filter(function (a) { return a && a.viitepunkt_b && a.pikkaadress; }).map(function (a) {
      var parts = a.pikkaadress.split(',').map(function (s) { return s.trim(); });
      var main = parts[parts.length - 1];
      var rest = parts.slice(0, -1).filter(function (s) { return !/maakond$/.test(s); });
      return {
        address: main.replace(/ tn /, ' '),
        sub: rest.join(', '),
        full: a.pikkaadress,
        lat: parseFloat(a.viitepunkt_b),
        lon: parseFloat(a.viitepunkt_l),
        tallinn: /(^|, )Tallinn(,|$)/.test(a.pikkaadress)
      };
    });
  }

  function query(q) {
    return fetch(App.config.geocodeUrl + encodeURIComponent(q) + '&results=10').then(function (r) {
      if (!r.ok) throw new Error(tr('Адресный сервис не ответил (') + r.status + ')');
      return r.json();
    }).then(function (j) { return parseList(j && j.addresses); }, function () { return []; });
  }

  // Подсказки при вводе (как на omniva.ee): In-ADS понимает неполный адрес и отдаёт настоящие
  // эстонские адреса. Возвращает до 5 штук [{ address, sub, full, lat, lon }], Таллинн — первым.
  var sugCache = {};
  function suggest(text) {
    var q = String(text || '').trim();
    if (q.length < 3) return Promise.resolve([]);
    if (sugCache[q]) return Promise.resolve(sugCache[q]);
    var want = plain(q.match(/^[^\s,0-9]+/) ? q.match(/^[^\s,0-9]+/)[0] : q);
    return Promise.all(variants(q).map(query)).then(function (lists) {
      var seen = {}, all = [];
      lists.forEach(function (l) { l.forEach(function (a) { if (!seen[a.full]) { seen[a.full] = true; all.push(a); } }); });
      // совпадает без учёта точек над буквами — значит это то, что искали
      var good = all.filter(function (a) { return plain(a.address).indexOf(want) >= 0; });
      var list = good.length ? good : all;
      list.sort(function (x, y) {
        var sx = plain(x.address).indexOf(want) === 0 ? 1 : 0, sy = plain(y.address).indexOf(want) === 0 ? 1 : 0;
        return (sy - sx) || ((y.tallinn ? 1 : 0) - (x.tallinn ? 1 : 0));
      });
      list = list.slice(0, 5);
      sugCache[q] = list;
      return list;
    });
  }

  function resolve(place) {
    if (place.lat && place.lon) return Promise.resolve(place);
    return find(place.address).then(function (f) {
      return { name: place.name, address: place.address, mode: place.mode, lat: f.lat, lon: f.lon };
    });
  }

  // ---- Адрес по точке на карте ----
  // In-ADS ищет по координатам L-EST97 (EPSG:3301): x — восток, y — север. Пересчёт из GPS (WGS84/GRS80).
  function lest97(lat, lon) {
    var a = 6378137, f = 1 / 298.257222101, e = Math.sqrt(2 * f - f * f), r = Math.PI / 180;
    var p1 = 59.33333333333333 * r, p2 = 58 * r, p0 = 57.51755393055556 * r, l0 = 24 * r;
    function m(p) { return Math.cos(p) / Math.sqrt(1 - e * e * Math.sin(p) * Math.sin(p)); }
    function t(p) { return Math.tan(Math.PI / 4 - p / 2) / Math.pow((1 - e * Math.sin(p)) / (1 + e * Math.sin(p)), e / 2); }
    var n = (Math.log(m(p1)) - Math.log(m(p2))) / (Math.log(t(p1)) - Math.log(t(p2)));
    var F = m(p1) / (n * Math.pow(t(p1), n));
    var rho0 = a * F * Math.pow(t(p0), n);
    var rho = a * F * Math.pow(t(lat * r), n);
    var th = n * (lon * r - l0);
    return { x: 500000 + rho * Math.sin(th), y: 6375000 + rho0 - rho * Math.cos(th) };
  }

  function dist(aLat, aLon, bLat, bLon) {
    var dx = (bLon - aLon) * 111320 * Math.cos(aLat * Math.PI / 180), dy = (bLat - aLat) * 111320;
    return Math.sqrt(dx * dx + dy * dy);
  }

  // Ближайший адрес к точке. { address, sub, full, lat, lon, far } или null, если рядом ничего (поле, море).
  function reverse(lat, lon) {
    var c = lest97(lat, lon);
    var url = App.config.geocodeUrl.replace('address=', '') + 'x=' + c.x.toFixed(1) + '&y=' + c.y.toFixed(1) + '&results=5';
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error('In-ADS ' + r.status);
      return r.json();
    }).then(function (j) {
      // Только адреса с номером дома: общие записи «Tallinn» или «Harju maakond» нам не подходят.
      var list = parseList(j && j.addresses).filter(function (a) { return /\d/.test(a.address); });
      list.forEach(function (a) { a.d = dist(lat, lon, a.lat, a.lon); });
      list.sort(function (x, y) { return x.d - y.d; });
      var best = list[0];
      if (!best || best.d > 400) return null;
      best.far = best.d > 60;   // далеко от дома — покажем «рядом с …»
      return best;
    });
  }

  // ---- Поиск мест по названию: «Kristiine keskus», «Solaris», остановки ----
  // Сначала Peatus.ee (Pelias: заведения и остановки Эстонии). Если там пусто (опечатка),
  // то Photon (komoot, данные OpenStreetMap) — он прощает ошибки в названии.
  var PEATUS_GEO = 'https://api.peatus.ee/geocoding/v1/autocomplete';
  var PHOTON = 'https://photon.komoot.io/api/';
  var placeCache = {};

  function near(list, x) {
    return list.some(function (y) {
      return y.address.toLowerCase() === x.address.toLowerCase() && dist(y.lat, y.lon, x.lat, x.lon) < 300;
    });
  }

  function peatusPlaces(q, focus) {
    var url = PEATUS_GEO + '?text=' + encodeURIComponent(q) + '&lang=et&layers=venue,stop' +
      (focus ? '&focus.point.lat=' + focus.lat.toFixed(4) + '&focus.point.lon=' + focus.lon.toFixed(4) : '');
    return fetch(url).then(function (r) { return r.ok ? r.json() : { features: [] }; }).then(function (j) {
      return (j.features || []).map(function (f) {
        var p = f.properties || {};
        var c = f.geometry && f.geometry.coordinates;
        if (!c || !p.name) return null;
        var sub = String(p.locality || p.localadmin || '').trim();
        var stop = p.layer === 'stop';
        // У остановок в Peatus.ee к названию приклеен код платформы: «Puhangu 09604-1» → «Puhangu»
        var name = stop ? String(p.name).replace(/\s+\d{3,}(-\d+)?$/, '').trim() : p.name;
        return { address: name, sub: sub, lat: c[1], lon: c[0], kind: stop ? 'stop' : 'place' };
      }).filter(Boolean);
    }, function () { return []; });
  }

  function photonPlaces(q, focus) {
    var url = PHOTON + '?q=' + encodeURIComponent(q) + '&limit=8' + (focus ? '&lat=' + focus.lat.toFixed(4) + '&lon=' + focus.lon.toFixed(4) : '');
    return fetch(url).then(function (r) { return r.ok ? r.json() : { features: [] }; }).then(function (j) {
      return (j.features || []).map(function (f) {
        var p = f.properties || {};
        var c = f.geometry && f.geometry.coordinates;
        if (!c || !p.name || p.osm_key === 'highway' || p.osm_key === 'place' || p.osm_key === 'boundary') return null;
        if (p.countrycode && p.countrycode !== 'EE') return null;
        var street = [p.street, p.housenumber].filter(Boolean).join(' ');
        var sub = [street, p.city || p.town || p.village].filter(Boolean).join(', ');
        return { address: p.name, sub: sub, lat: c[1], lon: c[0], kind: 'place' };
      }).filter(Boolean);
    }, function () { return []; });
  }

  // До 5 мест по названию. focus — откуда искать ближе (моя точка).
  function places(text, focus) {
    var q = String(text || '').trim();
    if (q.length < 3) return Promise.resolve([]);
    var key = q.toLowerCase();
    if (placeCache[key]) return Promise.resolve(placeCache[key]);
    return peatusPlaces(q, focus).then(function (list) {
      var venues = list.filter(function (x) { return x.kind === 'place'; });
      if (venues.length >= 2) return list;
      return photonPlaces(q, focus).then(function (more) {
        more.forEach(function (x) { if (!near(list, x)) list.push(x); });
        return list;
      });
    }).then(function (list) {
      // места выше остановок; одинаковые рядом — один раз
      var out = [];
      list.sort(function (a, b) { return (a.kind === 'stop') - (b.kind === 'stop'); }).forEach(function (x) { if (!near(out, x)) out.push(x); });
      out = out.slice(0, 5);
      placeCache[key] = out;
      return out;
    });
  }

  App.geocode = { resolve: resolve, find: find, suggest: suggest, reverse: reverse, places: places };
})(window.App = window.App || {});
