/*
 * Обычное расписание Tallinna Linnatransport, как на transport.tallinn.ee: линия → направление → остановка → время по часам.
 * Данные — Peatus.ee (тот же GTFS, что у города). У линии бывает несколько вариантов в справочнике
 * («66 (kuni 31.10)» и «66 (al 01.11)») — берём только рейсы, которые ходят в выбранный день.
 */
(function (App) {
  'use strict';

  var AGENCY = 'estonia:tallinn_10312960';   // Aktsiaselts Tallinna Linnatransport

  function gql(query, variables) {
    return fetch(App.config.plannerUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify({ query: query, variables: variables })
    }).then(function (r) {
      if (!r.ok) throw new Error('Peatus.ee ' + r.status);
      return r.json();
    }).then(function (j) {
      if (j.errors && j.errors.length) throw new Error(j.errors[0].message || tr('Ошибка Peatus.ee'));
      return j.data;
    });
  }

  function ymd(d) {
    return d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
  }
  function cleanName(n) { return String(n || '').replace(/^ÖÖ\s+/i, '').replace(/\s*\((kuni|al|alates|trollibuss)[^)]*\)/gi, '').replace(/\s+/g, ' ').trim(); }

  // Все линии города: [{ key, line, mode, name, ids }]
  var linesP = null;
  function lines() {
    if (linesP) return linesP;
    try {
      var c = JSON.parse(localStorage.getItem('pv.ttLines3') || 'null');
      if (c && Array.isArray(c.list) && Date.now() - c.at < 12 * 3600000) return (linesP = Promise.resolve(c.list));
    } catch (e) { /* без кэша */ }
    linesP = gql('query($id: String!) { agency(id: $id) { routes { gtfsId shortName longName mode } } }', { id: AGENCY }).then(function (d) {
      var map = {};
      var list = [];
      ((d.agency && d.agency.routes) || []).forEach(function (r) {
        var mode = App.routeMode ? App.routeMode(r, r.mode) : r.mode;
        var night = /^(ÖÖ|öö)(\s|$)/.test(String(r.longName || '').trim());
        var key = mode + '|' + r.shortName;
        var x = map[key];
        if (!x) { x = map[key] = { key: key, line: String(r.shortName), mode: mode, cat: mode, night: night, name: cleanName(r.longName), ids: [] }; list.push(x); }
        x.ids.push(r.gtfsId);
        if (!/\(kuni/i.test(r.longName || '')) x.name = cleanName(r.longName);   // имя действующего варианта
      });
      list.sort(function (a, b) {
        return (parseInt(a.line, 10) || 999) - (parseInt(b.line, 10) || 999) || a.line.localeCompare(b.line);
      });
      // Поезда (Elron): по виду транспорта RAIL. Если Peatus.ee не отдал их — список просто без поездов
      return gql('query { agencies { gtfsId routes { gtfsId shortName longName mode } } }', {}).then(function (a) {
        var rmap = {};
        var rails = [];
        ((a && a.agencies) || []).forEach(function (ag) {
          (ag.routes || []).forEach(function (r) {
            if (r.mode !== 'RAIL') return;
            var label = String(r.shortName || r.longName || '').trim();
            if (!label) return;
            var key = 'RAIL|' + label;
            var x = rmap[key];
            if (!x) { x = rmap[key] = { key: key, line: label, mode: 'RAIL', cat: 'RAIL', night: false, name: String(r.longName || r.shortName || '').trim(), ids: [] }; rails.push(x); }
            x.ids.push(r.gtfsId);
          });
        });
        rails.sort(function (p, q) { return p.line.localeCompare(q.line); });
        return list.concat(rails);
      }).catch(function () { return list; });
    }).then(function (all) {
      try { localStorage.setItem('pv.ttLines3', JSON.stringify({ at: Date.now(), list: all })); } catch (e) { /* без кэша */ }
      return all;
    }).catch(function (e) { linesP = null; throw e; });
    return linesP;
  }

  /*
   * Направления линии в этот день: [{ id, to, from, stops: [{gtfsId, name, lat, lon}], codes: [коды вариантов] }].
   * Основной вариант направления — тот, у которого больше рейсов; укороченные рейсы («до Hobujaama») идут в codes.
   */
  var dirCache = {};
  function directions(line, date) {
    var key = line.key + '|' + ymd(date);
    if (dirCache[key]) return dirCache[key];
    var parts = line.ids.map(function (id, i) {
      return 'r' + i + ': route(id: ' + JSON.stringify(id) + ') { gtfsId patterns { code headsign directionId tripsForDate(serviceDate: $d) { gtfsId } stops { gtfsId name lat lon } patternGeometry { points } } }';
    });
    var p = gql('query($d: String!) { ' + parts.join(' ') + ' }', { d: ymd(date) }).then(function (d) {
      var groups = {};
      Object.keys(d || {}).forEach(function (k) {
        var r = d[k];
        if (!r) return;
        (r.patterns || []).forEach(function (pt) {
          var n = (pt.tripsForDate || []).length;
          if (!n || !pt.stops || pt.stops.length < 2) return;
          var gk = r.gtfsId + '|' + pt.directionId;
          var g = groups[gk] || (groups[gk] = { id: gk, codes: [], trips: 0, main: null, mainN: -1 });
          g.codes.push(pt.code);
          g.trips += n;
          if (n > g.mainN || (n === g.mainN && pt.stops.length > g.main.stops.length)) { g.main = pt; g.mainN = n; }
        });
      });
      var out = Object.keys(groups).map(function (k) {
        var g = groups[k];
        var st = g.main.stops;
        var geo = g.main.patternGeometry && App.planner ? App.planner.decode(g.main.patternGeometry.points) : null;
        return { id: g.id, codes: g.codes, trips: g.trips, stops: st, points: geo && geo.length > 1 ? geo : st.map(function (x) { return [x.lat, x.lon]; }), from: st[0].name, to: st[st.length - 1].name };
      });
      out.sort(function (a, b) { return b.trips - a.trips; });
      var byTo = {};
      var res = [];
      out.forEach(function (x) {
        if (byTo[x.to]) { byTo[x.to].codes = byTo[x.to].codes.concat(x.codes); return; }
        byTo[x.to] = x;
        res.push(x);
      });
      return res;
    }).catch(function (e) { delete dirCache[key]; throw e; });
    dirCache[key] = p;
    return p;
  }

  /*
   * Отправления с остановки в этот день по вариантам направления.
   * [{ sec — секунды от начала дня (бывает больше 24 ч для ночных), headsign }]
   */
  var SQ = 'query($id: String!, $d: String!) { stop(id: $id) { stoptimesForServiceDate(date: $d, omitNonPickups: true) {' +
    ' pattern { code } stoptimes { scheduledDeparture headsign trip { gtfsId } } } } }';
  var WQ = 'query($id: String!, $d: String!) { stop(id: $id) { stoptimesForServiceDate(date: $d, omitNonPickups: true) { stoptimes { scheduledDeparture trip { wheelchairAccessible } } } } }';
  var timesCache = {};
  function times(stopId, codes, date) {
    var key = stopId + '|' + ymd(date) + '|' + codes.join(',');
    if (timesCache[key]) return timesCache[key];
    // Низкопольные рейсы (для колясок): отдельный запрос — если поля нет в данных, расписание всё равно работает
    var lowP = gql(WQ, { id: stopId, d: ymd(date) }).then(function (d) {
      var low = {};
      ((d.stop && d.stop.stoptimesForServiceDate) || []).forEach(function (g) {
        (g.stoptimes || []).forEach(function (s) { if (s.trip && s.trip.wheelchairAccessible === 'POSSIBLE') low[s.scheduledDeparture] = true; });
      });
      return low;
    }).catch(function () { return {}; });
    var p = Promise.all([gql(SQ, { id: stopId, d: ymd(date) }), lowP]).then(function (res) {
      var d = res[0];
      var low = res[1];
      var out = [];
      var seen = {};
      ((d.stop && d.stop.stoptimesForServiceDate) || []).forEach(function (g) {
        if (!g.pattern || codes.indexOf(g.pattern.code) < 0) return;
        (g.stoptimes || []).forEach(function (s) {
          if (seen[s.scheduledDeparture]) return;
          seen[s.scheduledDeparture] = true;
          out.push({ sec: s.scheduledDeparture, headsign: s.headsign || '', trip: s.trip ? s.trip.gtfsId : '', low: !!low[s.scheduledDeparture] });
        });
      });
      out.sort(function (a, b) { return a.sec - b.sec; });
      return out;
    }).catch(function (e) { delete timesCache[key]; throw e; });
    timesCache[key] = p;
    return p;
  }

  // Весь рейс: остановки и время на каждой. [{ sec, stop: {gtfsId, name, lat, lon} }], points — линия рейса
  var TQ = 'query($id: String!, $d: String!) { trip(id: $id) { tripHeadsign stoptimesForDate(serviceDate: $d) { scheduledDeparture scheduledArrival stop { gtfsId name lat lon } }' +
    ' pattern { patternGeometry { points } } } }';
  var tripCache = {};
  function trip(id, date) {
    var key = id + '|' + ymd(date);
    if (tripCache[key]) return tripCache[key];
    var p = gql(TQ, { id: id, d: ymd(date) }).then(function (d) {
      var t = d.trip;
      if (!t) return null;
      var geo = t.pattern && t.pattern.patternGeometry && App.planner ? App.planner.decode(t.pattern.patternGeometry.points) : null;
      var st = (t.stoptimesForDate || []).map(function (s) { return { sec: s.scheduledDeparture, arr: s.scheduledArrival, stop: s.stop }; });
      return { headsign: t.tripHeadsign || '', stops: st, points: geo && geo.length > 1 ? geo : st.map(function (x) { return [x.stop.lat, x.stop.lon]; }) };
    }).catch(function (e) { delete tripCache[key]; throw e; });
    tripCache[key] = p;
    return p;
  }

  // «Транспортный» сегодняшний день: до 4 утра ещё идут рейсы вчерашнего дня (ночные автобусы, поздние рейсы).
  function serviceToday() { var d = new Date(Date.now() - 4 * 3600000); d.setHours(12, 0, 0, 0); return d; }
  // Ближайшая дата этого типа: 'wd' — будни, 'sat', 'sun'. Сегодня подходит — значит сегодня.
  function dateFor(type, from) {
    var d = new Date(from || serviceToday());
    d.setHours(12, 0, 0, 0);
    for (var i = 0; i < 7; i++) {
      var w = d.getDay();
      if ((type === 'wd' && w >= 1 && w <= 5) || (type === 'sat' && w === 6) || (type === 'sun' && w === 0)) return d;
      d.setDate(d.getDate() + 1);
    }
    return d;
  }
  function typeOf(date) { var w = date.getDay(); return w === 6 ? 'sat' : w === 0 ? 'sun' : 'wd'; }

  App.timetable = { trip: trip, serviceToday: serviceToday, lines: lines, directions: directions, times: times, dateFor: dateFor, typeOf: typeOf, ymd: ymd };
})(window.App = window.App || {});
