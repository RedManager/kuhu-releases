/*
 * Живые данные, общие для всех экранов:
 *  - App.feed: координаты транспорта Таллина (gps.txt) раз в 10 секунд, пока приложение на экране;
 *  - App.here: где я (GPS телефона) или «дом» из настроек.
 * В приложении (Android) запросы идут через нативный HTTP, поэтому gps.txt доступен.
 * В обычном браузере сайт transport.tallinn.ee такие запросы блокирует — тогда работаем по расписанию.
 */
(function (App) {
  'use strict';

  var listeners = [];
  function emit(kind) { listeners.forEach(function (fn) { fn(kind); }); }

  // ---------- Транспорт ----------
  var feed = { vehicles: [], at: 0, ok: false, failed: 0, timer: null };

  // Сколько машина стоит на одном месте: «зависшая» (GPS не обновляется) не должна считаться ближайшей.
  var seen = {};
  function markStill(list) {
    var now = Date.now();
    var next = {};
    list.forEach(function (v) {
      var o = seen[v.id];
      if (!o || App.vehicles.dist(o.lat, o.lon, v.lat, v.lon) > 15) o = { lat: v.lat, lon: v.lon, since: now };
      next[v.id] = o;
      v.still = now - o.since;
    });
    seen = next;
  }

  function loadFeed() {
    return App.vehicles.load().then(function (v) {
      markStill(v);
      feed.vehicles = v;
      feed.at = Date.now();
      feed.ok = true;
      feed.failed = 0;
      emit('feed');
    }).catch(function () {
      feed.failed++;
      if (feed.failed >= 2) feed.ok = false;
      emit('feed');
    });
  }

  App.feed = {
    get vehicles() { return feed.vehicles; },
    get at() { return feed.at; },
    get ok() { return feed.ok; },
    get failed() { return feed.failed; },
    start: function () {
      if (feed.timer) return;
      loadFeed();
      feed.timer = setInterval(loadFeed, App.config.refreshSeconds * 1000);
    },
    stop: function () { clearInterval(feed.timer); feed.timer = null; },
    now: loadFeed
  };

  // ---------- Где я ----------
  // here.mode: 'gps' — по GPS телефона; 'home' — выбран дом; here.pos = { lat, lon, acc, at }
  var here = { mode: 'gps', pos: null, error: '', watch: null, lastPlanPos: null, pick: null };
  try { here.pick = JSON.parse(localStorage.getItem('pv.pick') || 'null'); } catch (e) { /* без точки */ }

  function setPos(p) {
    here.pos = p;
    here.error = '';
    here.denied = false;
    emit('here');
  }

  function startGps() {
    if (here.watch !== null) return;
    if (!navigator.geolocation) { here.error = tr('Телефон не даёт геолокацию'); emit('here'); return; }
    here.watch = navigator.geolocation.watchPosition(function (p) {
      setPos({ lat: p.coords.latitude, lon: p.coords.longitude, acc: Math.round(p.coords.accuracy || 0), at: Date.now() });
    }, function (err) {
      here.denied = err.code === 1;
      here.error = err.code === 1 ? tr('Нет разрешения на геолокацию') : tr('Не удаётся определить место');
      emit('here');
    }, { enableHighAccuracy: true, maximumAge: 15000, timeout: 20000 });
  }
  function stopGps() {
    if (here.watch !== null && navigator.geolocation) navigator.geolocation.clearWatch(here.watch);
    here.watch = null;
  }

  App.here = {
    get mode() { return here.mode; },
    get error() { return here.error; },
    get denied() { return !!here.denied; },
    // Место по GPS телефона неточное (хуже 100 м): расчёт «выходи через» приблизительный
    get weak() { return here.mode === 'gps' && !!here.pos && here.pos.acc > 100; },
    get gps() { return here.pos; },
    // Точка отправления для маршрута. null — ещё не знаем.
    get pick() { return here.pick; },
    // Точка, выбранная на карте: { address, lat, lon }
    setPick: function (p) {
      here.pick = p;
      try { localStorage.setItem('pv.pick', JSON.stringify(p)); } catch (e) { /* без памяти */ }
      this.setMode('pick');
    },
    origin: function () {
      if (here.mode === 'pick' && here.pick) return { lat: here.pick.lat, lon: here.pick.lon, label: here.pick.address, pick: true };
      if (here.mode === 'home' && App.config.home) return { lat: App.config.home.lat, lon: App.config.home.lon, label: tr('Дом'), home: true };
      if (here.mode === 'work' && App.config.work) return { lat: App.config.work.lat, lon: App.config.work.lon, label: tr('Работа'), work: true };
      if (here.pos) return { lat: here.pos.lat, lon: here.pos.lon, label: tr('Я здесь'), acc: here.pos.acc };
      if (App.config.home) return { lat: App.config.home.lat, lon: App.config.home.lon, label: tr('Дом'), home: true, fallback: true };
      return null;
    },
    setMode: function (m) {
      here.mode = m;
      try { localStorage.setItem('pv.origin', m); } catch (e) { /* без памяти */ }
      emit('here');
    },
    start: function () {
      try {
        var m = localStorage.getItem('pv.origin');
        here.mode = m === 'home' && App.config.home ? 'home' : m === 'work' && App.config.work ? 'work' : m === 'pick' && here.pick ? 'pick' : 'gps';
      } catch (e) { /* по умолчанию GPS */ }
      startGps();
    },
    stop: stopGps,
    retry: function () { stopGps(); startGps(); }
  };

  // Сдвинулась ли точка отправления настолько, что маршрут надо пересчитать (больше 120 м).
  App.movedEnough = function (a, b) {
    if (!a || !b) return true;
    return App.vehicles.dist(a.lat, a.lon, b.lat, b.lon) > 120;
  };

  App.onLive = function (fn) { listeners.push(fn); };
})(window.App = window.App || {});
