/*
 * Режим «Еду на этом»: движок ведения по выбранному маршруту, пока приложение открыто.
 * Следит за GPS телефона и сдвигает шаги: идти → ждать → ехать → выходить → пересадка → на месте.
 * Экрана у него нет: события рисует экран поездки (app.js), чтобы вид не менялся.
 * Без работы в фоне: экран остаётся включённым, при закрытом приложении сигналов нет.
 */
(function (App) {
  'use strict';

  var WALK_M_PER_MIN = 80;   // шаг ~4,8 км/ч (оценка)
  var S = null;              // состояние поездки
  var timer = null;
  var wake = null;

  function vibrate(p) { if (navigator.vibrate) try { navigator.vibrate(p); } catch (e) { /* без вибрации */ } }
  function dist(a, lat, lon) { return App.vehicles.dist(a.lat, a.lon, lat, lon); }

  // ---------- Экран всегда включён ----------
  function keepAwake() {
    try {
      if (navigator.wakeLock && navigator.wakeLock.request) {
        navigator.wakeLock.request('screen').then(function (l) { wake = l; }).catch(function () { /* не дали */ });
      }
    } catch (e) { /* без wake lock */ }
  }
  function release() {
    try { if (wake && wake.release) wake.release(); } catch (e) { /* уже снят */ }
    wake = null;
  }
  document.addEventListener('visibilitychange', function () { if (S && document.visibilityState === 'visible') { release(); keepAwake(); } });

  // ---------- Шаги ----------
  function buildSteps(opt) {
    var legs = opt.legs || [];
    var out = [];
    legs.forEach(function (l, i) {
      if (!l.transit) {
        if (l.minutes < 1 && i !== 0 && i !== legs.length - 1) return;
        out.push({ kind: 'walk', leg: l, last: false });
      } else out.push({ kind: 'ride', leg: l, boarded: false, seenNear: false, passed: -1, alerts: {} });
    });
    if (out.length) out[out.length - 1].last = true;
    return out;
  }

  function next() {
    if (!S) return;
    S.cur++;
    if (S.cur >= S.steps.length) { S.done = true; vibrate([200, 100, 200]); if (App.tips) App.tips.countTrip(); }
  }

  function posFresh() {
    var p = App.here.gps;
    return p && Date.now() - p.at < 60000 ? p : null;
  }

  // Решает, что сейчас происходит, и сдвигает шаг. Возвращает описание для экрана.
  function evaluate() {
    var now = Date.now();
    var p = posFresh();
    if (S.done) return { kind: 'done' };
    var st = S.steps[S.cur];
    var l = st.leg;
    if (st.kind === 'walk') {
      var d = p && l.toLat != null ? dist(p, l.toLat, l.toLon) : null;
      if (d !== null && d < 35) { next(); return evaluate(); }
      var nj = -1;
      for (var j = S.cur + 1; j < S.steps.length; j++) if (S.steps[j].kind === 'ride') { nj = j; break; }
      return { kind: 'walk', st: st, dist: d, last: st.last, nextLeg: nj >= 0 ? S.steps[nj].leg : null, nextEta: nj >= 0 ? S.etaFor(S.steps[nj].leg, nj) : null };
    }
    // поездка
    var eta = S.etaFor(l, S.cur);
    var d0 = p && l.fromLat != null ? dist(p, l.fromLat, l.fromLon) : null;
    if (!st.boarded) {
      if (d0 !== null && d0 < 100) st.seenNear = true;
      if (st.seenNear && d0 !== null && d0 > 150) st.boarded = true;
      // Сели без «заметили на остановке»: едем рядом с нужным автобусом и уже далеко от остановки
      if (!st.boarded && p && d0 !== null && d0 > 120 && S.busFor) {
        var bv = S.busFor(l);
        if (bv && dist(p, bv.lat, bv.lon) < 50) st.boarded = true;
      }
      if (!st.boarded) return { kind: 'wait', st: st, eta: eta, near: d0, transfer: S.cur > 0 && S.steps.slice(0, S.cur).some(function (x) { return x.kind === 'ride'; }) };
    }
    // едем
    var list = S.stopsFor(l);
    var exitD = p && l.toLat != null ? dist(p, l.toLat, l.toLon) : null;
    if (list && list.length && p) {
      for (var i = list.length - 1; i > st.passed; i--) {
        if (list[i].lat != null && dist(p, list[i].lat, list[i].lon) < 120) { st.passed = i; break; }
      }
    }
    if (exitD !== null && exitD < 70 && (!list || st.passed >= (list ? list.length - 1 : 0))) { next(); return evaluate(); }
    var left = list ? list.length - 1 - st.passed : null;    // остановок до выхода, считая выход
    var alertKey = left === 1 ? 'one' : left === 2 ? 'two' : null;
    if (alertKey && !st.alerts[alertKey]) {
      st.alerts[alertKey] = true;
      vibrate(alertKey === 'one' ? [300, 150, 300, 150, 300] : [120]);
    }
    return { kind: 'ride', st: st, left: left, list: list, exitD: exitD, exitAt: list && list.length ? list[list.length - 1].at : l.end };
  }

  // ---------- Управление ----------
  function tick() {
    if (!S) return;
    S.ev = evaluate();
    if (S.onTick) S.onTick(S.ev);
  }

  function start(o) {
    var steps = buildSteps(o.opt);
    if (!steps.length) return false;
    S = { steps: steps, cur: 0, done: false, etaFor: o.etaFor, busFor: o.busFor, stopsFor: o.stopsFor, onTick: o.onTick, ev: null };
    keepAwake();
    tick();
    clearInterval(timer);
    timer = setInterval(tick, 1000);
    return true;
  }
  function stop() {
    S = null;
    clearInterval(timer);
    timer = null;
    release();
  }

  App.ride = {
    start: start, stop: stop, active: function () { return !!S; },
    event: function () { return S ? S.ev : null; },
    stepIndex: function () { return S ? (S.done ? S.steps.length : S.cur) : -1; },
    steps: function () { return S ? S.steps : []; },
    tick: tick, walkMPerMin: WALK_M_PER_MIN
  };
})(window.App = window.App || {});
